# ADR-0022 - Assinaturas e Dedupe por Domínio (MacroRoute vs Level)

## Status atual (2026-03-11)
- Status: **DONE**
- Implementado no código:
  - Dedupe local por `LevelSignature` no `LevelStageOrchestrator`.
  - `SelectionVersion` permanece apenas como metadado de observabilidade; não é mais a identidade principal.
  - `LevelSignature` propagada em snapshot/eventos e consumida no IntroStage.
- Evidência:
  - `Docs/Reports/Audits/LATEST.md`
  - `Docs/Reports/Evidence/LATEST.md`

## Status

- Estado: **Aceito (Implementado)**
- Data (decisão): 2026-02-19
- Última atualização: 2026-03-12

## Decisão canônica atual

- Macro assinatura: `SceneTransitionContext.ContextSignature`.
- Level assinatura: `levelSignature` baseada em `levelRef` (`level:...|route:...|reason:...`).
- Dedupe de level por `LevelSignature`.
- `SelectionVersion` não define identidade canônica.
- `levelId/contentId` não definem identidade canônica de level.

## Evidência (log)

- `lastlog:737` `StartGameplayRouteAsync without level selection; default will be selected in LevelPrepare.`
- `lastlog:1145` `LevelDefaultSelected ... levelRef='Level1'`
- `lastlog:1211` `IntroStageStartRequested ... levelSignature='level:Level1|route:to-gameplay|reason:Menu/PlayButton'`
- `lastlog:1783` `RestartMacroRequested reason='PostGame/Restart' dispatched='GameResetRequestedEvent'.`

## Observação de escopo

- O fechamento deste ADR vale para o eixo principal de `LevelFlow`.
- Qualquer referência histórica a `levelId/contentId` deve ser lida como legado fora do contrato canônico atual.
- A exceção remanescente de `Gameplay ActorGroupRearm` fica fora deste escopo.
