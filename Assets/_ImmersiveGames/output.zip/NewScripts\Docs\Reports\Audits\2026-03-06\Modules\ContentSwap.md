# ContentSwap Module Audit

## A) Scope
- Entra: `Modules/ContentSwap/**` (`Runtime`, `Dev`).
- EventBus inputs: `ContentSwapCommittedEvent` (bridge legacy em Navigation).
- Chamadas publicas: `IContentSwapContextService`, `IContentSwapChangeService`.
- Unity callbacks: `ContentSwapDevBootstrapper`/`ContentSwapDevContextMenu` em dev.

## B) Outputs
- Aplica troca de conteudo in-place por `InPlaceContentSwapService`.
- Publica eventos de ContentSwap definidos em `ContentSwapEvents.cs` (conforme execucao).
- Efeito em Gate/InputMode: nenhum direto.

## C) DI Registration
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`:
  - `IContentSwapContextService` -> `ContentSwapContextService`
  - `IContentSwapChangeService` -> `InPlaceContentSwapService` (via `GlobalCompositionRoot.ContentLevels.cs`)

## D) Canonical Runtime Rail
- Trilho can�nico: recuperar contexto (`IContentSwapContextService`) -> aplicar plano in-place (`IContentSwapChangeService`) -> commit de troca.

## E) LEGACY/Compat
- `Modules/Navigation/RestartSnapshotContentSwapBridge.cs` declara comportamento no-op para integra��o antiga de restart com content swap.

## F) Redundancy Candidates
- `Modules/Navigation/RestartSnapshotContentSwapBridge.cs` (fora da pasta do modulo, mas acoplado ao dominio) - no-op legacy; risco baixo.
- `Modules/ContentSwap/Dev/Runtime/ContentSwapDevBootstrapper.cs` e `GlobalCompositionRoot.DevQA.cs` ambos viabilizam caminho dev installer; risco baixo.

## G) Deletion/Merge Plan (DOC-ONLY)
- Manter integra��o de restart-contentswap estritamente fora do trilho can�nico enquanto bridge permanecer no-op.
- Consolidar entrypoint dev em apenas um owner (ou bootstrapper local ou DevQA global).

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Modules/ContentSwap/Runtime/ContentSwapContextService.cs | Runtime | context API | N/A | N/A | `IContentSwapContextService` | Canon |
| Modules/ContentSwap/Runtime/InPlaceContentSwapService.cs | Runtime | change API | pode consumir contexto/eventos internos | eventos de commit/aplicacao | `IContentSwapChangeService` | Canon |
| Modules/ContentSwap/Runtime/ContentSwapEvents.cs | Shared | event contracts | N/A | N/A | N/A | Canon |
| Modules/ContentSwap/Runtime/ContentSwapPlan.cs | Shared | plan model | N/A | N/A | N/A | Canon |
| Modules/ContentSwap/Dev/Runtime/ContentSwapDevInstaller.cs | Runtime | `EnsureInstalled` | N/A | N/A | N/A | Dev/QA |
| Modules/ContentSwap/Dev/Bindings/ContentSwapDevContextMenu.cs | Editor | context menu actions | N/A | N/A | N/A | Dev/QA |
| Modules/Navigation/RestartSnapshotContentSwapBridge.cs | Runtime | ctor/Dispose | `ContentSwapCommittedEvent` | none efetivo | none (registration path not in pipeline) | Legacy/Compat no-op |