namespace _ImmersiveGames.NewScripts.Infrastructure.Composition
{
    public static partial class GlobalCompositionRoot
    {
        // ContentSwap removido do trilho canônico.
        // Arquivo preservado temporariamente apenas para evitar quebra caso a remoção física
        // do partial aconteça em etapa separada na IDE.
    }
}
