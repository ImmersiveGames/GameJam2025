# CS-1.1 - ContentSwap Cleanup Audit v1 (behavior-preserving)

Date: 2026-03-06
Scope:
- `Modules/ContentSwap/**`
- callsites em `Infrastructure/Composition/**`
- consumidores em `Modules/WorldLifecycle/**`, `Modules/LevelFlow/**`, `Modules/SceneFlow/**`, `Modules/DevQA/**` (quando existente)

## A) Owners
- Owner can�nico do fluxo de troca: `Modules/ContentSwap/Runtime/InPlaceContentSwapService.cs` (`IContentSwapChangeService`).
- Owner can�nico do estado/contexto: `Modules/ContentSwap/Runtime/ContentSwapContextService.cs` (`IContentSwapContextService`).
- Registro de pipeline (DI):
  - `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
  - `Infrastructure/Composition/GlobalCompositionRoot.ContentLevels.cs`
- Consumer can�nico externo ao m�dulo para reset de n�vel:
  - `Modules/WorldLifecycle/Runtime/WorldResetCommands.cs` (`ResolveGlobalOrFail<IContentSwapChangeService>` + `RequestContentSwapInPlaceAsync`).

## B) Consumers / eventos
- Eventos publicados por ContentSwap:
  - `ContentSwapPendingSetEvent` (`ContentSwapContextService.SetPending`)
  - `ContentSwapCommittedEvent` (`ContentSwapContextService.TryCommitPending`)
  - `ContentSwapPendingClearedEvent` (`ContentSwapContextService.ClearPending`)
- Consumers identificados:
  - `Modules/Navigation/Legacy/RestartSnapshotContentSwapBridge.cs` consome `ContentSwapCommittedEvent` (LEGACY/no-op fora do trilho can�nico).
- Evento de request observ�vel:
  - `InPlaceContentSwapService` registra log can�nico `[OBS][ContentSwap] ContentSwapRequested ...`.

## C) Registration / callsites (pipeline)
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
  - `InstallContentSwapServices()`
  - `RegisterIfMissing<IContentSwapContextService>(() => new ContentSwapContextService())`
  - `RegisterContentSwapChangeService()`
- `Infrastructure/Composition/GlobalCompositionRoot.ContentLevels.cs`
  - registra `IContentSwapChangeService` com `InPlaceContentSwapService(contextService)`.
- Dev/QA bootstrap:
  - `Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs` chama `ContentSwapDevInstaller.EnsureInstalled()`.

## Classifica��o por arquivo (Modules/ContentSwap)
| FilePath | Classifica��o | Evid�ncia est�tica | Notes |
|---|---|---|---|
| `Modules/ContentSwap/Runtime/IContentSwapChangeService.cs` | CANON_RUNTIME | interface resolvida no DI e consumida por `WorldResetCommands` | contrato can�nico |
| `Modules/ContentSwap/Runtime/IContentSwapContextService.cs` | CANON_RUNTIME | registrada em `GlobalCompositionRoot.Pipeline.cs` | contrato de contexto |
| `Modules/ContentSwap/Runtime/InPlaceContentSwapService.cs` | CANON_RUNTIME | registrada como `IContentSwapChangeService` em `GlobalCompositionRoot.ContentLevels.cs` | owner de request/commit in-place |
| `Modules/ContentSwap/Runtime/ContentSwapContextService.cs` | CANON_RUNTIME | registrada como `IContentSwapContextService` no pipeline | owner de estado + eventos |
| `Modules/ContentSwap/Runtime/ContentSwapEvents.cs` | CANON_RUNTIME | eventos publicados por `ContentSwapContextService` | contrato de eventos |
| `Modules/ContentSwap/Runtime/ContentSwapPlan.cs` | CANON_RUNTIME | usado por interfaces e servi�os runtime | payload can�nico |
| `Modules/ContentSwap/Runtime/ContentSwapOptions.cs` | CANON_RUNTIME | usado por `IContentSwapChangeService` e `InPlaceContentSwapService` | op��es runtime |
| `Modules/ContentSwap/Runtime/ContentSwapMode.cs` | CANON_RUNTIME | usado em log can�nico de request | enum observ�vel |
| `Modules/ContentSwap/Dev/Runtime/ContentSwapDevInstaller.cs` | DEV_ONLY | chamado por `GlobalCompositionRoot.DevQA.cs` | instalado s� em editor/dev |
| `Modules/ContentSwap/Dev/Runtime/ContentSwapDevBootstrapper.cs` | DEV_ONLY | `RuntimeInitializeOnLoadMethod` + `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | potencial overlap com DevQA installer |
| `Modules/ContentSwap/Dev/Bindings/ContentSwapDevContextMenu.cs` | DEV_ONLY | `#if UNITY_EDITOR` + consumido pelo installer dev | contexto QA/editor |

## LEGACY_COMPAT / ORPHAN_CANDIDATE
- `LEGACY_COMPAT` dentro de `Modules/ContentSwap/**`: nenhum identificado.
- `ORPHAN_CANDIDATE` dentro de `Modules/ContentSwap/**`: nenhum identificado com seguran�a est�tica.
- Observa��o de legado fora do m�dulo: `Modules/Navigation/Legacy/RestartSnapshotContentSwapBridge.cs` escuta `ContentSwapCommittedEvent` e permanece fora do trilho can�nico.

## Moves aplicados (CS-1.1)
- Nenhum move de `.cs` (crit�rio de seguran�a conservador).
- Resultado desta etapa: **DOC-only**.

## Evid�ncia (comandos rg usados)
```text
rg -n "class\s+.*ContentSwap|IContentSwap|ContentSwapContext" Modules/ContentSwap Infrastructure/Composition Modules/LevelFlow Modules/WorldLifecycle Modules/SceneFlow Modules/DevQA
rg -n "InstallContentSwapServices|RegisterContentSwapChangeService|RegisterIfMissing<IContentSwapContextService>" Infrastructure/Composition Modules
rg -n "EventBus<.*ContentSwap.*>|ContentSwapRequested|ContentSwapCommitted" Modules/ContentSwap Infrastructure/Composition Modules/LevelFlow Modules/WorldLifecycle Modules/SceneFlow
rg -n "LEGACY|Compat|Obsolete|NoOp" Modules/ContentSwap Infrastructure/Composition Modules/LevelFlow Modules/WorldLifecycle Modules/SceneFlow
rg -n "IContentSwapChangeService|IContentSwapContextService|ContentSwapContextService|InPlaceContentSwapService|ContentSwapPlan|ContentSwapOptions|ContentSwapMode" Modules Infrastructure/Composition
rg -n "ContentSwapPendingSetEvent|ContentSwapPendingClearedEvent|ContentSwapCommittedEvent" Modules Infrastructure
rg -n "ContentSwapDevInstaller|ContentSwapDevBootstrapper|ContentSwapDevContextMenu" Modules Infrastructure/Composition
rg -n "RequestContentSwapInPlaceAsync|TryCommitPending|SetPending\(" Modules/ContentSwap Modules/WorldLifecycle Modules/LevelFlow Modules/SceneFlow
```

## Candidatos para CS-1.2 (mudan�a real)
1. Decidir owner �nico de instala��o Dev (`GlobalCompositionRoot.DevQA` vs `ContentSwapDevBootstrapper`) para evitar bootstrap duplo.
2. Revisar depend�ncia do legacy externo `Navigation/Legacy/RestartSnapshotContentSwapBridge` no evento `ContentSwapCommittedEvent`.
3. Revisar se eventos `ContentSwapPendingSet/Cleared` precisam consumers runtime adicionais ou permanecem s� para observabilidade.