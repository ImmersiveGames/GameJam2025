using System;
namespace _ImmersiveGames.NewScripts.GameplayRuntime.StateGate.Core
{
    /// <summary>
    /// Contract for services that gate player or gameplay actions based on global state.
    /// </summary>
    public interface IGameplayStateGate : IDisposable
    {
        event Action<GameplayOperationalStateSnapshot> OperationalStateChanged;
        bool CanExecuteGameplayAction(GameplayAction action);
        bool CanExecuteUiAction(UiAction action);
        bool CanExecuteSystemAction(SystemAction action);
        bool IsGameActive();
    }
}


