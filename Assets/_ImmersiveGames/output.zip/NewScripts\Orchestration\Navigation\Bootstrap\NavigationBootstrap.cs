﻿using System;
using _ImmersiveGames.NewScripts.Infrastructure.Composition;
using _ImmersiveGames.NewScripts.Infrastructure.Config;
using _ImmersiveGames.NewScripts.Core.Logging;
using _ImmersiveGames.NewScripts.Experience.PostRun.Ownership;
using _ImmersiveGames.NewScripts.Experience.PostRun.Result;
using _ImmersiveGames.NewScripts.Experience.Frontend.UI.Runtime;
using _ImmersiveGames.NewScripts.Orchestration.GameLoop.Bridges;
using _ImmersiveGames.NewScripts.Orchestration.PhaseDefinition;
using _ImmersiveGames.NewScripts.Orchestration.PhaseDefinition.Runtime;
using _ImmersiveGames.NewScripts.Orchestration.SceneFlow.Transition;
using _ImmersiveGames.NewScripts.Orchestration.Navigation.Runtime;
using _ImmersiveGames.NewScripts.Orchestration.LevelLifecycle.Runtime;
using _ImmersiveGames.NewScripts.Orchestration.SessionTransition.Bootstrap;
namespace _ImmersiveGames.NewScripts.Orchestration.Navigation.Bootstrap
{
    /// <summary>
    /// Compositor operacional de Navigation.
    ///
    /// Responsabilidade:
    /// - compor e ativar o runtime de transporte/dispatch depois que os installers relevantes terminam;
    /// - nao registrar contratos de boot.
    /// </summary>
    public static class NavigationBootstrap
    {
        private static bool _runtimeComposed;

        public static void ComposeRuntime(BootstrapConfigAsset bootstrapConfig)
        {
            CompositionPipelineExecutor.RequireBootstrapPhaseOpen(nameof(NavigationBootstrap));

            if (_runtimeComposed)
            {
                return;
            }

            if (bootstrapConfig == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] BootstrapConfigAsset required and missing to compose runtime.");
            }

            EnsureNavigationCoreComposition();
            EnsureGameplaySessionFlowContinuityService(bootstrapConfig);
            EnsureGameplaySessionRunResetService();
            SessionTransitionBootstrap.ComposeRuntime();
            NavigationAdaptersBootstrap.ComposeRuntime(bootstrapConfig);
            EnsureNavigationModuleComposition();

            _runtimeComposed = true;

            DebugUtility.Log(typeof(NavigationBootstrap),
                "[OBS][NavigationCore][Operational] Runtime composition completed.",
                DebugUtility.Colors.Info);
        }

        private static void EnsureNavigationCoreComposition()
        {
            if (DependencyManager.Provider.TryGetGlobal<IGameNavigationService>(out var existingService) && existingService != null)
            {
                return;
            }

            if (!DependencyManager.Provider.TryGetGlobal<ISceneTransitionService>(out var sceneFlow) || sceneFlow == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] ISceneTransitionService missing from global DI before runtime composition.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IGameNavigationCatalog>(out var catalog) || catalog == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IGameNavigationCatalog missing from global DI before runtime composition.");
            }

            var service = new GameNavigationService(sceneFlow, catalog);

            DependencyManager.Provider.RegisterGlobal<IGameNavigationService>(service);

            DebugUtility.LogVerbose(typeof(NavigationBootstrap),
                $"[OBS][NavigationCore][Operational] GameNavigationService composed at runtime (Catalog={catalog.GetType().Name}).",
                DebugUtility.Colors.Info);
        }

        private static void EnsureNavigationModuleComposition()
        {
            if (!DependencyManager.Provider.TryGetGlobal<IGameNavigationCatalog>(out var catalog) || catalog == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IGameNavigationCatalog missing from global DI before module composition checkpoint.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IGameNavigationService>(out var navigationService) || navigationService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IGameNavigationService missing from global DI before module composition checkpoint.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<GameLoopInputCommandBridge>(out var inputBridge) || inputBridge == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationAdapters] GameLoopInputCommandBridge missing from global DI before module composition checkpoint.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IFrontendQuitService>(out var frontendQuitService) || frontendQuitService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationAdapters] IFrontendQuitService missing from global DI before module composition checkpoint.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IGameplaySessionFlowContinuityService>(out var continuityService) || continuityService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IGameplaySessionFlowContinuityService missing from global DI before module composition checkpoint.");
            }

            DebugUtility.Log(typeof(NavigationBootstrap),
                "[OBS][NavigationCore][Operational] Runtime composition consolidated. scope='NavigationCore + NavigationAdapters + GameplaySessionFlow continuity seam'.",
                DebugUtility.Colors.Info);
        }

        private static void EnsureGameplaySessionFlowContinuityService(BootstrapConfigAsset bootstrapConfig)
        {
            if (DependencyManager.Provider.TryGetGlobal<IGameplaySessionFlowContinuityService>(out var existing) && existing != null)
            {
                return;
            }

            if (!DependencyManager.Provider.TryGetGlobal<IGameNavigationService>(out var navigationService) || navigationService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IGameNavigationService ausente no DI global antes de registrar o IGameplaySessionFlowContinuityService.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IRestartContextService>(out var restartContextService) || restartContextService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IRestartContextService ausente no DI global antes de registrar o IGameplaySessionFlowContinuityService.");
            }

            IPhaseResetExecutor phaseResetExecutor = new PhaseResetExecutor(restartContextService);
            IPhaseDefinitionCatalog phaseDefinitionCatalog = ResolveOptionalPhaseDefinitionCatalog(bootstrapConfig);

            var service = new GameplaySessionFlowContinuityService(
                navigationService,
                restartContextService,
                phaseResetExecutor,
                phaseDefinitionCatalog);

            DependencyManager.Provider.RegisterGlobal<IGameplaySessionFlowContinuityService>(service);

            DebugUtility.LogVerbose(typeof(NavigationBootstrap),
                "[OBS][NavigationCore][Operational] IGameplaySessionFlowContinuityService registrado como continuity seam canonical.",
                DebugUtility.Colors.Info);
        }

        private static void EnsureGameplaySessionRunResetService()
        {
            if (DependencyManager.Provider.TryGetGlobal<IGameplaySessionRunResetService>(out var existing) && existing != null)
            {
                return;
            }

            if (!DependencyManager.Provider.TryGetGlobal<IRestartContextService>(out var restartContextService) || restartContextService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IRestartContextService ausente no DI global antes de registrar o IGameplaySessionRunResetService.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IGameNavigationService>(out var navigationService) || navigationService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IGameNavigationService ausente no DI global antes de registrar o IGameplaySessionRunResetService.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IPhaseDefinitionCatalog>(out var phaseDefinitionCatalog) || phaseDefinitionCatalog == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IPhaseDefinitionCatalog ausente no DI global antes de registrar o IGameplaySessionRunResetService.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IPhaseCatalogRuntimeStateService>(out var phaseCatalogRuntimeStateService) || phaseCatalogRuntimeStateService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IPhaseCatalogRuntimeStateService ausente no DI global antes de registrar o IGameplaySessionRunResetService.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IRunContinuationOwnershipService>(out var runContinuationOwnershipService) || runContinuationOwnershipService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IRunContinuationOwnershipService ausente no DI global antes de registrar o IGameplaySessionRunResetService.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IPostRunResultService>(out var postRunResultService) || postRunResultService == null)
            {
                throw new InvalidOperationException("[FATAL][Config][NavigationCore] IPostRunResultService ausente no DI global antes de registrar o IGameplaySessionRunResetService.");
            }

            var service = new GameplaySessionRunResetService(
                restartContextService,
                navigationService,
                phaseDefinitionCatalog,
                phaseCatalogRuntimeStateService,
                runContinuationOwnershipService,
                postRunResultService);

            DependencyManager.Provider.RegisterGlobal<IGameplaySessionRunResetService>(service);

            DebugUtility.LogVerbose(typeof(NavigationBootstrap),
                "[OBS][NavigationCore][Operational] IGameplaySessionRunResetService registrado como run-reset seam canonical.",
                DebugUtility.Colors.Info);
        }

        private static IPhaseDefinitionCatalog ResolveOptionalPhaseDefinitionCatalog(BootstrapConfigAsset bootstrapConfig)
        {
            if (bootstrapConfig?.NavigationCatalog is not GameNavigationCatalogAsset navigationCatalog)
            {
                return null;
            }

            if (!navigationCatalog.IsGameplayPhaseEnabledOrFail())
            {
                return null;
            }

            return navigationCatalog.ResolveGameplayPhaseCatalogOrFail();
        }
    }
}
