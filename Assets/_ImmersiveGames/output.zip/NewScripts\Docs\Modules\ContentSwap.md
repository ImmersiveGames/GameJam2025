# ContentSwap (Baseline 3.1)

## Status atual (2026-03-06)
- Owner can�nico de troca: `Modules/ContentSwap/Runtime/InPlaceContentSwapService.cs` via `IContentSwapChangeService`.
- Owner can�nico de contexto/estado: `Modules/ContentSwap/Runtime/ContentSwapContextService.cs` via `IContentSwapContextService`.
- Registro can�nico no pipeline: `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs` + `GlobalCompositionRoot.ContentLevels.cs`.

## Ownership final
- `InPlaceContentSwapService`: owner do fluxo de request in-place, guard de in-flight, valida��o de gate e commit.
- `ContentSwapContextService`: owner do estado `Current/Pending` e publica��o dos eventos de contexto.
- N�o-owner: SceneFlow transition/fade/loading e macro-restart orchestration.

## Integra��o com LevelFlow/WorldReset
- `Modules/WorldLifecycle/Runtime/WorldResetCommands.cs` consome `IContentSwapChangeService` no reset de n�vel (`ResetLevelAsync`).
- `Modules/LevelFlow/**` n�o chama `IContentSwapChangeService` diretamente no trilho can�nico atual; integra por contexto/eventos de n�vel.
- `Modules/SceneFlow/**` n�o possui integra��o can�nica direta com execu��o de ContentSwap (InPlace-only).

## LEGACY/Compat isolado
- Dentro de `Modules/ContentSwap/**`: nenhum arquivo classificado como `LEGACY_COMPAT` nesta etapa.
- Consumidor legado externo ao m�dulo: `Modules/Navigation/Legacy/RestartSnapshotContentSwapBridge.cs` (no-op/legacy).

## Manual confirmation required
- `Modules/ContentSwap/Dev/Runtime/ContentSwapDevBootstrapper.cs`: tamb�m instala QA por `RuntimeInitializeOnLoadMethod`, em paralelo ao installer de `GlobalCompositionRoot.DevQA.cs`.
- `Modules/ContentSwap/Dev/Bindings/ContentSwapDevContextMenu.cs`: `#if UNITY_EDITOR`; wiring real depende de contexto de editor/play mode.
## CS-1.2 (ownership/publish consolidation, behavior-preserving)

### Ownership final
- `ContentSwapContextService` é owner do estado (`Current/Pending`) e publisher único de:
  - `ContentSwapPendingSetEvent`
  - `ContentSwapPendingClearedEvent`
  - `ContentSwapCommittedEvent`
- `InPlaceContentSwapService` é executor canônico do request InPlace (validações/gates/fluxo) e delega `SetPending/TryCommitPending/ClearPending` ao context service.

### Timeline canônica
1. `RequestContentSwapInPlaceAsync(...)` (executor)
2. `SetPending(...)` (context service) -> `ContentSwapPendingSetEvent`
3. `TryCommitPending(...)` (context service) -> `ContentSwapCommittedEvent`
4. `ClearPending(...)` (context service, apenas quando aplicável) -> `ContentSwapPendingClearedEvent`

### Consumers por módulo
- `WorldLifecycle`: usa `IContentSwapChangeService` em `WorldResetCommands.ResetLevelAsync(...)`.
- `LevelFlow`: sem consumer canônico direto de ContentSwap no trilho atual.
- `Navigation (Legacy)`: `RestartSnapshotContentSwapBridge` escuta `ContentSwapCommittedEvent` (compat).

Evidência detalhada: `Docs/Reports/Audits/2026-03-06/Modules/ContentSwap-Cleanup-Audit-v2.md`.
