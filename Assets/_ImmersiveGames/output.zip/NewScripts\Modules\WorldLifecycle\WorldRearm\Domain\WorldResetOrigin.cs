namespace _ImmersiveGames.NewScripts.Modules.WorldLifecycle.WorldRearm.Domain
{
    /// <summary>
    /// Origem do request de reset.
    /// </summary>
    public enum WorldResetOrigin
    {
        Unknown = 0,
        SceneFlow = 1,
        Manual = 2
    }
}
