# DQ-1.2 - DevQA runtime cleanup audit v2 (behavior-preserving)

Date: 2026-03-06
Source of truth: local workspace files.

## Step A - Inventory evidence

### Commands executed
```text
rg -n "DevInstaller|DevBootstrap|ContextMenu|RuntimeDebugGui|MenuItem|Hotkey" Modules Infrastructure
rg -n "#if\s+UNITY_EDITOR|#if\s+DEVELOPMENT_BUILD|UNITY_EDITOR\s*\|\|\s*DEVELOPMENT_BUILD" Modules
rg -n "InstallDevQaServices|CompositionInstallStage\.DevQA|DevQaCompositionModule" Infrastructure/Composition
rg -n "QA_" Modules
```

### Inventory table
| FilePath | Tipo | Guard atual | Callsite de registro | Seguro mover? |
|---|---|---|---|---|
| `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs` | Pipeline owner | N/A | stage `CompositionInstallStage.DevQA` -> `InstallDevQaServices()` | N (owner can�nico) |
| `Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs` | Central installer registry | `InstallDevQaServices` � guardado em `UNITY_EDITOR || DEVELOPMENT_BUILD` | chamado por pipeline | N (owner can�nico) |
| `Modules/ContentSwap/Dev/Runtime/ContentSwapDevInstaller.cs` | Installer | sem `#if` local (callsite can�nico guardado) | `RegisterContentSwapQaInstaller()` | N (can�nico) |
| `Modules/ContentSwap/Dev/Runtime/ContentSwapDevBootstrapper.cs` | Bootstrap paralelo | `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | `RuntimeInitializeOnLoadMethod` (paralelo) | Y (desativar callsite paralelo; manter arquivo) |
| `Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyDevBootstrap.cs` | Hotkey installer | `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | antes: RuntimeInitialize; agora: `RegisterWorldLifecycleQaInstaller()` | N (agora can�nico via DevQA) |
| `Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyBridge.cs` | Hotkey bridge | `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | criado por `WorldResetRequestHotkeyDevBootstrap.EnsureInstalled()` | N (runtime debug ativo em dev) |
| `Modules/GameLoop/IntroStage/Dev/IntroStageRuntimeDebugGui.cs` | RuntimeDebugGui | `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | `RegisterIntroStageRuntimeDebugGui()` | N (can�nico) |
| `Modules/SceneFlow/Dev/SceneFlowDevInstaller.cs` | Installer | sem `#if` local (callsite can�nico guardado) | `RegisterSceneFlowQaInstaller()` | N (can�nico) |
| `Modules/LevelFlow/Dev/LevelFlowDevInstaller.cs` | Installer | sem `#if` local (callsite can�nico guardado) | `RegisterSceneFlowQaInstaller()` | N (can�nico) |
| `Modules/WorldLifecycle/Dev/WorldLifecycleHookLoggerA.cs` | Dev hook | sem guard expl�cito | sem callsite expl�cito em composition | N (manual confirmation required) |
| `Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs` | ContextMenu em runtime file | bloco `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | MonoBehaviour runtime | N (risco prefab/inspector) |
| `Modules/PostGame/Bindings/PostGameOverlayController.cs` | ContextMenu em runtime file | bloco `#if UNITY_EDITOR || DEVELOPMENT_BUILD` | MonoBehaviour runtime | N (risco prefab/inspector) |

## Step B - Real duplications and plan
- Duplica��o confirmada 1: `ContentSwapDevInstaller` era acionado por dois trilhos:
  - can�nico: `GlobalCompositionRoot.DevQA`
  - paralelo: `ContentSwapDevBootstrapper` (`RuntimeInitializeOnLoadMethod`)
- Escolha de owner can�nico:
  - manter `GlobalCompositionRoot.DevQA` como �nico trilho de instala��o.
- A��o aplicada:
  - `ContentSwapDevBootstrapper` mantido como LEGACY no-op com log `[OBS][LEGACY][DevQA]`.

- Paralelo fora do trilho can�nico: hotkey dev de WorldLifecycle.
- Escolha de owner can�nico:
  - mover instala��o do hotkey para `GlobalCompositionRoot.DevQA`.
- A��es aplicadas:
  - `WorldResetRequestHotkeyDevBootstrap` deixou de usar `RuntimeInitializeOnLoadMethod`.
  - `WorldResetRequestHotkeyDevBootstrap.EnsureInstalled()` passou a ser chamado por `RegisterWorldLifecycleQaInstaller()`.
  - `InstallDevQaServices()` agora chama `RegisterWorldLifecycleQaInstaller()`.

## Step C - Implemented changes
### Code changes
1. `Modules/ContentSwap/Dev/Runtime/ContentSwapDevBootstrapper.cs`
- desativado o caminho paralelo de instala��o
- mantido log observ�vel:
  - `[OBS][LEGACY][DevQA] ContentSwapDevBootstrapper desativado; instala��o can�nica via GlobalCompositionRoot.DevQA.`

2. `Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyDevBootstrap.cs`
- removido bootstrap autom�tico por `RuntimeInitializeOnLoadMethod`
- adicionado m�todo p�blico `EnsureInstalled()` para trilho can�nico DevQA
- guard consolidado para `#if UNITY_EDITOR || DEVELOPMENT_BUILD`

3. `Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyBridge.cs`
- guard consolidado para `#if UNITY_EDITOR || DEVELOPMENT_BUILD`

4. `Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs`
- adicionado `RegisterWorldLifecycleQaInstaller()`
- integra��o com `WorldResetRequestHotkeyDevBootstrap.EnsureInstalled()`

5. `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
- `InstallDevQaServices()` agora chama `RegisterWorldLifecycleQaInstaller()`

## Step D - Static validation evidence
```text
rg -n "ContentSwapDevBootstrapper|ContentSwapDevInstaller\.EnsureInstalled|WorldResetRequestHotkeyDevBootstrap|RegisterWorldLifecycleQaInstaller|RuntimeInitializeOnLoadMethod" Modules Infrastructure/Composition
rg -n "InstallDevQaServices|RegisterIntroStageQaInstaller|RegisterContentSwapQaInstaller|RegisterSceneFlowQaInstaller|RegisterWorldLifecycleQaInstaller|RegisterIntroStageRuntimeDebugGui" Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs
rg -n "#if\s+UNITY_EDITOR\s*\|\|\s*DEVELOPMENT_BUILD|NEWSCRIPTS_DEV|NEWSCRIPTS_QA" Modules/ContentSwap/Dev Modules/WorldLifecycle/Dev Modules/GameLoop/IntroStage/Dev Modules/Gameplay/Editor/RunRearm
```

Validation result:
- N�o h� mais registrador ativo paralelo para `ContentSwapDevInstaller` (bootstrap ficou no-op).
- Hotkey de WorldLifecycle est� em trilho can�nico de DevQA composition.
- Guards dos arquivos alterados ficaram consistentes com `UNITY_EDITOR || DEVELOPMENT_BUILD`.

## Remaining risks / pending manual confirmation
- `Modules/WorldLifecycle/Dev/WorldLifecycleHookLoggerA.cs`: dev-only sem guard expl�cito.
- `Modules/Gameplay/Editor/RunRearm/*`: ainda usa `NEWSCRIPTS_QA` em conjunto com guards padr�o.
- ContextMenus QA em `PauseOverlayController` e `PostGameOverlayController` permanecem em arquivos runtime por risco de wiring Unity.

## Behavior-preserving statement
- Nenhuma altera��o de contratos p�blicos.
- Nenhuma mudan�a em fluxo runtime de produ��o.
- Mudan�as limitadas ao trilho DevQA e guards de c�digo de desenvolvimento.