# SceneFlow Module Audit

## A) Scope
- Entra: `Modules/SceneFlow/**` (`Transition`, `Navigation`, `Readiness`, `Loading`, `Fade`, `Runtime`, `Dev`, `Editor`).
- EventBus inputs: completion gate consome `WorldLifecycleResetCompletedEvent` indiretamente via gate dedicado.
- Chamadas publicas: `ISceneTransitionService`, `ISceneRouteResolver`, `ISceneRouteCatalog`, `IFadeService`, `ILoadingHudService`.
- Unity callbacks: bindings de Fade/Loading/Readiness e assets de catalogo.

## B) Outputs
- Publica: `SceneTransitionStartedEvent`, `SceneTransitionFadeInCompletedEvent`, `SceneTransitionScenesReadyEvent`, `SceneTransitionBeforeFadeOutEvent`, `SceneTransitionCompletedEvent`.
- Registra servi�os de transi��o, fade, loading, route resolver e signature cache.
- Efeito em Gate/InputMode: drive principal de transi��o que dispara consumidores de gate/input.

## C) DI Registration
- `Infrastructure/Composition/GlobalCompositionRoot.SceneFlowRoutes.cs`:
  - `ISceneRouteCatalog`, `ISceneRouteResolver`.
- `Infrastructure/Composition/GlobalCompositionRoot.SceneFlowWorldLifecycle.cs`:
  - `ISceneTransitionCompletionGate`, `INavigationPolicy`, `IRouteGuard`, `ISceneTransitionService`, `ISceneFlowSignatureCache`, `IRouteResetPolicy`.
- `Infrastructure/Composition/GlobalCompositionRoot.FadeLoading.cs`:
  - `IFadeService`, `ILoadingHudService`, `LoadingHudOrchestrator`.

## D) Canonical Runtime Rail
- `SceneTransitionService.TransitionAsync` resolve rota/perfil, publica `Started`, executa `FadeIn`, carrega cenas, publica `ScenesReady`, aguarda completion gate, publica `BeforeFadeOut`, executa `FadeOut` e publica `Completed`.

## E) LEGACY/Compat
- Adaptadores fallback (`NoFadeAdapter`, `NoOpTransitionCompletionGate`) sao compat operacionais, nao trilho primario.
- Fluxo de degrade de fade em `DegradedFadeService` para editor/dev.

## F) Redundancy Candidates
- `Modules/SceneFlow/Runtime/SceneFlowSignatureCache.cs` e dedupe adicional em `SceneTransitionService` e `LoadingHudOrchestrator`; risco medio de regras diferentes.
- `Modules/SceneFlow/Readiness/Runtime/GameReadinessService.cs` e `Modules/InputModes/Interop/SceneFlowInputModeBridge.cs` consomem mesmos eventos-chave; risco medio.
- `Modules/SceneFlow/Dev/SceneFlowDevContextMenu.cs` possui fluxos QA que sobrepoem comandos de runtime; risco baixo.

## G) Deletion/Merge Plan (DOC-ONLY)
- Centralizar politica de dedupe de assinatura com owner unico e consumidores read-only.
- Reduzir sobreposicao entre readiness/input bridge na resposta a `Started/Completed`.
- Manter adaptadores fallback explicitamente fora do trilho can�nico de producao.

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Modules/SceneFlow/Transition/Runtime/SceneTransitionService.cs | Runtime | `TransitionAsync` | N/A | `SceneTransitionStartedEvent`, `SceneTransitionCompletedEvent` e fases | `ISceneTransitionService` | Canon (publisher principal) |
| Modules/SceneFlow/Transition/Runtime/MacroLevelPrepareCompletionGate.cs | Runtime | `AwaitBeforeFadeOutAsync` | `WorldLifecycleResetCompletedEvent` (via inner gate) | N/A | `ISceneTransitionCompletionGate` | Canon |
| Modules/SceneFlow/Runtime/SceneFlowSignatureCache.cs | Runtime | `TryGetLast`, dispose | `SceneTransitionStartedEvent`, `SceneTransitionCompletedEvent` | N/A | `ISceneFlowSignatureCache` | Canon + dedupe overlap |
| Modules/SceneFlow/Loading/Runtime/LoadingHudOrchestrator.cs | Runtime | ctor/dispose | `SceneTransitionStartedEvent`, `SceneTransitionCompletedEvent` + fases | N/A | concrete orchestrator | Canon + dedupe overlap |
| Modules/SceneFlow/Readiness/Runtime/GameReadinessService.cs | Runtime | ctor/dispose | `SceneTransitionStartedEvent`, `SceneTransitionScenesReadyEvent`, `SceneTransitionCompletedEvent` | `ReadinessChangedEvent` | concrete service | Canon |
| Modules/SceneFlow/Fade/Runtime/FadeService.cs | Runtime | `EnsureReadyAsync`, `FadeInAsync`, `FadeOutAsync` | N/A | N/A | `IFadeService` | Canon |
| Modules/SceneFlow/Fade/Runtime/DegradedFadeService.cs | Runtime | `FadeInAsync`, `FadeOutAsync` | N/A | N/A | `IFadeService` (fallback) | Compat/Fallback |