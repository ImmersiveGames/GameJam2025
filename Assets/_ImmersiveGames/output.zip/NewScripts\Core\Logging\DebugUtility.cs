﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Object = UnityEngine.Object;

namespace _ImmersiveGames.NewScripts.Core.Logging
{
    public enum DebugLevel
    {
        None = 0,
        Error = 1,
        Warning = 2,
        Logs = 3,
        Verbose = 4
    }

    public static class DebugUtility
    {
        private static bool _globalDebugEnabled = true;
        private static bool _verboseLoggingEnabled = true;
        private static bool _logFallbacks = true;
        private static bool _repeatedCallVerboseEnabled = true;
        private static DebugLevel _defaultDebugLevel = DebugLevel.Logs;
        private static string _lastPolicyKey;
        private static int _lastPolicyFrame = -1;
        private static int _policyApplyTick;
        private static bool _hasAppliedPolicy;
        private static bool _lastAppliedGlobalDebugEnabled;
        private static bool _lastAppliedVerboseEnabled;
        private static bool _lastAppliedFallbacksEnabled;
        private static bool _lastAppliedRepeatedVerboseEnabled;
        private static DebugLevel _lastAppliedDefaultLevel = DebugLevel.Logs;
        private static string _lastAppliedSource;

        private static readonly Dictionary<Type, DebugLevel> _scriptDebugLevels = new();
        private static readonly Dictionary<object, DebugLevel> _localLevels = new();
        private static readonly Dictionary<Type, DebugLevel> _attributeLevels = new();
        private static readonly HashSet<Type> _disabledVerboseTypes = new();

        // Tracking por frame (limpamos quando o frame muda).
        private static readonly HashSet<(string key, int frame)> _callTracker = new();
        private static readonly HashSet<(string key, int frame)> _repeatedCallTracker = new();
        private static int _lastTrackedFrame = -1;

        private static readonly StringBuilder _stringBuilder = new(256);
        private static readonly Dictionary<string, string> _messagePool = new();

        private const string RepeatedCallColor = "#FFD54F";
        private const string AlertIcon = "âš ï¸";

        public static class Colors
        {
            public const string CrucialInfo = "#00BCD4";
            public const string Info = "#A8DEED";
            public const string Success = "#4CAF50";
            public const string Warning = "yellow";
            public const string Error = "red";
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        public static void Initialize()
        {
#if NEWSCRIPTS_MODE
            Debug.Log("NEWSCRIPTS_MODE ativo: DebugUtility.Initialize executando reset de estado.");
#endif
            _scriptDebugLevels.Clear();
            _localLevels.Clear();
            _attributeLevels.Clear();
            _disabledVerboseTypes.Clear();

            _callTracker.Clear();
            _repeatedCallTracker.Clear();
            _lastTrackedFrame = -1;
            _lastPolicyFrame = -1;
            _lastPolicyKey = null;
            _policyApplyTick = 0;
            _hasAppliedPolicy = false;
            _lastAppliedGlobalDebugEnabled = true;
            _lastAppliedVerboseEnabled = Application.isEditor;
            _lastAppliedFallbacksEnabled = Application.isEditor;
            _lastAppliedRepeatedVerboseEnabled = true;
            _lastAppliedDefaultLevel = DebugLevel.Logs;
            _lastAppliedSource = null;

            _messagePool.Clear();

            ApplyLoggingPolicyInternal(
                globalDebugEnabled: true,
                verboseEnabled: Application.isEditor,
                fallbacksEnabled: Application.isEditor,
                repeatedVerboseEnabled: true,
                defaultLevel: DebugLevel.Logs,
                source: "EarlyDefault");

            LogInternal("DebugUtility inicializado antes de todos os sistemas.");
        }

        #region ConfiguraÃ§Ãµes
        public static bool IsGlobalDebugEnabled => _globalDebugEnabled;
        public static bool IsVerboseLoggingEnabled => _verboseLoggingEnabled;
        public static bool IsFallbacksEnabled => _logFallbacks;
        public static bool IsRepeatedCallVerboseEnabled => _repeatedCallVerboseEnabled;
        public static DebugLevel DefaultDebugLevel => _defaultDebugLevel;

        public static void SetGlobalDebugState(bool enabled) => _globalDebugEnabled = enabled;
        public static void SetVerboseLogging(bool enabled) => _verboseLoggingEnabled = enabled;
        public static void SetLogFallbacks(bool enabled) => _logFallbacks = enabled;
        public static void SetRepeatedCallVerbose(bool enabled) => _repeatedCallVerboseEnabled = enabled;
        public static bool GetRepeatedCallVerbose() => _repeatedCallVerboseEnabled;

        public static void DisableVerboseForType(Type type) => _disabledVerboseTypes.Add(type);
        public static void EnableVerboseForType(Type type) => _disabledVerboseTypes.Remove(type);

        public static void SetDefaultDebugLevel(DebugLevel level) => _defaultDebugLevel = level;
        public static void RegisterScriptDebugLevel(Type type, DebugLevel level) => _scriptDebugLevels[type] = level;
        public static void SetLocalDebugLevel(object instance, DebugLevel level) => _localLevels[instance] = level;

        public static void ApplyLoggingPolicyFromBootstrap(
            DebugLevel defaultLevel,
            bool verboseEnabled,
            bool fallbacksEnabled,
            bool globalDebugEnabled = true,
            bool repeatedVerboseEnabled = true)
        {
            ApplyLoggingPolicyInternal(
                globalDebugEnabled,
                verboseEnabled,
                fallbacksEnabled,
                repeatedVerboseEnabled,
                defaultLevel,
                "BootstrapPolicy");
        }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        public static async void Dev_ForceReapplyLastLoggingPolicyForEvidence()
        {
            if (!_hasAppliedPolicy)
            {
                LogRuntimeModeObs("[OBS][RuntimeMode] LoggingPolicyEvidenceSkipped reason='no_last_policy'");
                return;
            }

            ApplyLoggingPolicyInternal(
                _lastAppliedGlobalDebugEnabled,
                _lastAppliedVerboseEnabled,
                _lastAppliedFallbacksEnabled,
                _lastAppliedRepeatedVerboseEnabled,
                _lastAppliedDefaultLevel,
                _lastAppliedSource);

            await Task.Yield();

            ApplyLoggingPolicyInternal(
                _lastAppliedGlobalDebugEnabled,
                _lastAppliedVerboseEnabled,
                _lastAppliedFallbacksEnabled,
                _lastAppliedRepeatedVerboseEnabled,
                _lastAppliedDefaultLevel,
                _lastAppliedSource);
        }
#endif
        #endregion

        #region Log estÃ¡tico por Type
        public static void Log(Type type, string message, string color = null, Object context = null)
        {
            if (!ShouldLog(type, null, DebugLevel.Logs))
            {
                return;
            }
            Debug.Log(ApplyColor(BuildLogMessage("INFO", type, message), color), context);
        }

        public static void LogWarning(Type type, string message, Object context = null)
        {
            if (!ShouldLog(type, null, DebugLevel.Warning))
            {
                return;
            }
            Debug.LogWarning(BuildLogMessage("WARNING", type, message), context);
        }

        public static void LogError(Type type, string message, Object context = null)
        {
            if (!ShouldLog(type, null, DebugLevel.Error))
            {
                return;
            }
            Debug.LogError(BuildLogMessage("ERROR", type, message), context);
        }

        public static void LogVerbose(Type type, string message, string color = null, Object context = null, bool isFallback = false, bool deduplicate = false)
        {
            if (!_verboseLoggingEnabled || _disabledVerboseTypes.Contains(type) || (isFallback && !_logFallbacks) || !ShouldLog(type, null, DebugLevel.Verbose))
            {
                return;
            }

            if (!TrackCall(type, message, context, deduplicate))
            {
                return;
            }
            Debug.Log(ApplyColor(GetPooledMessage(type, message, isFallback), color), context);
        }
        #endregion

        #region Log genÃ©rico por tipo (T)
        public static void Log<T>(string message, string color = null, Object context = null, T instance = null) where T : class
        {
            var type = typeof(T);
            if (!ShouldLog(type, instance, DebugLevel.Logs))
            {
                return;
            }
            Debug.Log(ApplyColor(BuildLogMessage("INFO", type, message), color), context);
        }

        public static void LogWarning<T>(string message, Object context = null, T instance = null) where T : class
        {
            var type = typeof(T);
            if (!ShouldLog(type, instance, DebugLevel.Warning))
            {
                return;
            }
            Debug.LogWarning(BuildLogMessage("WARNING", type, message), context);
        }

        public static void LogError<T>(string message, Object context = null, T instance = null) where T : class
        {
            var type = typeof(T);
            if (!ShouldLog(type, instance, DebugLevel.Error))
            {
                return;
            }
            Debug.LogError(BuildLogMessage("ERROR", type, message), context);
        }

        public static void LogVerbose<T>(string message, string color = null, Object context = null, T instance = null, bool isFallback = false, bool deduplicate = false) where T : class
        {
            var type = typeof(T);
            if (!_verboseLoggingEnabled || _disabledVerboseTypes.Contains(type) || (isFallback && !_logFallbacks) || !ShouldLog(type, instance, DebugLevel.Verbose))
            {
                return;
            }

            if (!TrackCall(type, message, context, deduplicate))
            {
                return;
            }
            Debug.Log(ApplyColor(GetPooledMessage(type, message, isFallback), color), context);
        }
        #endregion

        #region Helpers Internos
        private static bool ShouldLog(Type type, object instance, DebugLevel messageLevel)
        {
            if (!_globalDebugEnabled)
            {
                return false;
            }

            if (instance != null && _localLevels.TryGetValue(instance, out var localLevel))
            {
                return (int)localLevel >= (int)messageLevel;
            }

            if (type == null)
            {
                return (int)_defaultDebugLevel >= (int)messageLevel;
            }

            if (_scriptDebugLevels.TryGetValue(type, out var scriptLevel))
            {
                return (int)scriptLevel >= (int)messageLevel;
            }

            if (_attributeLevels.TryGetValue(type, out var attributeLevel))
            {
                return (int)attributeLevel >= (int)messageLevel;
            }

            attributeLevel = Attribute.GetCustomAttribute(type, typeof(DebugLevelAttribute)) is DebugLevelAttribute attr
                ? attr.Level
                : _defaultDebugLevel;

            _attributeLevels[type] = attributeLevel;
            return (int)attributeLevel >= (int)messageLevel;
        }

        private static string BuildLogMessage(string level, Type type, string message)
        {
            _stringBuilder.Clear();
            _stringBuilder.Append('[').Append(level).Append("] [").Append(type.Name).Append("] ").Append(message);
            return _stringBuilder.ToString();
        }

        private static string GetPooledMessage(Type type, string message, bool isFallback)
        {
            string key = $"{type.Name}:{message}:{isFallback}";
            if (!_messagePool.TryGetValue(key, out string baseMessage))
            {
                _stringBuilder.Clear();
                _stringBuilder.Append("[VERBOSE] [").Append(type.Name).Append("] ").Append(message);
                if (isFallback)
                {
                    _stringBuilder.Append(" (fallback)");
                }
                baseMessage = _stringBuilder.ToString();
                _messagePool[key] = baseMessage;
            }

            _stringBuilder.Clear();
            _stringBuilder.Append(baseMessage)
                          .Append(" (@ ").Append(Time.realtimeSinceStartup.ToString("F2")).Append("s)");
            return _stringBuilder.ToString();
        }

        private static string ApplyColor(string message, string color)
        {
            return string.IsNullOrEmpty(color) ? message : $"<color={color}>{message}</color>";
        }

        private static void ApplyLoggingPolicyInternal(
            bool globalDebugEnabled,
            bool verboseEnabled,
            bool fallbacksEnabled,
            bool repeatedVerboseEnabled,
            DebugLevel defaultLevel,
            string source)
        {
            string policyKey = BuildLoggingPolicyKey(
                GetBuildVariant(),
                GetNewscriptsModeState(),
                globalDebugEnabled,
                verboseEnabled,
                defaultLevel,
                repeatedVerboseEnabled,
                fallbacksEnabled,
                source);
            int policyFrame = GetPolicyFrame();

            if (policyFrame == _lastPolicyFrame && string.Equals(policyKey, _lastPolicyKey, StringComparison.Ordinal))
            {
                LogRuntimeModeObs($"[OBS][RuntimeMode] LoggingPolicyApplySkipped reason='dedupe_same_frame' key='{policyKey}'");
                return;
            }

            if (string.Equals(policyKey, _lastPolicyKey, StringComparison.Ordinal))
            {
                LogRuntimeModeObs($"[OBS][RuntimeMode] LoggingPolicyApplySkipped reason='dedupe_same_key' key='{policyKey}'");
                return;
            }

            _globalDebugEnabled = globalDebugEnabled;
            _verboseLoggingEnabled = verboseEnabled;
            _logFallbacks = fallbacksEnabled;
            _repeatedCallVerboseEnabled = repeatedVerboseEnabled;
            _defaultDebugLevel = defaultLevel;

            _lastPolicyKey = policyKey;
            _lastPolicyFrame = policyFrame;
            _hasAppliedPolicy = true;
            _lastAppliedGlobalDebugEnabled = globalDebugEnabled;
            _lastAppliedVerboseEnabled = verboseEnabled;
            _lastAppliedFallbacksEnabled = fallbacksEnabled;
            _lastAppliedRepeatedVerboseEnabled = repeatedVerboseEnabled;
            _lastAppliedDefaultLevel = defaultLevel;
            _lastAppliedSource = source;

            LogRuntimeModeObs($"[OBS][RuntimeMode] LoggingPolicyApplied source='{source}' key='{policyKey}'");
        }

        // policyKey e um contrato estavel/deterministico usado para dedupe e evidencia.
        private static string BuildLoggingPolicyKey(
            string buildVariant,
            string newscriptsMode,
            bool globalDebugEnabled,
            bool verboseEnabled,
            DebugLevel defaultLevel,
            bool repeatedVerboseEnabled,
            bool fallbacksEnabled,
            string source)
        {
            var builder = new StringBuilder(128);
            builder.Append(buildVariant)
                   .Append('|').Append(newscriptsMode)
                   .Append("|global=").Append(globalDebugEnabled)
                   .Append(";verbose=").Append(verboseEnabled)
                   .Append(";default=").Append(defaultLevel)
                   .Append(";repeated=").Append(repeatedVerboseEnabled)
                   .Append("|fallbacks=").Append(fallbacksEnabled)
                   .Append('|').Append(source);
            return builder.ToString();
        }
        private static int GetPolicyFrame()
        {
            int frame = Time.frameCount;
            if (frame >= 0)
            {
                return frame;
            }

            _policyApplyTick++;
            return -_policyApplyTick;
        }

        private static string GetBuildVariant()
        {
#if UNITY_EDITOR
#if DEVELOPMENT_BUILD
            return "DevBuild";
#else
            return "Editor";
#endif
#else
            return "Release";
#endif
        }

        private static string GetNewscriptsModeState()
        {
#if NEWSCRIPTS_MODE
            return "Enabled";
#else
            return "Disabled";
#endif
        }

        private static void LogRuntimeModeObs(string message)
        {
            Debug.Log(ApplyColor(BuildLogMessage("INFO", typeof(DebugUtility), message), Colors.Info));
        }
        private static void LogInternal(string message, Object context = null)
        {
            if (!ShouldLog(null, null, DebugLevel.Logs))
            {
                return;
            }
            Debug.Log(ApplyColor(BuildLogMessage("INFO", typeof(DebugUtility), message), null), context);
        }

        private static bool TrackCall(Type type, string message, Object context, bool deduplicate)
        {
            int frame = Time.frameCount;

            // Limpamos 1x por frame (mais barato do que RemoveWhere em toda chamada).
            if (_lastTrackedFrame != frame)
            {
                _callTracker.Clear();
                _repeatedCallTracker.Clear();
                _lastTrackedFrame = frame;
            }

            int contextId = context != null ? context.GetInstanceID() : 0;
            string key = $"{type.Name}:{message}:ctx={contextId}";
            var trackerKey = (key, frame);

            bool isRepeat = _callTracker.Contains(trackerKey);

            if (isRepeat)
            {
                if (!deduplicate && _repeatedCallVerboseEnabled)
                {
                    if (_repeatedCallTracker.Add(trackerKey) && !ShouldSuppressRepeatedCallWarning(type, message))
                    {
                        LogRepeatedCallVerbose(type, message, frame);
                    }
                }

                return !deduplicate;
            }

            _callTracker.Add(trackerKey);
            return true;
        }

        private static void LogRepeatedCallVerbose(Type type, string message, int frame)
        {
            if (!_verboseLoggingEnabled || !_repeatedCallVerboseEnabled)
            {
                return;
            }
            if (type != null && _disabledVerboseTypes.Contains(type))
            {
                return;
            }
            if (!ShouldLog(type, null, DebugLevel.Verbose))
            {
                return;
            }

            _stringBuilder.Clear();
            _stringBuilder.Append("[DebugUtility] ")
                          .Append(AlertIcon)
                          .Append(" Chamada repetida no frame ")
                          .Append(frame)
                          .Append(": [")
                          .Append(type?.Name ?? nameof(DebugUtility))
                          .Append("] ")
                          .Append(message);

            Debug.Log(ApplyColor(_stringBuilder.ToString(), RepeatedCallColor));
        }

        private static bool ShouldSuppressRepeatedCallWarning(Type type, string message)
        {
            string typeName = type?.Name ?? string.Empty;
            if (!string.Equals(typeName, "GameNavigationCatalogAsset", StringComparison.Ordinal) &&
                !string.Equals(typeName, "SceneRouteCatalogAsset", StringComparison.Ordinal))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(message))
            {
                return false;
            }

            // Suprime apenas spam de observabilidade idempotente de catÃ¡logo.
            return message.Contains("[OBS][SceneFlow] RouteResolvedVia=AssetRef", StringComparison.Ordinal) ||
                   message.Contains("[OBS][Config] RouteResolvedVia=AssetRef", StringComparison.Ordinal) ||
                   message.Contains("[OBS][Config] SceneRouteCatalogBuild", StringComparison.Ordinal);
        }
        #endregion
    }
}






