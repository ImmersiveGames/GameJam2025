# Infra Composition Cleanup v1 (2026-03-06)

## Scope
- Alteracoes realizadas apenas em:
  - `Infrastructure/Composition/GlobalCompositionRoot.Helpers.cs`
  - `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
  - `Infrastructure/Composition/GlobalCompositionRoot.NavigationInputModes.cs`
- Nenhuma alteracao em `Modules/**`, assets (`.asset/.prefab/.unity`) ou outros paths de runtime.

## 1) Helpers inventory and consolidation

### Before
- `RegisterIfMissing<T>(Func<T> factory)` em `GlobalCompositionRoot.Helpers.cs`
- `RegisterGlobalIfMissing<T>(T service, string label)` em `GlobalCompositionRoot.NavigationInputModes.cs`
- Varios metodos `Register*Bridge` com mesmo padrao manual:
  - `TryGetGlobal` -> `new` -> `RegisterGlobal` -> `LogVerbose`
- Resolucao de gate repetida com `TryGetGlobal<ISimulationGateService>` em multiplos pontos.

### After
- **Helper canonico idempotente** mantido em `GlobalCompositionRoot.Helpers.cs`:
  - `RegisterIfMissing<T>(Func<T> factory)`
  - `RegisterIfMissing<T>(Func<T> factory, string alreadyRegisteredMessage, string registeredMessage)`
- Novo helper de resolucao reutilizavel:
  - `ResolveSimulationGateServiceOrNull()`
- `RegisterGlobalIfMissing<T>(...)` removido (consolidado no helper canonico).
- `Register*Bridge` prioritarios migrados para o helper canonico em `NavigationInputModes.cs`:
  - `RegisterExitToMenuNavigationBridge`
  - `RegisterMacroRestartCoordinator`
  - `RegisterLevelSelectedRestartSnapshotBridge`
  - `RegisterInputModeSceneFlowBridge`
  - `RegisterLevelStageOrchestrator`

## 2) Callsites altered (file + method)
- `Infrastructure/Composition/GlobalCompositionRoot.NavigationInputModes.cs`
  - `RegisterGameNavigationService`
    - de: `RegisterGlobalIfMissing<ITransitionStyleCatalog>(...)`
    - para: `RegisterIfMissing<ITransitionStyleCatalog>(..., alreadyMessage, null)`
  - `RegisterExitToMenuNavigationBridge` -> usa helper canonico
  - `RegisterMacroRestartCoordinator` -> usa helper canonico
  - `RegisterLevelSelectedRestartSnapshotBridge` -> usa helper canonico
  - `RegisterInputModeSceneFlowBridge` -> usa helper canonico
  - `RegisterLevelStageOrchestrator` -> usa helper canonico
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
  - `RegisterEssentialServicesOnly`
    - de: `TryGetGlobal<ISimulationGateService>(...)`
    - para: `ResolveSimulationGateServiceOrNull()`
  - `InstallWorldLifecycleServices`
    - de: `TryGetGlobal<ISimulationGateService>(...)`
    - para: `ResolveSimulationGateServiceOrNull()`
- `Infrastructure/Composition/GlobalCompositionRoot.Helpers.cs`
  - adicionado overload canonico de `RegisterIfMissing`
  - adicionado `ResolveSimulationGateServiceOrNull`

## 3) Removed items
- `RegisterGlobalIfMissing<T>(T service, string label)` (NavigationInputModes)
  - Motivo: duplicacao semantica de "check then register" ja coberta por helper canonico.
- `RegisterRestartSnapshotContentSwapBridge()` (NavigationInputModes)
  - Motivo: stub legacy sem callsite no pipeline de Infrastructure/Composition (ruido sem efeito no comportamento atual).

## 4) Static checklist - behavior preserved
- [x] Ordem de stages em `GlobalCompositionRoot.Pipeline.cs` preservada.
- [x] Lista de modulos em `InstallCompositionModules()` nao alterada.
- [x] Conjunto final de servicos registrados no trilho can�nico preservado.
- [x] Logs de observabilidade/erro (`[OBS]`, `[FATAL]`, warnings existentes nos fluxos principais) preservados semanticamente.
- [x] Nenhum fallback silencioso novo foi introduzido; fail-fast continua nos pontos de config obrigatoria.
- [x] Nenhuma alteracao em `Modules/**`.

## 5) Validation commands and results (static)
- Helpers redundantes removidos:
  - comando: `rg -n "RegisterGlobalIfMissing|RegisterRestartSnapshotContentSwapBridge" Infrastructure/Composition`
  - resultado: `0 matches`
- Helper canonico unico presente:
  - comando: `rg -n "private static void RegisterIfMissing<|private static void RegisterIfMissing\(" Infrastructure/Composition/GlobalCompositionRoot.Helpers.cs`
  - resultado: 2 overloads no mesmo arquivo (canonico)
- Pipeline sem duplicacao de chamada `Register*` (exceto helper generico reutilizado):
  - comando: agrupamento de invocacoes `Register*` em `GlobalCompositionRoot.Pipeline.cs`
  - resultado: apenas `RegisterIfMissing` aparece 2x; demais chamadas `Register*` aparecem 1x.

## 6) Notes
- Cleanup focado em higiene de Infrastructure/Composition; nenhum contrato publico de modulo foi alterado.

## 7) IC-1.2a applied (behavior-preserving)
- Data: 2026-03-06
- Objetivo aplicado: split estrutural do hotspot `GlobalCompositionRoot.NavigationInputModes.cs` em parciais por dominio, sem mudanca intencional de comportamento.
- Metodos movidos:
  - `Infrastructure/Composition/GlobalCompositionRoot.InputModes.cs`
    - `RegisterInputModesFromRuntimeConfig`
    - `ReportInputModesDegraded`
    - `RegisterInputModeSceneFlowBridge`
  - `Infrastructure/Composition/GlobalCompositionRoot.Navigation.cs`
    - `ResolveOrRegisterRestartContextService`
    - `RegisterGameNavigationService`
    - `RegisterExitToMenuNavigationBridge`
    - `RegisterMacroRestartCoordinator`
    - `RegisterLevelSelectedRestartSnapshotBridge`
  - `Infrastructure/Composition/GlobalCompositionRoot.LevelFlow.cs`
    - `RegisterLevelsServices`
    - `RegisterLevelStageOrchestrator`
- Wrapper legado:
  - `Infrastructure/Composition/GlobalCompositionRoot.NavigationInputModes.cs` mantido leve, sem logica duplicada.
- Garantias:
  - Behavior-preserving: metodos mantidos com mesmo nome, assinatura, visibilidade e fluxo fail-fast.
  - Ordem e callsites do pipeline preservados.
- Comandos `rg` usados na verificacao:
  - `rg --line-number "private static (void|IRestartContextService) (RegisterInputModesFromRuntimeConfig|ReportInputModesDegraded|ResolveOrRegisterRestartContextService|RegisterGameNavigationService|RegisterLevelsServices|RegisterExitToMenuNavigationBridge|RegisterMacroRestartCoordinator|RegisterLevelSelectedRestartSnapshotBridge|RegisterInputModeSceneFlowBridge|RegisterLevelStageOrchestrator)\(" Infrastructure/Composition`
  - `rg --line-number "RegisterInputModesFromRuntimeConfig\(|RegisterGameNavigationService\(|RegisterLevelsServices\(|RegisterExitToMenuNavigationBridge\(|RegisterMacroRestartCoordinator\(|RegisterLevelSelectedRestartSnapshotBridge\(|RegisterInputModeSceneFlowBridge\(|RegisterLevelStageOrchestrator\(" Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
  - `rg --line-number "RegisterLevelsServices\(|installLevels:\s*RegisterLevelsServices" Infrastructure/Composition`

## 8) IC-1.2b applied (behavior-preserving)
- Data: 2026-03-06
- Escopo: split por dominio em `Infrastructure/Composition/**` usando apenas o workspace local como fonte da verdade.

### Arquivos criados/modificados
- Criado: `Infrastructure/Composition/GlobalCompositionRoot.SceneFlow.cs`
- Criado: `Infrastructure/Composition/GlobalCompositionRoot.WorldLifecycle.cs`
- Modificado: `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
- Modificado: `Infrastructure/Composition/GlobalCompositionRoot.SceneFlowWorldLifecycle.cs` (wrapper leve)
- Modificado: `Infrastructure/Composition/GlobalCompositionRoot.FadeLoading.cs` (wrapper leve)

### Metodos movidos por arquivo
- Para `GlobalCompositionRoot.SceneFlow.cs`:
  - `InstallSceneFlowServices`
  - `RegisterSceneFlowNative`
  - `RegisterSceneFlowSignatureCache`
  - `RegisterSceneFlowRouteResetPolicy`
  - `ResolveOrRegisterRouteResolverRequired`
  - `RegisterSceneFlowFadeModule`
  - `TryResolveFadeSceneName`
  - `TryValidateFadeSceneInBuildSettings`
  - `TryResolveBuildSettingsScenePath`
  - `PreloadFadeSceneAsync`
  - `HandleFadeBootstrapFailure`
  - `HandleFadeRuntimeFailure`
  - `ShouldDegradeFadeInRuntime`
  - `RegisterSceneFlowLoadingIfAvailable`
- Para `GlobalCompositionRoot.WorldLifecycle.cs`:
  - `InstallWorldLifecycleServices`

### Validacoes `rg` (static)
- Unicidade de metodos movidos:
  - comando: `rg --line-number "^\s*private\s+static\s+.*\b(InstallSceneFlowServices|RegisterSceneFlowNative|RegisterSceneFlowSignatureCache|RegisterSceneFlowRouteResetPolicy|ResolveOrRegisterRouteResolverRequired|RegisterSceneFlowFadeModule|TryResolveFadeSceneName|TryValidateFadeSceneInBuildSettings|TryResolveBuildSettingsScenePath|PreloadFadeSceneAsync|HandleFadeBootstrapFailure|HandleFadeRuntimeFailure|ShouldDegradeFadeInRuntime|RegisterSceneFlowLoadingIfAvailable|InstallWorldLifecycleServices)\b" Infrastructure/Composition`
  - resultado: 15 metodos, 1 ocorrencia cada.
- Callsites/pipeline preservados:
  - comando: `rg --line-number "RegisterEssentialServicesOnly|InstallSceneFlowServices|InstallWorldLifecycleServices|InstallCompositionModules" Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`
  - resultado: nomes mantidos; `InstallSceneFlowServices` e `InstallWorldLifecycleServices` continuam referenciados no `GlobalCompositionContext`; ordem de `RegisterEssentialServicesOnly()` inalterada.
- Dependencia legacy nao reintroduzida em callsites canonicos:
  - comando: `rg --line-number "RegisterRestartSnapshotContentSwapBridge|RestartNavigationBridge|RestartSnapshotContentSwapBridge" Infrastructure/Composition Modules`
  - resultado: apenas declaracoes em `Modules/Navigation/Legacy/*`; nenhum callsite canonico em `Infrastructure/Composition`.
  - comando adicional: `rg --line-number "new\s+(RestartNavigationBridge|RestartSnapshotContentSwapBridge)|RegisterIfMissing\s*\(\s*\(\)\s*=>\s*new\s+(RestartNavigationBridge|RestartSnapshotContentSwapBridge)" Infrastructure/Composition Modules`
  - resultado: `0 matches`.

### Garantia de comportamento
- Split estrutural apenas por realocacao de metodos.
- Sem mudanca de assinatura/visibilidade/logs canonicamente existentes.
- Sem mudanca de ordem de pipeline, `#if` ou callsites do pipeline.
