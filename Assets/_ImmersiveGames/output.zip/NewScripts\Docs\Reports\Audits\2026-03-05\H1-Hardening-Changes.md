# H1 Hardening Changes � anti-retrocesso rota/level

Data: 2026-03-05
Escopo: `Assets/_ImmersiveGames/NewScripts/**`
Base: invent�rio H0 + hardening solicitado (sem pipeline paralelo).

## Resumo

Este pacote H1 endurece caminhos LEGACY/COMPAT/FALLBACK em runtime para impedir regress�o de mistura rota/level em produ��o.

- Em **Strict/Production**: caminhos legados cr�ticos fazem fail-fast com anchor `[FATAL][H1]`.
- Em **DEV** (`UNITY_EDITOR`/`DEVELOPMENT_BUILD`/`DebugBuild`): escape hatch permanece apenas para caminhos `[WARN][COMPAT]` e `[WARN][DEGRADED]` previstos.
- APIs de navega��o `[Obsolete]` ficam bloqueadas em todos os ambientes (DEV e Strict/Production).

---

## Mudan�as por arquivo

## 1) Core

### `Core/Logging/HardFailFastH1.cs`

#### A) helper �nico de fail-fast H1
- Novo helper centralizado para os fail-fast H1 deste pacote.
- Comportamento unificado:
  - loga `[FATAL][H1] ...`
  - em `UNITY_EDITOR`: `UnityEditor.EditorApplication.isPlaying = false`
  - em player: `Application.Quit()`
  - lan�a `InvalidOperationException`

---

## 2) Navigation

### `Modules/Navigation/GameNavigationService.cs`

#### B) `RestartAsync` � bloqueio de `legacy_route_only`
- **Strict/Production:** fail-fast `[FATAL][H1]` quando branch legacy seria usado.
- **DEV:** fallback mantido com `[WARN][COMPAT][NAV]` + contador (`_compatRestartLegacyRouteOnlyCount`).

#### C) `StartGameplayRouteAsync` � fallback endurecido
- **Strict/Production:** fallback `last_level_id` gera fail-fast `[FATAL][H1]`.
- **DEV:** fallback permitido com `[WARN][COMPAT][NAV]` + contador (`_compatStartGameplayRouteFallbackCount`).

#### D) APIs `[Obsolete]`
- M�todos:
  - `RequestMenuAsync`
  - `RequestGameplayAsync`
  - `StartGameplayLegacy(LevelId, ...)`
  - `NavigateAsync(string, ...)`
- **Strict/Production e DEV:** bloqueio com `[FATAL][H1]`.
- Warn 1x por sess�o `[WARN][LEGACY_API_USED]` (`_legacyApiWarningEmitted`) � emitido antes do fail-fast para diagn�stico.

### `Modules/Navigation/RestartNavigationBridge.cs`

#### E) fallback operacional do bridge
- **Strict/Production:** fail-fast `[FATAL][H1][NAV][DI]` e sem fallback.
- **DEV:** fallback mantido com `[WARN][COMPAT][NAV]` e recomenda��o de corrigir DI.

---

## 3) SceneFlow

### `Modules/SceneFlow/Transition/Runtime/MacroLevelPrepareCompletionGate.cs`

#### F) skip silencioso de LevelPrepare
- **Strict/Production:** fail-fast `[FATAL][H1]` (n�o segue sem LevelPrepare).
- **DEV:** skip permitido apenas com `[WARN][DEGRADED][SceneFlow]` + recomenda��o de corre��o.

---

## 4) WorldLifecycle

### `Modules/WorldLifecycle/Runtime/WorldLifecycleSceneFlowResetDriver.cs`

#### G) reset required sem swallow silencioso
- `ExecuteResetWhenRequiredAsync` n�o engole mais falha de `WorldResetService.TriggerResetAsync`.
- Se `TriggerResetAsync` falhar:
  - **Strict/Production:** fail-fast com `[FATAL][H1][WorldLifecycle]`.
  - **DEV:** registra `[WARN][DEGRADED][WorldLifecycle]` e retorna `shouldPublishCompletion=true`.
- Se `WorldResetService` faltar:
  - **Strict/Production:** fail-fast com `[FATAL][H1][WorldLifecycle]`.
  - **DEV:** fallback degradado com `[WARN][DEGRADED][WorldLifecycle]` e completion publish.
- Garantia: reset required sempre termina em completion (service/fallback DEV) ou fail-fast em Strict.

---

## Comportamento final (matriz)

| Cen�rio | Strict/Production | DEV |
|---|---|---|
| Restart via `legacy_route_only` | Bloqueado (`[FATAL][H1]`) | Permitido com `[WARN][COMPAT][NAV]` |
| `StartGameplayRouteAsync` com `last_level_id` fallback | Bloqueado (`[FATAL][H1]`) | Permitido com `[WARN][COMPAT][NAV]` |
| Restart bridge sem `ILevelFlowRuntimeService` | Bloqueado (`[FATAL][H1][NAV][DI]`) | Permitido com `[WARN][COMPAT][NAV]` |
| `LevelPrepare` skip por DI/servi�o ausente | Bloqueado (`[FATAL][H1]`) | Permitido com `[WARN][DEGRADED][SceneFlow]` |
| Reset required sem `WorldResetService` | Bloqueado (`[FATAL][H1][WorldLifecycle]`) | Permitido com `[WARN][DEGRADED][WorldLifecycle]` |
| Uso de API `[Obsolete]` de navega��o | Bloqueado (`[FATAL][H1]`) | Bloqueado (`[FATAL][H1]`) com warn 1x (`[WARN][LEGACY_API_USED]`) |
| Fail-fast H1 (helper �nico) | `[FATAL][H1]` + stop imediato | `[FATAL][H1]` + stop imediato |

---

## Anchors de log preservados

- `[FATAL][H1]`
- `[WARN][COMPAT]`
- `[WARN][DEGRADED]`
- `[WARN][LEGACY_API_USED]`


