using UnityEngine;
namespace _ImmersiveGames.NewScripts.SceneFlow.LoadingFade.Fade.Runtime
{
    /// <summary>
    /// Configuração “crua” de fade (sem depender de SceneTransitionProfile).
    /// </summary>
    public readonly struct FadeConfig
    {
        public FadeConfig(
            float fadeInDuration,
            float fadeOutDuration,
            AnimationCurve fadeInCurve,
            AnimationCurve fadeOutCurve)
        {
            FadeInDuration = fadeInDuration;
            FadeOutDuration = fadeOutDuration;
            FadeInCurve = fadeInCurve;
            FadeOutCurve = fadeOutCurve;
        }

        public float FadeInDuration { get; }
        public float FadeOutDuration { get; }
        public AnimationCurve FadeInCurve { get; }
        public AnimationCurve FadeOutCurve { get; }
    }
}

