﻿using _ImmersiveGames.NewScripts.Core.Composition;
using _ImmersiveGames.NewScripts.Core.Identifiers;
using _ImmersiveGames.NewScripts.Modules.ContentSwap.Runtime;
using _ImmersiveGames.NewScripts.Modules.GameLoop.Bindings.Bootstrap;
using _ImmersiveGames.NewScripts.Modules.GameLoop.Runtime;
using _ImmersiveGames.NewScripts.Modules.Gameplay.Runtime.View;
using _ImmersiveGames.NewScripts.Modules.Gates;

namespace _ImmersiveGames.NewScripts.Infrastructure.Composition
{
    public static partial class GlobalCompositionRoot
    {
        private enum CompositionInstallStage
        {
            RuntimePolicy,
            Gates,
            GameLoop,
            SceneFlow,
            WorldLifecycle,
            Navigation,
            Levels,
            ContentSwap,
            DevQA
        }

        private static CompositionInstallStage _compositionInstallStage;

        // --------------------------------------------------------------------
        // Main registration pipeline (order matters)
        // --------------------------------------------------------------------

        private static void RegisterEssentialServicesOnly()
        {
            PrimeEventSystems();

            _compositionInstallStage = CompositionInstallStage.RuntimePolicy;
            InstallCompositionModules();
            RegisterInputModesFromRuntimeConfig();

            _compositionInstallStage = CompositionInstallStage.Gates;
            InstallCompositionModules();

            // Resolve ISimulationGateService UMA vez para os consumidores (reduz repeticao de TryGetGlobal).
            var gateService = ResolveSimulationGateServiceOrNull();

            RegisterPauseBridge(gateService);

            _compositionInstallStage = CompositionInstallStage.GameLoop;
            InstallCompositionModules();

            // NewScripts standalone: registra sempre o SceneFlow nativo (sem bridge/adapters legados).
            _compositionInstallStage = CompositionInstallStage.SceneFlow;
            InstallCompositionModules();

            _compositionInstallStage = CompositionInstallStage.WorldLifecycle;
            InstallCompositionModules();

            _compositionInstallStage = CompositionInstallStage.Navigation;
            InstallCompositionModules();

            _compositionInstallStage = CompositionInstallStage.Levels;
            InstallCompositionModules();

            _compositionInstallStage = CompositionInstallStage.ContentSwap;
            InstallCompositionModules();

            _compositionInstallStage = CompositionInstallStage.DevQA;
            InstallCompositionModules();

            RegisterExitToMenuNavigationBridge();
            RegisterMacroRestartCoordinator();
            RegisterLevelSelectedRestartSnapshotBridge();

            RegisterInputModeSceneFlowBridge();
            RegisterLevelStageOrchestrator();
            RegisterStateDependentService();
            RegisterIfMissing<ICameraResolver>(() => new CameraResolverService());

#if NEWSCRIPTS_BASELINE_ASSERTS
            RegisterBaselineAsserter();
#endif

            InitializeReadinessGate(gateService);
            RegisterGameLoopSceneFlowCoordinatorIfAvailable();
        }

        private static void InstallCompositionModules()
        {
            switch (_compositionInstallStage)
            {
                case CompositionInstallStage.RuntimePolicy:
                    RegisterRuntimePolicyServices();
                    break;
                case CompositionInstallStage.Gates:
                    InstallGatesServices();
                    break;
                case CompositionInstallStage.GameLoop:
                    InstallGameLoopServices();
                    break;
                case CompositionInstallStage.SceneFlow:
                    InstallSceneFlowServices();
                    break;
                case CompositionInstallStage.WorldLifecycle:
                    InstallWorldLifecycleServices();
                    break;
                case CompositionInstallStage.Navigation:
                    InstallNavigationServices();
                    break;
                case CompositionInstallStage.Levels:
                    RegisterLevelsServices();
                    break;
                case CompositionInstallStage.ContentSwap:
                    InstallContentSwapServices();
                    break;
                case CompositionInstallStage.DevQA:
                    InstallDevQaServices();
                    break;
            }
        }

        private static void InstallGatesServices()
        {
            RegisterIfMissing<IUniqueIdFactory>(() => new UniqueIdFactory());
            RegisterIfMissing<ISimulationGateService>(() => new SimulationGateService());
        }

        private static void InstallGameLoopServices()
        {
            RegisterGameLoop();
            RegisterIntroStageCoordinator();
            RegisterIntroStageControlService();
            RegisterGameplaySceneClassifier();
            RegisterIntroStagePolicyResolver();
            RegisterDefaultIntroStageStep();

            RegisterGameRunEndRequestService();
            RegisterGameCommands();
            GameStartRequestEmitter.EnsureInstalled();

            // Resolve IGameLoopService UMA vez para servicos dependentes.
            DependencyManager.Provider.TryGetGlobal<IGameLoopService>(out var gameLoopService);

            RegisterGameRunStatusService(gameLoopService);
            RegisterGameRunOutcomeService(gameLoopService);
            RegisterGameRunOutcomeEventInputBridge();
            RegisterPostPlayOwnershipService();
        }

        private static void InstallNavigationServices()
        {
            RegisterGameNavigationService();
        }

        private static void InstallContentSwapServices()
        {
            // ADR-0016: ContentSwapContext precisa existir no DI global.
            RegisterIfMissing<IContentSwapContextService>(() => new ContentSwapContextService());

            // ContentSwapChange (InPlace-only): usa apenas ContentSwapContext e commit imediato.
            RegisterContentSwapChangeService();
        }

        private static void InstallDevQaServices()
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            RegisterIntroStageQaInstaller();
            RegisterContentSwapQaInstaller();
            RegisterSceneFlowQaInstaller();
            RegisterWorldLifecycleQaInstaller();
            RegisterIntroStageRuntimeDebugGui();
#endif
        }
    }
}
