using System;
using System.Threading;
using _ImmersiveGames.NewScripts.Core.Composition;
using _ImmersiveGames.NewScripts.Core.Events;
using _ImmersiveGames.NewScripts.Core.Logging;
using _ImmersiveGames.NewScripts.Modules.GameLoop.Runtime;
using _ImmersiveGames.NewScripts.Modules.LevelFlow.Runtime;

namespace _ImmersiveGames.NewScripts.Modules.Navigation
{
    public sealed class RestartNavigationBridge : IDisposable
    {
        private const string RestartReason = "PostGame/Restart";

        private readonly EventBinding<GameResetRequestedEvent> _resetBinding;
        private bool _disposed;

        public RestartNavigationBridge()
        {
            _resetBinding = new EventBinding<GameResetRequestedEvent>(OnResetRequested);
            EventBus<GameResetRequestedEvent>.Register(_resetBinding);

            DebugUtility.LogVerbose<RestartNavigationBridge>(
                "[Navigation] RestartNavigationBridge registered (GameResetRequestedEvent -> StartGameplayDefaultAsync).",
                DebugUtility.Colors.Info);
        }

        public void Dispose()
        {
            if (_disposed)
            {
                return;
            }

            _disposed = true;
            EventBus<GameResetRequestedEvent>.Unregister(_resetBinding);
        }

        private void OnResetRequested(GameResetRequestedEvent evt)
        {
            string reason = string.IsNullOrWhiteSpace(evt?.Reason) ? RestartReason : evt.Reason.Trim();

            if (DependencyManager.Provider == null)
            {
                HardFailFastH1.Trigger(typeof(RestartNavigationBridge),
                    $"[FATAL][H1][Navigation] RestartNavigationBridge missing DependencyManager.Provider. reason='{reason}'.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IRestartContextService>(out var restartContext) || restartContext == null)
            {
                HardFailFastH1.Trigger(typeof(RestartNavigationBridge),
                    $"[FATAL][H1][Navigation] RestartNavigationBridge missing IRestartContextService. reason='{reason}'.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<ILevelFlowRuntimeService>(out var levelFlowRuntime) || levelFlowRuntime == null)
            {
                HardFailFastH1.Trigger(typeof(RestartNavigationBridge),
                    $"[FATAL][H1][Navigation] RestartNavigationBridge missing ILevelFlowRuntimeService. reason='{reason}'.");
            }

            restartContext.Clear(reason);

            DebugUtility.Log<RestartNavigationBridge>(
                $"[OBS][Navigation] GameResetRequestedEvent -> StartGameplayDefaultAsync reason='{reason}' clearedSelection=True.",
                DebugUtility.Colors.Info);

            NavigationTaskRunner.FireAndForget(
                levelFlowRuntime.StartGameplayDefaultAsync(reason, CancellationToken.None),
                typeof(RestartNavigationBridge),
                "Restart -> LevelFlow/StartGameplayDefault");
        }
    }
}
