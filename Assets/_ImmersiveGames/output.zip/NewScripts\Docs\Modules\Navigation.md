# Navigation

## CAN�NICO
- Owner can�nico de restart: `Modules/Navigation/Runtime/MacroRestartCoordinator.cs`.
- Trilho can�nico de restart:
  - `GameCommands` publica `GameResetRequestedEvent`.
  - `MacroRestartCoordinator` consome o evento.
  - Executa, nesta ordem: `IRestartContextService.Clear(...)` -> `IGameLoopService.RequestReset()` -> `ILevelFlowRuntimeService.StartGameplayDefaultAsync(...)`.
- `GameLoopCommandEventBridge` **n�o** � listener de reset (apenas pausa/resume/exit).

## LEGACY/Compat
- Conte�do legacy restante ficou isolado em `Modules/Navigation/Legacy/`:
  - `Modules/Navigation/Legacy/RestartNavigationBridge.cs` (stub desativado)
  - `Modules/Navigation/Legacy/RestartSnapshotContentSwapBridge.cs` (no-op)
- N�o h� callsite can�nico no `Infrastructure/Composition` para registrar esses bridges.

## Notas
- Limpeza v1 manteve o comportamento do baseline por an�lise est�tica.
- N�o houve mudan�a de contrato p�blico em `IGameNavigationService`/`GameNavigationService` neste passo.
