# ADR-XXXX — <Título>

## Status
- Estado: {Proposto | Aceito | Implementado | Obsoleto | Substituído}
- Data: YYYY-MM-DD (ou '(não informado)')
- Escopo: <sistemas/pastas afetados>

## Contexto
<problema/motivação/premissas>

## Decisão
<decisão em bullets numerados>

## Fora de escopo
- (não informado)

## Consequências

### Benefícios
- (não informado)

### Trade-offs / Riscos
- (não informado)

## Notas de implementação
- (opcional)

## Evidências
- (não informado)

## Referências
- [README.md](../README.md)
