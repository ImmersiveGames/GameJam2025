#nullable enable
using System.Threading.Tasks;
namespace _ImmersiveGames.NewScripts.SceneFlow.LoadingFade.Fade.Runtime
{

    public interface IFadeService
    {
        Task EnsureReadyAsync();
        void Configure(FadeConfig config);
        Task FadeInAsync(string? contextSignature = null);
        Task FadeOutAsync(string? contextSignature = null);
    }
}

