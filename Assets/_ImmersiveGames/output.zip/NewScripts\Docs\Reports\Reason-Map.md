# Reason Map — DEPRECATED

Este arquivo é mantido apenas por **compatibilidade histórica** (links antigos).

A **fonte de verdade** do contrato de observabilidade e do catálogo de reasons é:

- `Reports/Observability-Contract.md`

## Regra

- Não adicionar listas novas de reasons aqui.
- Não manter aliases aqui.
- Se algum documento apontar para este arquivo, atualizar o link para o contrato.
