﻿#nullable enable
namespace _ImmersiveGames.NewScripts.Modules.ContentSwap.Runtime
{
    /// <summary>
    /// Modos canônicos de troca de conteúdo.
    /// </summary>
    public enum ContentSwapMode
    {
        InPlace = 0
    }
}
