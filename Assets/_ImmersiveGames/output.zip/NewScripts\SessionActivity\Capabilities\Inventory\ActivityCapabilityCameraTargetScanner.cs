namespace _ImmersiveGames.NewScripts.SessionActivity.Capabilities.Inventory
{
    // Intencionalmente vazio: implementação consolidada em ActivityCapabilityPermissionScanner.cs
}
