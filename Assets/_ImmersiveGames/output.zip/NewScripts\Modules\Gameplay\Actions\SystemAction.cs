namespace _ImmersiveGames.NewScripts.Modules.Gameplay.Actions
{
    public enum SystemAction
    {
        RequestReset,
        RequestQuit
    }
}

