# Core Module Audit

## A) Scope
- Entra: `Core/Events/**`, `Core/Composition/**`, `Core/Logging/**`, `Core/Identifiers/**`, `Core/Fsm/**`, `Core/Validation/**`.
- EventBus inputs: nao aplicavel como modulo de dominio (fornece infraestrutura de bus).
- Chamadas publicas: `EventBus<T>.Register/Unregister/Raise/Clear`, `DependencyManager.Provider.*`, `DebugUtility.*`.
- Unity callbacks: `DependencyManager` (MonoBehaviour bootstrap de DI).

## B) Outputs
- Publica efeitos de infraestrutura: entrega de eventos para consumidores e resolucao de servicos.
- Nao registra servicos de dominio diretamente no DI de producao.
- Efeito em Gate/InputMode: indireto (suporte), sem ownership de regra de gate/input.

## C) DI Registration
- Registro de Core ocorre em `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs` via `RegisterIfMissing<IUniqueIdFactory>(() => new UniqueIdFactory())`.
- Infra de DI base em `Core/Composition/DependencyManager.cs` + registries (`Global/Scene/Object`).

## D) Canonical Runtime Rail
- Trilho canonico: `EventBus<T>` (dispatch) -> consumidores dos modulos de dominio.
- Trilho canonico de servicos: `DependencyManager.Provider` resolve interfaces registradas pelo `GlobalCompositionRoot`.

## E) LEGACY/Compat
- `Core/Events/FilteredEventBus.Legacy.cs` = wrapper de compat para assinatura antiga.

## F) Redundancy Candidates
- `Core/Events/FilteredEventBus.Legacy.cs` - wrapper LEGACY adicional ao `FilteredEventBus<TScope, TEvent>`; risco baixo, pode mascarar API antiga ainda usada.
- `Core/Composition/SceneServiceCleaner.cs` vs limpeza via controllers/roots - dupla superficie de limpeza; risco medio de limpeza duplicada.
- `Core/Logging/DebugManagerConfig.cs` + `DebugLogSettings.*` - policy distribuida; risco baixo de divergencia de configuracao.

## G) Deletion/Merge Plan (DOC-ONLY)
- Planejar deprecacao formal de `FilteredEventBus.Legacy.cs` com inventario de callsites.
- Consolidar politica de limpeza de `SceneServiceRegistry` em um owner can�nico.
- Consolidar ponto unico de politica de logs/fallback.

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Core/Events/EventBus.cs | Shared | `Register`, `Unregister`, `Raise`, `Clear` | N/A | N/A | N/A | Canon |
| Core/Events/InjectableEventBus.cs | Shared | `Register`, `Unregister`, `Raise` | N/A | N/A | N/A | Canon |
| Core/Events/FilteredEventBus.cs | Shared | `Register`, `Raise`, `Clear` | N/A | N/A | N/A | Canon |
| Core/Events/FilteredEventBus.Legacy.cs | Shared | wrapper static API | N/A | N/A | N/A | Legacy/Compat |
| Core/Composition/DependencyManager.cs | Runtime | `Provider`, lifecycle mono | N/A | N/A | base DI provider | Canon |
| Core/Identifiers/UniqueIdFactory.cs | Runtime | `Create` (factory) | N/A | N/A | `IUniqueIdFactory` (via composition) | Canon |