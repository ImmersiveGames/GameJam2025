# PostGame Module

Status: Baseline 3.1
Data: 2026-03-07

## Ownership

- Owner can�nico de ownership de PostGame: `IPostGameOwnershipService` / `PostGameOwnershipService`.
- Registro can�nico na composi��o: `Infrastructure/Composition/GlobalCompositionRoot.GameLoop.cs`.
- Overlay (`PostGameOverlayController`) atua como non-owner quando owner global est� ativo (`ShouldOverlayManageOwnership()`), preservando o trilho can�nico.

## Timeline

1. `GameLoopService` conclui run e publica estado de p�s-jogo (`PostGameEntered`).
2. `PostGameOwnershipService.OnPostGameEntered(...)` aplica input/gate de `state.postgame` quando habilitado.
3. `PostGameOverlayController` responde a `GameRunEndedEvent`, mostra UI e dispara apenas intents de a��o.
4. A��es do overlay chamam `IPostLevelActionsService`:
   - `RestartLevelAsync(...)`
   - `NextLevelAsync(...)`
   - `ExitToMenuAsync(...)`
5. Restart macro permanece can�nico em Navigation:
   - `GameCommands.RequestRestart(...)` -> `GameResetRequestedEvent` -> `MacroRestartCoordinator`.

## Runtime Rail (can�nico)

- `Modules/PostGame/IPostGameOwnershipService.cs`
- `Modules/PostGame/PostGameOwnershipService.cs`
- `Modules/PostGame/Bindings/PostGameOverlayController.cs`

## LEGACY / DevQA

- DevQA isolado em:
  - `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs`
- Guard do arquivo DevQA:
  - `#if UNITY_EDITOR || DEVELOPMENT_BUILD`
- APIs `UnityEditor` no DevQA ficam sob:
  - `#if UNITY_EDITOR`

## Build Matrix Note

- QA harness de PostGame (ContextMenu e comandos de risco) requer build de desenvolvimento (`UNITY_EDITOR || DEVELOPMENT_BUILD`).
- Build de release exclui trilho DevQA por compile guards.
- Contratos p�blicos e timeline macro permanecem inalterados.
