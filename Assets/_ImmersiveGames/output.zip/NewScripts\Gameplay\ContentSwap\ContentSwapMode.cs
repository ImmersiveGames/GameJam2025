#nullable enable
namespace _ImmersiveGames.NewScripts.Gameplay.ContentSwap
{
    /// <summary>
    /// Modos canônicos de troca de conteúdo.
    /// </summary>
    public enum ContentSwapMode
    {
        InPlace = 0,
        SceneTransition = 1
    }
}
