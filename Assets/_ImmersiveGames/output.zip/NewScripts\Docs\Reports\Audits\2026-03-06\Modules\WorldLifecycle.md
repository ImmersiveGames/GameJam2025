# WorldLifecycle Module Audit

## A) Scope
- Entra: `Modules/WorldLifecycle/**` (`Runtime`, `WorldRearm`, `Bindings`, `Hooks`, `Spawn`, `Dev`).
- EventBus inputs: `SceneTransitionScenesReadyEvent` (driver), `WorldLifecycleResetCompletedEvent` (completion gate consumer).
- Chamadas publicas: `IWorldResetService`, `IWorldResetCommands`, `IWorldResetRequestService`.
- Unity callbacks: `WorldLifecycleController` e hooks de ciclo de vida.

## B) Outputs
- Publica `WorldLifecycleResetStartedEvent`, `WorldLifecycleResetCompletedEvent`, e eventos V2 (`WorldLifecycleResetRequestedV2Event`, `WorldLifecycleResetCompletedV2Event`).
- Registra servi�os de reset macro/level e completion gate para SceneFlow.
- Efeito em Gate/InputMode: libera gate de transicao via `WorldLifecycleResetCompletionGate`.

## C) DI Registration
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs`:
  - `WorldLifecycleSceneFlowResetDriver`
  - `WorldResetService`
  - `IWorldResetCommands` -> `WorldResetCommands`
  - `IWorldResetRequestService` -> `WorldResetRequestService`
- `Infrastructure/Composition/GlobalCompositionRoot.SceneFlowWorldLifecycle.cs`:
  - `ISceneTransitionCompletionGate` (com `WorldLifecycleResetCompletionGate` como inner gate).

## D) Canonical Runtime Rail
- `WorldLifecycleSceneFlowResetDriver` recebe `SceneTransitionScenesReadyEvent`; quando policy exige reset, delega para `WorldResetService` -> `WorldResetOrchestrator` (owner can�nico). O `WorldLifecycleResetCompletionGate` aguarda `WorldLifecycleResetCompletedEvent` para liberar o final da transi��o.

## E) LEGACY/Compat
- Publicacao de `WorldLifecycleResetCompletedEvent` no driver e em `WorldResetService` e fallback/escape hatch (nao trilho principal).
- APIs obsoletas por `LevelId` em `WorldResetCommands` marcadas como desativadas.

## F) Redundancy Candidates
- `Modules/WorldLifecycle/Runtime/WorldLifecycleOrchestrator.cs` e `Modules/WorldLifecycle/WorldRearm/Application/WorldResetOrchestrator.cs` coexistem com nomes similares e semantica diferente; risco alto de confusao.
- `Modules/WorldLifecycle/Runtime/WorldLifecycleSceneFlowResetDriver.cs` publica completion em fallback alem do publisher can�nico; risco medio.
- `Modules/WorldLifecycle/Runtime/WorldLifecycleResetV2Events.cs` coexistindo com evento V1 de completion; risco medio de fragmentacao.

## G) Deletion/Merge Plan (DOC-ONLY)
- Definir um mapa explicito V1/V2 com data de desativacao de contrato antigo.
- Nomear/documentar claramente limites entre `WorldLifecycleOrchestrator` (controller flow) e `WorldResetOrchestrator` (rail can�nico macro reset).
- Manter fallback publisher apenas enquanto gate depender de tolerancia a falha.

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Modules/WorldLifecycle/Runtime/WorldLifecycleSceneFlowResetDriver.cs | Runtime | ctor/dispose | `SceneTransitionScenesReadyEvent` | `WorldLifecycleResetCompletedEvent` (SKIP/fallback) | concrete driver | Canon integration + fallback publish |
| Modules/WorldLifecycle/WorldRearm/Application/WorldResetService.cs | Runtime | `TriggerResetAsync` | N/A | `WorldLifecycleResetCompletedEvent` (fallback on error) | `WorldResetService` / `IWorldResetService` | Canon service |
| Modules/WorldLifecycle/WorldRearm/Application/WorldResetOrchestrator.cs | Runtime | `ExecuteAsync` | N/A | `WorldLifecycleResetStartedEvent`, `WorldLifecycleResetCompletedEvent` | internal owner | Canon publisher owner |
| Modules/WorldLifecycle/Runtime/WorldLifecycleResetCompletionGate.cs | Runtime | `AwaitBeforeFadeOutAsync` | `WorldLifecycleResetCompletedEvent` | N/A | used as completion gate inner | Canon consumer |
| Modules/WorldLifecycle/Runtime/WorldResetCommands.cs | Runtime | `ResetMacroAsync`, `ResetLevelAsync` | N/A | `WorldLifecycleResetRequestedV2Event`, `WorldLifecycleResetCompletedV2Event` | `IWorldResetCommands` | Canon + legacy API blocked |
| Modules/WorldLifecycle/Runtime/WorldLifecycleOrchestrator.cs | Runtime | orchestrator flow methods | N/A | logs/flow side effects | used by controller | Canon (parallel domain) |
| Modules/WorldLifecycle/Runtime/WorldLifecycleResetV2Events.cs | Shared | event contracts | N/A | N/A | N/A | Compat transition candidate |