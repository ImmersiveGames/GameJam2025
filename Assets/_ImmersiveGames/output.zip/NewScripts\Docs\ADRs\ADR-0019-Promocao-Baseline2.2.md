﻿# ADR-0019 — Promoção do Baseline 2.1 → 2.2 (Declaração Formal)

## Status
- Estado: Em aberto (rascunho)
- Data: 2026-01-18
- Escopo: Declaração de promoção (Baseline 2.2)

## Contexto

O Baseline 2.2 (WorldCycle config-driven) só pode ser promovido quando os gates definidos no ADR-0018 estiverem PASS com evidência datada.

Este ADR existe para:
1) registrar formalmente a promoção (o “ato”);
2) referenciar, de forma inequívoca, o snapshot de evidência que fecha os gates;
3) evitar promoções implícitas (“parece que está pronto”), mantendo o baseline como contrato verificável.

## Decisão

### Regra
A promoção do Baseline 2.1 → 2.2 **somente** é considerada válida quando este ADR estiver com **Estado: Implementado**, contendo:
- um snapshot datado explícito (evidence package),
- o ponteiro `Docs/Reports/Evidence/LATEST.md` atualizado para esse snapshot,
- e a lista de gates do ADR-0018 marcada como PASS com referência ao snapshot.

Até lá, Baseline 2.2 permanece “não promovido”, mesmo que existam implementações parciais.

## Critérios de Promoção (Checklist)

> Estes itens devem ser preenchidos/atualizados no momento da promoção.

### Snapshot canônico da promoção
- Evidence snapshot: `Docs/Reports/Evidence/<YYYY-MM-DD>/` (obrigatório)
- Ponteiro atualizado: `Docs/Reports/Evidence/LATEST.md` (obrigatório)
- Logs brutos incluídos: Console + Smoke/Run relevante (obrigatório)
- Verificação curada incluída: âncoras/invariantes (obrigatório)

### Gates do ADR-0018 (todos PASS)
- G-01 — Phases nível B (contrato visual do In-Place): PASS/FAIL
    - Evidência: `<preencher com caminho do snapshot + arquivo>`
- G-02 — Observability contract (reasons + links + fonte de verdade): PASS/FAIL
    - Evidência: `<preencher>`
- G-03 — Docs sem drift (links canônicos): PASS/FAIL
    - Evidência: `<preencher>`
- G-04 — Trigger de produção para ResetWorld (condicional): PASS/FAIL/N/A
    - Evidência: `<preencher>`

## Evidências (a preencher no fechamento)

### Snapshot datado
- Data do snapshot: `<YYYY-MM-DD>`
- Pasta: `Docs/Reports/Evidence/<YYYY-MM-DD>/`
- Arquivo(s) de log bruto:
    - `<preencher: ConsoleLog-...>`
    - `<preencher: Smoke-... se aplicável>`
- Arquivo(s) de verificação curada:
    - `<preencher: Evidence-<YYYY-MM-DD>.md / anchors / checklist>`

### LATEST.md
- `Docs/Reports/Evidence/LATEST.md` atualizado para apontar para:
    - `Docs/Reports/Evidence/<YYYY-MM-DD>/`

## Consequências

### Benefícios
- A promoção vira um evento auditável e reproduzível
- Reduz regressões por documentação desatualizada ou evidência ambígua
- Dá segurança para evoluir o runtime do 2.2 sem “quebrar o contrato”

### Trade-offs
- Exige disciplina de evidência (snapshot datado + ponteiro LATEST)
- Exige que “promoção” seja tratada como entrega formal (não implícita)

## Passos para concluir este ADR (procedimento)

1) Executar os testes/fluxos necessários e gerar **snapshot datado** seguindo a metodologia em `Docs/Reports/Evidence/README.md`.
2) Atualizar `Docs/Reports/Evidence/LATEST.md` para apontar para o snapshot.
3) Marcar G-01..G-03 (e G-04 se aplicável) como PASS, com links/caminhos para evidência.
4) Alterar **Status** deste ADR para:
    - Estado: Implementado
    - Data: `<data da promoção>` (normalmente a data do snapshot)
5) Se necessário, atualizar changelog/report do baseline para refletir “Baseline 2.2 promoted”.

## Referências
- [ADR-0018 — Gate de Promoção do Baseline 2.1 → 2.2](ADR-0018-Gate-de-Promoção-Baseline2.2.md)
- [Plano 2.2 — WorldCycle Config-Driven](../Reports/plano2.2.md)
- Metodologia de evidência: `Docs/Reports/Evidence/README.md`
- Ponteiro de evidência vigente: `Docs/Reports/Evidence/LATEST.md`
