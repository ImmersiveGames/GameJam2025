﻿// DevQA compile-only for editor/dev builds; excluded from release player builds.
#if UNITY_EDITOR || DEVELOPMENT_BUILD
using System;
using _ImmersiveGames.NewScripts.Core.Logging;
using _ImmersiveGames.NewScripts.Modules.ContentSwap.Dev.Runtime;
using _ImmersiveGames.NewScripts.Modules.GameLoop.IntroStage.Dev;
using _ImmersiveGames.NewScripts.Modules.LevelFlow.Dev;
using _ImmersiveGames.NewScripts.Modules.SceneFlow.Dev;
using _ImmersiveGames.NewScripts.Modules.WorldLifecycle.Dev;

namespace _ImmersiveGames.NewScripts.Infrastructure.Composition
{
    public static partial class GlobalCompositionRoot
    {
        private static void RegisterIntroStageQaInstaller()
        {
            try
            {
                IntroStageDevInstaller.EnsureInstalled();
            }
            catch (Exception ex)
            {
                DebugUtility.LogWarning(typeof(GlobalCompositionRoot),
                    $"[QA][IntroStageController] Falha ao instalar IntroStageDevTools no bootstrap. ex='{ex.GetType().Name}: {ex.Message}'.");
            }
        }

        private static void RegisterContentSwapQaInstaller()
        {
            try
            {
                ContentSwapDevInstaller.EnsureInstalled();
            }
            catch (Exception ex)
            {
                DebugUtility.LogWarning(typeof(GlobalCompositionRoot),
                    $"[QA][ContentSwap] Falha ao instalar ContentSwapDevTools no bootstrap. ex='{ex.GetType().Name}: {ex.Message}'.");
            }
        }

        private static void RegisterSceneFlowQaInstaller()
        {
            try
            {
                SceneFlowDevInstaller.EnsureInstalled();
            }
            catch (Exception ex)
            {
                DebugUtility.LogWarning(typeof(GlobalCompositionRoot),
                    $"[QA][SceneFlow] Falha ao instalar SceneFlowDevTools no bootstrap. ex='{ex.GetType().Name}: {ex.Message}'.");
            }

            try
            {
                LevelFlowDevInstaller.EnsureInstalled();
            }
            catch (Exception ex)
            {
                DebugUtility.LogWarning(typeof(GlobalCompositionRoot),
                    $"[QA][LevelFlow] Falha ao instalar LevelFlowDevTools no bootstrap. ex='{ex.GetType().Name}: {ex.Message}'.");
            }
        }

        private static void RegisterWorldLifecycleQaInstaller()
        {
            try
            {
                WorldResetRequestHotkeyDevBootstrap.EnsureInstalled();
            }
            catch (Exception ex)
            {
                DebugUtility.LogWarning(typeof(GlobalCompositionRoot),
                    $"[QA][WorldLifecycle] Falha ao instalar WorldResetRequestHotkeyBridge no bootstrap. ex='{ex.GetType().Name}: {ex.Message}'.");
            }
        }

        private static void RegisterIntroStageRuntimeDebugGui()
        {
            IntroStageRuntimeDebugGui.EnsureInstalled();
        }

        // --------------------------------------------------------------------
    }
}
#endif

