# PostGame Cleanup Audit v1 (PG-1.1)

Data: 2026-03-07

Escopo: `Modules/PostGame/**` + interfaces/callsites em `LevelFlow`, `GameLoop`, `InputModes`, `Infrastructure/Composition`.

Princ�pio: workspace local � a fonte da verdade (sem uso de repo remoto).

## Behavior-preserving statement

- N�o houve mudan�a de contratos p�blicos (`IPostLevelActionsService`, `IPostGameOwnershipService`, payloads/eventos).
- N�o houve mudan�a de ordem/timeline macro (SceneFlow/GameLoop/LevelFlow).
- Restart macro continua ownership de `Navigation/MacroRestartCoordinator`.
- Mudan�a aplicada foi isolamento de DevQA em parcial sob guard de build.

## Invent�rio A/B/C

| Component | FilePath | Role | Guards (Editor/Dev/None) | HasRuntimeCallsite | HasAssetOrSerializeRef | Recommendation |
|---|---|---|---|---|---|---|
| IPostGameOwnershipService | `Modules/PostGame/IPostGameOwnershipService.cs` | Contrato de ownership PostGame | None | Sim (`GameLoopService`, composition) | N/A | A) KEEP |
| PostGameOwnershipService | `Modules/PostGame/PostGameOwnershipService.cs` | Owner can�nico de input mode + gate `state.postgame` | None | Sim (`GlobalCompositionRoot.GameLoop`) | N�o detectado no workspace (`*.unity/*.prefab/*.asset`) | A) KEEP |
| PostGameOverlayController (runtime) | `Modules/PostGame/Bindings/PostGameOverlayController.cs` | UI overlay runtime + intents para `IPostLevelActionsService` | None | Sim (`MonoBehaviour` runtime; chamadas para actions) | N�o detectado no workspace (`*.unity/*.prefab/*.asset`) | A) KEEP |
| PostGameOverlayController DevQA (novo parcial) | `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs` | Harness QA/ContextMenu de risco | `UNITY_EDITOR || DEVELOPMENT_BUILD`; `UnityEditor` sob `UNITY_EDITOR` | N�o (DevQA only) | N�o aplic�vel | B) MOVE to Dev (aplicado) |

Observa��o sobre `HasAssetOrSerializeRef`: scan de assets no workspace local n�o encontrou `*.unity/*.prefab/*.asset`; sem evid�ncia de refer�ncia serializada no escopo local.

## Mudan�a aplicada (segura)

- Extra�do bloco QA/Editor de `PostGameOverlayController` para arquivo parcial dedicado:
  - origem l�gica: `Modules/PostGame/Bindings/PostGameOverlayController.cs` (bloco `ContextMenu` + guard/reentrada QA)
  - destino: `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs`
- `PostGameOverlayController` virou `partial` e preservou trilho runtime can�nico.
- `UnityEditor` removido do arquivo runtime; uso agora restrito ao arquivo DevQA e sob guard `#if UNITY_EDITOR`.

## Evid�ncia est�tica (rg)

### 1.1 Mapear arquivos/features PostGame
Comando:
`rg -n "namespace _ImmersiveGames\.NewScripts\.Modules\.PostGame|class\s+PostGame|PostGameOverlay|PostGameOwnership|state\.postgame|\[PostGame\]" Modules -g "*.cs"`

Trechos relevantes:
- `Modules/PostGame/PostGameOwnershipService.cs:57` (`state.postgame`)
- `Modules/PostGame/PostGameOwnershipService.cs:65` (`OnPostGameEntered`)
- `Modules/PostGame/PostGameOwnershipService.cs:77` (`OnPostGameExited`)
- `Modules/PostGame/Bindings/PostGameOverlayController.cs:25` (controller runtime)
- `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs:12` (parcial DevQA)
- `Modules/GameLoop/Runtime/Services/GameLoopService.cs:285` e `:300` (ownership enter/exit)

### 1.2 Entry points / dispatch
Comando:
`rg -n "PostGameOverlayController|IPostLevelActionsService|RestartLevelAsync|NextLevelAsync|ExitToMenuAsync|RequestRestart|GameResetRequestedEvent" Modules Infrastructure -g "*.cs"`

Trechos relevantes:
- `Modules/PostGame/Bindings/PostGameOverlayController.cs:125` (`RestartLevelAsync`)
- `Modules/PostGame/Bindings/PostGameOverlayController.cs:148` (`ExitToMenuAsync`)
- `Modules/LevelFlow/Runtime/PostLevelActionsService.cs:35` (`RestartLevelAsync`)
- `Modules/LevelFlow/Runtime/PostLevelActionsService.cs:45` (`RequestRestart`)
- `Modules/Navigation/Runtime/MacroRestartCoordinator.cs:33` (`EventBus<GameResetRequestedEvent>.Register`)
- `Modules/Navigation/Runtime/MacroRestartCoordinator.cs:36` (`canonical macro restart`)

### 1.3 Dev/QA/Editor-only dentro de PostGame
Comando:
`rg -n "#if\s+UNITY_EDITOR|#if\s+DEVELOPMENT_BUILD|UNITY_EDITOR\s*\|\|\s*DEVELOPMENT_BUILD|MenuItem|ContextMenu|RuntimeInitializeOnLoadMethod|InitializeOnLoad|AssetDatabase|FindAssets|UnityEditor" Modules/PostGame -g "*.cs"`

Trechos relevantes:
- `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs:1` (`#if UNITY_EDITOR || DEVELOPMENT_BUILD`)
- `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs:6` e `:7` (`UnityEditor` sob `#if UNITY_EDITOR`)
- `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs:62`, `:87`, `:112`, `:133` (`[ContextMenu(...)]`)

### 1.4 Scan de assets (candidato move/delete)
Comando:
`rg -n "PostGameOverlayController|PostGameOwnershipService|IPostGameOwnershipService" -g "*.unity" -g "*.prefab" -g "*.asset" .`

Resultado:
- sem matches (exit code 1 no workspace atual).

### 1.5 Callsites can�nicos de composi��o
Comandos:
- `rg -n "InstallDevQaServices\(|InstallGameLoopServices\(|InstallSceneFlowServices\(|RegisterLevelsServices\(|InstallNavigationServices\(|InstallContentSwapServices\(" Infrastructure/Composition -g "*.cs"`
- `rg -n "PostGame" Infrastructure/Composition -g "*.cs"`

Trechos relevantes:
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs:98` (`InstallGameLoopServices`)
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs:116` (`InstallDevQaServices`)
- `Infrastructure/Composition/GlobalCompositionRoot.GameLoop.cs:134`-`:135` (`RegisterGlobal<IPostGameOwnershipService>(new PostGameOwnershipService())`)

## Mudan�as de arquivo

- Modificado: `Modules/PostGame/Bindings/PostGameOverlayController.cs`
- Adicionado: `Modules/PostGame/Dev/PostGameOverlayController.DevQA.cs`
- Nenhum arquivo removido.
- Nenhum arquivo movido/renomeado (logo, sem move de `.meta`).
