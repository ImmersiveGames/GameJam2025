# Navigation Module Audit

## A) Scope
- Entra: `Modules/Navigation/**` (runtime, bindings, assets, dev/editor helpers).
- EventBus inputs: `GameResetRequestedEvent`, `GameExitToMenuRequestedEvent`, `LevelSelectedEvent`.
- Chamadas publicas: `IGameNavigationService`, `IGameNavigationCatalog`.
- Unity callbacks: bindings de menu/frontend e assets de catalogo.

## B) Outputs
- Executa navegacao para SceneFlow por `GameNavigationService`.
- Publica efeitos de restart macro por pipeline can�nico (`MacroRestartCoordinator` chama LevelFlow runtime).
- Efeito em Gate/InputMode: indireto, via transicoes SceneFlow e contexto de restart.

## C) DI Registration
- `Infrastructure/Composition/GlobalCompositionRoot.NavigationInputModes.cs`:
  - `IRestartContextService` -> `RestartContextService`
  - `IGameNavigationService` -> `GameNavigationService`
  - bridges: `ExitToMenuNavigationBridge`, `MacroRestartCoordinator`, `LevelSelectedRestartSnapshotBridge`
- Metodo nao chamado no pipeline: `RegisterRestartSnapshotContentSwapBridge()`.

## D) Canonical Runtime Rail
- Restart can�nico: `GameCommands` publica `GameResetRequestedEvent` -> `MacroRestartCoordinator` consome -> limpa contexto, aciona `IGameLoopService.RequestReset()` e `ILevelFlowRuntimeService.StartGameplayDefaultAsync()`.
- Navegacao can�nica: `GameNavigationService.StartGameplayRouteAsync` para transicao SceneFlow.

## E) LEGACY/Compat
- `Modules/Navigation/RestartNavigationBridge.cs` desativado (apenas warning).
- `Modules/Navigation/RestartSnapshotContentSwapBridge.cs` no-op com marcador legacy.
- APIs obsoletas em `IGameNavigationService` / `GameNavigationService` mantidas por compatibilidade temporaria.

## F) Redundancy Candidates
- `Modules/Navigation/RestartNavigationBridge.cs` - classe legacy sem registro no pipeline atual; risco baixo.
- `Modules/Navigation/RestartSnapshotContentSwapBridge.cs` - no-op e metodo de registro nao invocado; risco baixo.
- `Modules/Navigation/LevelSelectedRestartSnapshotBridge.cs` + `IRestartContextService` com informacao tambem carregada por LevelFlow services; risco medio.

## G) Deletion/Merge Plan (DOC-ONLY)
- Remover bridges legacy apos confirmar zero dependencias externas.
- Encerrar APIs obsolete de `IGameNavigationService` com plano de migra��o final.
- Consolidar ownership do snapshot de restart entre Navigation e LevelFlow.

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Modules/Navigation/GameNavigationService.cs | Runtime | `RestartAsync`, `StartGameplayRouteAsync`, outros intents | N/A | aciona `ISceneTransitionService` | `IGameNavigationService` | Canon |
| Modules/Navigation/Runtime/MacroRestartCoordinator.cs | Runtime | ctor/Dispose | `GameResetRequestedEvent` | N/A | concrete coordinator | Canon owner restart |
| Modules/Navigation/ExitToMenuNavigationBridge.cs | Runtime | ctor/Dispose | `GameExitToMenuRequestedEvent` | N/A | concrete bridge | Canon |
| Modules/Navigation/LevelSelectedRestartSnapshotBridge.cs | Runtime | ctor/Dispose | `LevelSelectedEvent` | N/A | concrete bridge | Canon consumer |
| Modules/Navigation/RestartNavigationBridge.cs | Runtime | ctor only warning | none efetivo | none | none | Legacy/Compat (disabled) |
| Modules/Navigation/RestartSnapshotContentSwapBridge.cs | Runtime | ctor/Dispose | `ContentSwapCommittedEvent` | none efetivo | none (registration method unused) | Legacy/Compat no-op |
| Modules/Navigation/IGameNavigationService.cs | Shared | public contract | N/A | N/A | N/A | Canon + obsolete members |