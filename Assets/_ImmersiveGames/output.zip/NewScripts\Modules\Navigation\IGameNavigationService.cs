using System.Threading.Tasks;
using _ImmersiveGames.NewScripts.Modules.SceneFlow.Navigation.Runtime;
namespace _ImmersiveGames.NewScripts.Modules.Navigation
{
    /// <summary>
    /// Servi�o de navega��o de produ��o (NewScripts).
    /// Mant�m rotas/planos centralizados e dispara transi��es via SceneFlow.
    /// </summary>
    public interface IGameNavigationService
    {
        /// <summary>
        /// Navega explicitamente para o Menu principal.
        /// </summary>
        Task GoToMenuAsync(string reason = null);

        /// <summary>
        /// Reinicia o gameplay atual usando o intent can�nico de gameplay.
        /// </summary>
        Task RestartAsync(string reason = null);

        /// <summary>
        /// Sai do gameplay para Menu (sem�ntica de p�s-jogo/pause).
        /// </summary>
        Task ExitToMenuAsync(string reason = null);


        /// <summary>
        /// Inicia gameplay a partir de um SceneRouteId j� resolvido pelo LevelFlow.
        /// </summary>
        Task StartGameplayRouteAsync(SceneRouteId routeId, SceneTransitionPayload payload = null, string reason = null);


        /// <summary>
        /// Navega��o por intent core tipado (slots expl�citos no cat�logo).
        /// </summary>
        Task NavigateAsync(GameNavigationIntentKind intent, string reason = null);

        /// <summary>
        /// Compatibilidade tempor�ria: navegar por id de intent/rota (inclui extras/custom intents).
        /// </summary>
        [System.Obsolete("Prefira NavigateAsync(GameNavigationIntentKind, reason) para core intents; mantenha string para extras/custom.")]
        Task NavigateAsync(string routeId, string reason = null);

        /// <summary>
        /// Compatibilidade tempor�ria para menu.
        /// </summary>
        [System.Obsolete("Use GoToMenuAsync(reason).")]
        Task RequestMenuAsync(string reason = null);

        /// <summary>
        /// Compatibilidade tempor�ria para gameplay sem LevelId expl�cito.
        /// </summary>
        [System.Obsolete("Legacy API blocked. Use RestartAsync(reason) ou ILevelFlowRuntimeService.StartGameplayDefaultAsync(reason, ct).")]
        Task RequestGameplayAsync(string reason = null);
    }
}



