# Module Audit Summary (LevelFlow excerpt)

## LevelFlow
**Canonical Rail:** `LevelFlowRuntimeService` inicia/reinicia gameplay default; `LevelMacroPrepareService` executa LevelPrepare na fase macro do SceneFlow; `LevelSwapLocalService` cobre swap local intra-macro; `LevelStageOrchestrator` coordena IntroStage por `SceneTransitionCompletedEvent` + `LevelSwapLocalAppliedEvent`.

**Atualizacao LF-1.1 (higiene sem mudanca comportamental):**
- Legacy/Compat isolado para `Modules/LevelFlow/Legacy/**`:
  - `Legacy/Bindings/LevelCatalogAsset.cs`
  - `Legacy/Runtime/ILevelFlowService.cs`
  - `Legacy/Runtime/ILevelMacroRouteCatalog.cs`
  - `Legacy/Runtime/ILevelContentResolver.cs`
- Pipeline canonico de DI/runtime permaneceu inalterado.

## GameLoop
**Canonical Rail:** `GameLoopService` mant�m a state machine da run, `GameCommands` publica comandos definitivos, `GameRunOutcomeService` publica `GameRunEndedEvent` de forma idempotente, `GameRunStateService` exp�e estado para UI/sistemas, e `GameLoopSceneFlowCoordinator` sincroniza StartPlan com SceneFlow/WorldLifecycle para `RequestReady`.

**Atualizacao GL-1.1 (higiene sem mudanca comportamental):**
- Reset ownership mantido: `GameResetRequestedEvent` continua sem listener ativo em `Modules/GameLoop/**`; owner can�nico do consumo permanece `Modules/Navigation/Runtime/MacroRestartCoordinator.cs`.
- Nenhum item foi movido para `Modules/GameLoop/Legacy/**` nesta etapa por falta de evid�ncia conclusiva de inatividade runtime.
- Itens com baixa refer�ncia foram marcados como `requires manual confirmation` (Unity lifecycle/editor):
  - `Bindings/Bootstrap/GameStartRequestEmitter.cs`
  - `Bindings/Inputs/GamePauseHotkeyController.cs`
  - `IntroStage/Dev/Editor/IntroStageDevTools.cs`

## Gates-Readiness-StateDependent
**Canonical Rail:** `SceneTransitionService` publica `SceneTransitionStarted/Completed`; `GameReadinessService` � owner de readiness e do token `SceneTransition` no `SimulationGateService`; `SceneFlowInputModeBridge` sincroniza InputMode/GameLoop no `Completed` com dedupe `profile|signature`; `StateDependentService` consome Gate + Readiness + GameLoop state para bloquear/liberar a��es de gameplay.

**Top redund�ncias (5):**
- Overlap de consumidores em `GamePauseCommandEvent` (`GamePauseGateBridge`, `StateDependentService`, `GameLoopCommandEventBridge`, `PauseOverlayController`, `GamePauseHotkeyController`).
- Overlap de consumidores em `GameResumeRequestedEvent` (`GamePauseGateBridge` + `StateDependentService` + bridges/UI).
- Overlap de consumidores em `GameExitToMenuRequestedEvent` (`GamePauseGateBridge` + `StateDependentService` + navega��o/UI).
- Dedupe paralelo em dom�nios diferentes (`SceneFlowInputModeBridge` com `profile|signature` vs `GameReadinessService` por snapshot equality).
- `InputModeBootstrap` coexistindo com registro can�nico via composition (`RegisterInputModesFromRuntimeConfig`) sem evid�ncia conclusiva de inatividade.

**Risco e ordem:** 4/10 (m�dio-baixo). Primeiro consolidar documenta��o de ownership e dedupe; depois decidir corte de overlap em pause/resume/exit; por �ltimo avaliar bootstrap legacy com valida��o manual de cena.

**Nota cr�tica:** `GameResetRequestedEvent` mant�m owner can�nico de restart em `Modules/Navigation/Runtime/MacroRestartCoordinator.cs`; `Modules/Gameplay/Runtime/Actions/States/StateDependentService.cs` permanece como consumer adicional auxiliar (n�o executa restart).