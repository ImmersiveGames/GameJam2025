using System;
using System.Collections.Generic;
using _ImmersiveGames.NewScripts.SceneFlow.NavigationDispatch.NavigationMacro;
using ImmersiveGames.GameJam2025.Modules.Navigation;
using UnityEditor;
using UnityEngine;

namespace ImmersiveGames.GameJam2025.Modules.Navigation.Editor.IdSources
{
    /// <summary>
    /// Coleta NavigationIntentId a partir da fonte canonica em codigo + extras do GameNavigationCatalogAsset.
    /// </summary>
    public sealed class NavigationIntentIdSourceProvider
    {
        private const string CanonicalCatalogPath = "Assets/Resources/Navigation/GameNavigationCatalog.asset";

        public NavigationIntentIdSourceResult Collect()
        {
            var values = new HashSet<string>(StringComparer.Ordinal);
            var duplicates = new HashSet<string>(StringComparer.Ordinal);

            AddFromCode(values, duplicates);
            CollectExtrasFromNavigationCatalog(values, duplicates);

            return BuildResult(values, duplicates);
        }

        private static void AddFromCode(HashSet<string> values, HashSet<string> duplicates)
        {
            for (int i = 0; i < GameNavigationIntents.AllCanonical.Count; i++)
            {
                string normalized = NavigationIntentId.Normalize(GameNavigationIntents.AllCanonical[i].Value);
                if (string.IsNullOrEmpty(normalized))
                {
                    continue;
                }

                if (!values.Add(normalized))
                {
                    duplicates.Add(normalized);
                }
            }

            for (int i = 0; i < GameNavigationCompatibility.AllAliases.Count; i++)
            {
                string normalized = NavigationIntentId.Normalize(GameNavigationCompatibility.AllAliases[i].Value);
                if (string.IsNullOrEmpty(normalized))
                {
                    continue;
                }

                if (!values.Add(normalized))
                {
                    duplicates.Add(normalized);
                }
            }
        }

        private static void CollectExtrasFromNavigationCatalog(
            HashSet<string> values,
            HashSet<string> duplicates)
        {
            var catalog = AssetDatabase.LoadAssetAtPath<GameNavigationCatalogAsset>(CanonicalCatalogPath);
            if (catalog == null)
            {
                throw new InvalidOperationException($"Canonical catalog not found at '{CanonicalCatalogPath}'.");
            }

            var serializedObject = new SerializedObject(catalog);
            SerializedProperty routes = serializedObject.FindProperty("routes");
            if (routes == null || !routes.isArray)
            {
                return;
            }

            for (int i = 0; i < routes.arraySize; i++)
            {
                SerializedProperty entry = routes.GetArrayElementAtIndex(i);
                SerializedProperty intentId = entry.FindPropertyRelative("intentId");
                SerializedProperty raw = intentId?.FindPropertyRelative("_value");
                if (raw == null)
                {
                    continue;
                }

                string normalized = NavigationIntentId.Normalize(raw.stringValue);
                if (string.IsNullOrEmpty(normalized))
                {
                    continue;
                }

                if (!values.Add(normalized))
                {
                    duplicates.Add(normalized);
                }
            }
        }

        private static NavigationIntentIdSourceResult BuildResult(HashSet<string> values, HashSet<string> duplicates)
        {
            var sortedValues = new List<string>(values);
            sortedValues.Sort(StringComparer.Ordinal);

            var sortedDuplicates = new List<string>(duplicates);
            sortedDuplicates.Sort(StringComparer.Ordinal);

            return new NavigationIntentIdSourceResult(sortedValues, sortedDuplicates);
        }
    }

    public readonly struct NavigationIntentIdSourceResult
    {
        public NavigationIntentIdSourceResult(IReadOnlyList<string> values, IReadOnlyList<string> duplicateValues)
        {
            Values = values;
            DuplicateValues = duplicateValues;
        }

        public IReadOnlyList<string> Values { get; }
        public IReadOnlyList<string> DuplicateValues { get; }
    }
}

namespace ImmersiveGames.GameJam2025.Modules.Navigation.Editor.Drawers
{
    using ImmersiveGames.GameJam2025.Modules.Navigation.Editor.IdSources;

    [CustomPropertyDrawer(typeof(NavigationIntentId))]
    public sealed class NavigationIntentIdPropertyDrawer : PropertyDrawer
    {
        private const string RawValuePropertyName = "_value";
        private const string NoneOptionLabel = "(None)";

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            SerializedProperty rawValueProperty = property.FindPropertyRelative(RawValuePropertyName);
            if (rawValueProperty == null)
            {
                EditorGUI.PropertyField(position, property, label, true);
                return;
            }

            string currentNormalized = NavigationIntentId.Normalize(rawValueProperty.stringValue);
            SourceSnapshot snapshot = NavigationIntentOptionsCache.GetOrRefresh();

            float y = position.y;
            Rect popupRect = new(position.x, y, position.width, EditorGUIUtility.singleLineHeight);
            y += EditorGUIUtility.singleLineHeight;

            bool hasSourceError = !string.IsNullOrEmpty(snapshot.ErrorMessage);
            bool hasMissingValue = !string.IsNullOrEmpty(currentNormalized) && !Contains(snapshot.Values, currentNormalized);
            bool hasDuplicates = snapshot.DuplicateValues.Count > 0;

            if (hasSourceError)
            {
                y += EditorGUIUtility.standardVerticalSpacing;
                float errorHeight = EditorStyles.helpBox.CalcHeight(new GUIContent(snapshot.ErrorMessage), position.width);
                Rect errorRect = new(position.x, y, position.width, errorHeight);
                y += errorHeight;
                EditorGUI.HelpBox(errorRect, snapshot.ErrorMessage, MessageType.Error);
            }

            if (hasMissingValue)
            {
                string missingWarningMessage = $"NavigationIntentId inexistente: '{currentNormalized}'.";
                y += EditorGUIUtility.standardVerticalSpacing;
                float warningHeight = EditorStyles.helpBox.CalcHeight(new GUIContent(missingWarningMessage), position.width);
                Rect warningRect = new(position.x, y, position.width, warningHeight);
                y += warningHeight;
                EditorGUI.HelpBox(warningRect, missingWarningMessage, MessageType.Warning);
            }

            if (hasDuplicates)
            {
                string duplicateWarningMessage = BuildDuplicateWarningMessage(snapshot.DuplicateValues);
                y += EditorGUIUtility.standardVerticalSpacing;
                float duplicateHeight = EditorStyles.helpBox.CalcHeight(new GUIContent(duplicateWarningMessage), position.width);
                Rect duplicateRect = new(position.x, y, position.width, duplicateHeight);
                EditorGUI.HelpBox(duplicateRect, duplicateWarningMessage, MessageType.Warning);
            }

            BuildPopupOptions(snapshot.Values, currentNormalized, hasMissingValue, out string[] popupOptions, out string[] rawValuesByIndex, out int selectedIndex);

            EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            int nextIndex = EditorGUI.Popup(popupRect, label.text, selectedIndex, popupOptions);
            if (EditorGUI.EndChangeCheck() && nextIndex >= 0 && nextIndex < rawValuesByIndex.Length)
            {
                rawValueProperty.stringValue = rawValuesByIndex[nextIndex];
            }

            EditorGUI.EndProperty();
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            SerializedProperty rawValueProperty = property.FindPropertyRelative(RawValuePropertyName);
            if (rawValueProperty == null)
            {
                return EditorGUI.GetPropertyHeight(property, label, true);
            }

            float height = EditorGUIUtility.singleLineHeight;
            string currentNormalized = NavigationIntentId.Normalize(rawValueProperty.stringValue);
            SourceSnapshot snapshot = NavigationIntentOptionsCache.GetOrRefresh();

            if (!string.IsNullOrEmpty(snapshot.ErrorMessage))
            {
                float errorHeight = EditorStyles.helpBox.CalcHeight(new GUIContent(snapshot.ErrorMessage), EditorGUIUtility.currentViewWidth);
                height += EditorGUIUtility.standardVerticalSpacing + errorHeight;
            }

            bool hasMissingValue = !string.IsNullOrEmpty(currentNormalized) && !Contains(snapshot.Values, currentNormalized);
            if (hasMissingValue)
            {
                string warningMessage = $"NavigationIntentId inexistente: '{currentNormalized}'.";
                float warningHeight = EditorStyles.helpBox.CalcHeight(new GUIContent(warningMessage), EditorGUIUtility.currentViewWidth);
                height += EditorGUIUtility.standardVerticalSpacing + warningHeight;
            }

            if (snapshot.DuplicateValues.Count > 0)
            {
                string duplicateMessage = BuildDuplicateWarningMessage(snapshot.DuplicateValues);
                float duplicateHeight = EditorStyles.helpBox.CalcHeight(new GUIContent(duplicateMessage), EditorGUIUtility.currentViewWidth);
                height += EditorGUIUtility.standardVerticalSpacing + duplicateHeight;
            }

            return height;
        }

        private static void BuildPopupOptions(
            IReadOnlyList<string> sourceValues,
            string currentNormalized,
            bool hasMissingValue,
            out string[] popupOptions,
            out string[] rawValuesByIndex,
            out int selectedIndex)
        {
            var labels = new List<string>(sourceValues.Count + 2) { NoneOptionLabel };
            var values = new List<string>(sourceValues.Count + 2) { string.Empty };

            for (int i = 0; i < sourceValues.Count; i++)
            {
                string id = sourceValues[i];
                labels.Add(id);
                values.Add(id);
            }

            if (hasMissingValue)
            {
                labels.Add($"MISSING: {currentNormalized}");
                values.Add(currentNormalized);
            }

            selectedIndex = 0;
            if (!string.IsNullOrEmpty(currentNormalized))
            {
                for (int i = 0; i < values.Count; i++)
                {
                    if (string.Equals(values[i], currentNormalized, StringComparison.Ordinal))
                    {
                        selectedIndex = i;
                        break;
                    }
                }
            }

            popupOptions = labels.ToArray();
            rawValuesByIndex = values.ToArray();
        }

        private static string BuildDuplicateWarningMessage(IReadOnlyList<string> duplicateValues)
        {
            const int maxIdsToDisplay = 5;
            int visibleCount = Mathf.Min(maxIdsToDisplay, duplicateValues.Count);

            var visibleIds = new string[visibleCount];
            for (int i = 0; i < visibleCount; i++)
            {
                visibleIds[i] = duplicateValues[i];
            }

            string suffix = duplicateValues.Count > maxIdsToDisplay
                ? $" (+{duplicateValues.Count - maxIdsToDisplay} more)"
                : string.Empty;

            return $"NavigationIntentId duplicado na fonte: {string.Join(", ", visibleIds)}{suffix}.";
        }

        private static bool Contains(IReadOnlyList<string> values, string expected)
        {
            for (int i = 0; i < values.Count; i++)
            {
                if (string.Equals(values[i], expected, StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }

        private readonly struct SourceSnapshot
        {
            public SourceSnapshot(IReadOnlyList<string> values, IReadOnlyList<string> duplicateValues, string errorMessage)
            {
                Values = values;
                DuplicateValues = duplicateValues;
                ErrorMessage = errorMessage;
            }

            public IReadOnlyList<string> Values { get; }
            public IReadOnlyList<string> DuplicateValues { get; }
            public string ErrorMessage { get; }
        }

        private static class NavigationIntentOptionsCache
        {
            private static readonly NavigationIntentIdSourceProvider Provider = new();
            private static readonly string[] EmptyValues = Array.Empty<string>();

            private static bool _isInitialized;
            private static bool _isDirty = true;
            private static SourceSnapshot _snapshot = new(EmptyValues, EmptyValues, string.Empty);

            public static SourceSnapshot GetOrRefresh()
            {
                EnsureInitialized();

                if (!_isDirty)
                {
                    return _snapshot;
                }

                try
                {
                    NavigationIntentIdSourceResult source = Provider.Collect();
                    _snapshot = new SourceSnapshot(source.Values, source.DuplicateValues, string.Empty);
                }
                catch (Exception exception)
                {
                    _snapshot = new SourceSnapshot(
                        EmptyValues,
                        EmptyValues,
                        $"Failed to load NavigationIntentId options. Check GameNavigationCatalog.asset. ({exception.GetType().Name})");
                }

                _isDirty = false;
                return _snapshot;
            }

            private static void EnsureInitialized()
            {
                if (_isInitialized)
                {
                    return;
                }

                _isInitialized = true;
                EditorApplication.projectChanged += MarkDirty;
            }

            private static void MarkDirty()
            {
                _isDirty = true;
            }
        }
    }
}

