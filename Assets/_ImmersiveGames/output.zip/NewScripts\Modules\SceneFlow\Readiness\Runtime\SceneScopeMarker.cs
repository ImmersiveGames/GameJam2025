namespace _ImmersiveGames.NewScripts.Modules.SceneFlow.Readiness.Runtime
{

    /// <summary>
    /// Implementação simples do marcador de escopo de cena.
    /// </summary>
    public sealed class SceneScopeMarker : ISceneScopeMarker
    {
    }
}
