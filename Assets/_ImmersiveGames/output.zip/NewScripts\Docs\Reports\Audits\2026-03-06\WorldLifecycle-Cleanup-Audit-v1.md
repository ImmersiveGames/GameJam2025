# WorldLifecycle Cleanup Audit v1 (Baseline 3.1)

Date: 2026-03-06  
Scope: `Modules/WorldLifecycle/**` + callsites externos que publicam/consomem eventos `WorldLifecycleReset*`, instanciam servi�os WL, ou registram WL no `GlobalCompositionRoot`.

---

## A) Canonical Rail

### Texto
No trilho can�nico atual, o SceneFlow publica `SceneTransitionScenesReadyEvent`, o `WorldLifecycleSceneFlowResetDriver` decide se o reset � requerido, e quando requerido delega ao `WorldResetService` (WorldRearm). O `WorldResetService` constr�i/usa `WorldResetOrchestrator`, que publica `WorldLifecycleResetStartedEvent` e `WorldLifecycleResetCompletedEvent`. O completion gate (`WorldLifecycleResetCompletionGate`) consome `WorldLifecycleResetCompletedEvent` para liberar a transi��o SceneFlow.

### Bullet flow (diagrama)
- `SceneTransitionService` -> `SceneTransitionScenesReadyEvent`
- `WorldLifecycleSceneFlowResetDriver.OnScenesReady`
- `WorldLifecycleSceneFlowResetDriver.ExecuteResetWhenRequiredAsync`
- `WorldResetService.TriggerResetAsync(WorldResetRequest)`
- `WorldResetOrchestrator.ExecuteAsync`
- `EventBus<WorldLifecycleResetStartedEvent>.Raise(...)`
- reset execution (`WorldResetExecutor` + controllers)
- `EventBus<WorldLifecycleResetCompletedEvent>.Raise(...)`
- `WorldLifecycleResetCompletionGate` consome completed e libera gate
- `SceneTransitionService` continua `BeforeFadeOut -> Completed`

Observa��o cr�tica (evid�ncia): o driver tamb�m publica `WorldLifecycleResetCompletedEvent` em SKIP/fallback para evitar timeout do gate.
- `Modules/WorldLifecycle/Runtime/WorldLifecycleSceneFlowResetDriver.cs:256`
- coment�rio de contrato no pr�prio arquivo: `:19` e `:247`

---

## B) Inventory table

| FilePath | Type | Canon/Legacy/Dead | Notes |
|---|---|---|---|
| Modules/WorldLifecycle/Runtime/WorldResetResult.cs | Runtime | Canon | Resultado de reset (`Completed/Failed/SkippedValidation`). |
| Modules/WorldLifecycle/Runtime/WorldResetRequestService.cs | Runtime | Canon | Entry-point de request manual; encaminha para `IWorldResetService`. |
| Modules/WorldLifecycle/Runtime/WorldResetCommands.cs | Runtime | Canon + Compat | Comandos macro/level + eventos V2; possui API legacy `ResetLevelAsync(LevelId)` bloqueada `[Obsolete]`. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleTokens.cs | Runtime | Canon | Tokens can�nicos de gate WL. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleSceneFlowResetDriver.cs | Runtime | Canon | Bridge SceneFlow->WL; fallback publisher de completion em SKIP/falha. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleResetV2Events.cs | Runtime | Canon (secund�rio) | Contratos V2 request/completed; hoje sem consumers por EventBus no escopo. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleResetStartedEvent.cs | Runtime | Canon (publisher-only) | Evento V1 started, publicado por `WorldResetOrchestrator`. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleResetCompletionGate.cs | Runtime | Canon | Consumer principal de `WorldLifecycleResetCompletedEvent`. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleResetCompletedEvent.cs | Runtime | Canon | Evento V1 completion usado no gate SceneFlow. |
| Modules/WorldLifecycle/Runtime/WorldLifecycleOrchestrator.cs | Runtime | Canon (controller rail) | Orquestrador de reset do controller de cena (Acquire/Despawn/Spawn/Release). |
| Modules/WorldLifecycle/Runtime/WorldLifecycleControllerLocator.cs | Runtime | Canon | Localiza controllers para execu��o de reset por cena. |
| Modules/WorldLifecycle/Runtime/SceneRouteResetPolicy.cs | Runtime | Canon | Policy de decis�o de reset por route/profile. |
| Modules/WorldLifecycle/Runtime/ResetKind.cs | Runtime | Canon | Enum do dom�nio de reset. |
| Modules/WorldLifecycle/Runtime/IWorldResetService.cs | Runtime | Canon | Contrato do servi�o can�nico de reset. |
| Modules/WorldLifecycle/Runtime/IWorldResetRequestService.cs | Runtime | Canon | Contrato de request manual de reset. |
| Modules/WorldLifecycle/Runtime/IWorldResetCommands.cs | Runtime | Canon + Compat | Contrato de comandos macro/level; inclui assinatura legacy obsoleta. |
| Modules/WorldLifecycle/Runtime/IRouteResetPolicy.cs | Runtime | Canon | Contrato da policy de reset por route. |
| Modules/WorldLifecycle/Bindings/WorldLifecycleController.cs | Bindings | Canon | MonoBehaviour de cena; cria e chama `WorldLifecycleOrchestrator`. |
| Modules/WorldLifecycle/Hooks/IWorldLifecycleHook.cs | Hooks | Canon | Contrato base de hook. |
| Modules/WorldLifecycle/Hooks/IWorldLifecycleHookOrdered.cs | Hooks | Canon | Contrato de ordena��o de hooks. |
| Modules/WorldLifecycle/Hooks/WorldLifecycleHookBase.cs | Hooks | Canon | Base utilit�ria de hook. |
| Modules/WorldLifecycle/Hooks/WorldLifecycleHookRegistry.cs | Hooks | Canon | Registry de hooks por ordem. |
| Modules/WorldLifecycle/Spawn/IWorldSpawnContext.cs | Spawn | Canon | Contrato de contexto de spawn. |
| Modules/WorldLifecycle/Spawn/IWorldSpawnService.cs | Spawn | Canon | Contrato de servi�o de spawn. |
| Modules/WorldLifecycle/Spawn/IWorldSpawnServiceRegistry.cs | Spawn | Canon | Contrato de registry de spawn services. |
| Modules/WorldLifecycle/Spawn/WorldSpawnContext.cs | Spawn | Canon | Implementa��o de contexto de spawn. |
| Modules/WorldLifecycle/Spawn/WorldSpawnServiceFactory.cs | Spawn | Canon | Factory de servi�os de spawn por kind. |
| Modules/WorldLifecycle/Spawn/WorldSpawnServiceRegistry.cs | Spawn | Canon | Registry concreto de spawn services. |
| Modules/WorldLifecycle/WorldRearm/WorldResetContext.cs | WorldRearm | Canon | Contexto de reset de rearm/scopes. |
| Modules/WorldLifecycle/WorldRearm/WorldResetScope.cs | WorldRearm | Canon | Enum/modelo de escopo de reset. |
| Modules/WorldLifecycle/WorldRearm/WorldResetFlags.cs | WorldRearm | Canon | Flags de reset world. |
| Modules/WorldLifecycle/WorldRearm/Domain/WorldResetRequest.cs | WorldRearm | Canon | Request DTO do pipeline WorldReset. |
| Modules/WorldLifecycle/WorldRearm/Domain/WorldResetReasons.cs | WorldRearm | Canon | Raz�es can�nicas/anchors de reset. |
| Modules/WorldLifecycle/WorldRearm/Domain/WorldResetOrigin.cs | WorldRearm | Canon | Origem do reset (SceneFlow/Manual...). |
| Modules/WorldLifecycle/WorldRearm/Domain/ResetFeatureIds.cs | WorldRearm | Canon | Feature IDs para degrade/report. |
| Modules/WorldLifecycle/WorldRearm/Domain/ResetDecision.cs | WorldRearm | Canon | Resultado de guard/validation no pipeline. |
| Modules/WorldLifecycle/WorldRearm/Guards/IWorldResetGuard.cs | WorldRearm | Canon | Contrato de guard. |
| Modules/WorldLifecycle/WorldRearm/Guards/SimulationGateWorldResetGuard.cs | WorldRearm | Canon | Guard por gate de simula��o. |
| Modules/WorldLifecycle/WorldRearm/Validation/IWorldResetValidator.cs | WorldRearm | Canon | Contrato de validator. |
| Modules/WorldLifecycle/WorldRearm/Validation/WorldResetProfileValidator.cs | WorldRearm | Canon | Validator de profile de reset. |
| Modules/WorldLifecycle/WorldRearm/Validation/WorldResetSignatureValidator.cs | WorldRearm | Canon | Validator de signature de reset. |
| Modules/WorldLifecycle/WorldRearm/Validation/WorldResetValidationPipeline.cs | WorldRearm | Canon | Pipeline de validators. |
| Modules/WorldLifecycle/WorldRearm/Policies/IWorldResetPolicy.cs | WorldRearm | Canon | Contrato de policy strict/degraded. |
| Modules/WorldLifecycle/WorldRearm/Policies/ProductionWorldResetPolicy.cs | WorldRearm | Canon | Policy de produ��o para reset. |
| Modules/WorldLifecycle/WorldRearm/Application/WorldResetService.cs | WorldRearm | Canon | Servi�o can�nico de reset; instancia `WorldResetOrchestrator`; fallback publisher em erro. |
| Modules/WorldLifecycle/WorldRearm/Application/WorldResetOrchestrator.cs | WorldRearm | Canon | Orquestrador Guard->Validate->Execute->Publish. |
| Modules/WorldLifecycle/WorldRearm/Application/WorldResetExecutor.cs | WorldRearm | Canon | Executor de reset sobre controllers alvo. |
| Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyDevBootstrap.cs | Dev | Canon (Dev) | Bootstrap de hotkey dev para reset request. |
| Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyBridge.cs | Dev | Canon (Dev) | Bridge hotkey -> `IWorldResetRequestService`. |
| Modules/WorldLifecycle/Dev/WorldLifecycleHookLoggerA.cs | Dev | Canon (Dev) | Logger dev de hooks/ordem. |

Dead confirmed by evidence: **none** (nenhum arquivo sem s�mbolo/callsite relevante foi identificado de forma conclusiva neste escopo).

---

## C) Event Ownership Matrix (publish/consume + evidence)

| Event | Publisher(s) (evidence) | Consumer(s) (evidence) | Canon owner |
|---|---|---|---|
| `WorldLifecycleResetStartedEvent` | `Modules/WorldLifecycle/WorldRearm/Application/WorldResetOrchestrator.cs:156-157` | Nenhum `EventBus<...>.Register` encontrado no escopo (`rg` zero) | `WorldResetOrchestrator` |
| `WorldLifecycleResetCompletedEvent` | `WorldResetOrchestrator.cs:168-169`; fallback em `WorldResetService.cs:69`; fallback/SKIP em `WorldLifecycleSceneFlowResetDriver.cs:256-257` | `WorldLifecycleResetCompletionGate.cs:27-28`; `Modules/GameLoop/Runtime/Bridges/GameLoopSceneFlowCoordinator.cs:57` | `WorldResetOrchestrator` (driver/service apenas fallback) |
| `WorldLifecycleResetRequestedV2Event` | `Modules/WorldLifecycle/Runtime/WorldResetCommands.cs:153` | Nenhum `Register` encontrado (`rg` zero) | `WorldResetCommands` |
| `WorldLifecycleResetCompletedV2Event` | `Modules/WorldLifecycle/Runtime/WorldResetCommands.cs:178` | Nenhum `Register` encontrado (`rg` zero) | `WorldResetCommands` |

### Fallback publisher duplicado (expl�cito)
- `WorldLifecycleSceneFlowResetDriver` publica `WorldLifecycleResetCompletedEvent` em SKIP/fallback:
  - coment�rio de contrato: `Modules/WorldLifecycle/Runtime/WorldLifecycleSceneFlowResetDriver.cs:19`
  - publica��o: `:256-257`
- `WorldResetService` publica `WorldLifecycleResetCompletedEvent` em catch (best-effort):
  - `Modules/WorldLifecycle/WorldRearm/Application/WorldResetService.cs:69`
- Trilho nominal/can�nico de publish permanece em `WorldResetOrchestrator`:
  - `Modules/WorldLifecycle/WorldRearm/Application/WorldResetOrchestrator.cs:168-169`

---

## D) Redundancy Hotspots (with callsites)

1. **Dois orquestradores ativos (coexist�ncia expl�cita)**
- `WorldLifecycleOrchestrator` instanciado por `WorldLifecycleController`:
  - `Modules/WorldLifecycle/Bindings/WorldLifecycleController.cs:391-395`
- `WorldResetOrchestrator` instanciado por `WorldResetService`:
  - `Modules/WorldLifecycle/WorldRearm/Application/WorldResetService.cs:103`
- Risco: nomenclatura pr�xima e sobreposi��o sem�ntica de "orquestrar reset".

2. **Eventos V1/V2 coexistindo em paralelo**
- V1 started/completed: `WorldResetOrchestrator` + completion gate consumers.
- V2 requested/completed: publicados por `WorldResetCommands` sem consumers EventBus no escopo.
- Risco: duplicidade de trilhas observ�veis e potencial drift de contratos.

3. **Overlap API: `WorldResetCommands` vs `WorldResetService`**
- Trilho can�nico SceneFlow (`ScenesReady`) usa `WorldResetService` via driver:
  - `WorldLifecycleSceneFlowResetDriver.cs:185` e `:202`
- `WorldResetCommands.ResetMacroAsync` tamb�m chama `IWorldResetService.TriggerResetAsync`:
  - `WorldResetCommands.cs:34-35`
- `WorldResetCommands.ResetLevelAsync(LevelDefinitionAsset...)` segue trilho local de content swap + V2 events.
- Risco: duas portas de entrada para macro reset com observabilidade diferente (V1/V2).

4. **Fallback publish completion em m�ltiplos pontos**
- Driver fallback e service catch fallback (acima) coexistem com publish nominal do orchestrator.
- Risco: duplicidade de completed em cen�rios degradados (mitigado por dedupe downstream, mas aumenta complexidade).

---

## E) Plano WL-1 (cleanup code) � passos pequenos e seguros

### WL-1.1 � Clarificar ownership dos dois orquestradores (sem mudan�a de runtime)
- A��o: renomear/documentar responsabilidades em c�digo (nomenclatura e coment�rios) mantendo callsites.
- DoD:
  - n�o muda callsite de `WorldLifecycleController.CreateOrchestrator()`.
  - n�o muda callsite de `WorldResetService` para `WorldResetOrchestrator`.
- Logs Baseline que devem continuar:
  - `[OBS][WorldLifecycle] ResetRequested ...`
  - `[OBS][WorldLifecycle] ResetCompleted ...`

### WL-1.2 � Invent�rio formal de V1/V2 e roteamento �nico por dom�nio
- A��o: manter V1 para gate SceneFlow; definir V2 apenas para telemetria de comandos, com documenta��o expl�cita no c�digo.
- DoD:
  - consumers de `WorldLifecycleResetCompletedEvent` continuam iguais.
  - `WorldResetCommands` continua publicando V2 sem quebrar chamadas atuais.
- Logs que devem continuar:
  - `[SceneFlowGate] WorldLifecycleResetCompletedEvent recebido...`
  - `[OBS][WorldLifecycle] ResetCompleted kind='...' ...` (V2 path)

### WL-1.3 � Consolidar fallback publisher policy (sem retirar seguran�a)
- A��o: explicitar prioridade de fallback (driver SKIP/failure + service catch), mantendo comportamento best-effort.
- DoD:
  - nenhum timeout novo no `WorldLifecycleResetCompletionGate`.
  - behavior de SKIP/fallback preservado em dev/release.
- Logs que devem continuar:
  - `[ResetTimeoutProceed] [SceneFlowGate] Timeout ...` (somente em cen�rio real de timeout)
  - `[WARN][DEGRADED][WorldLifecycle] ResetWorld fallback completion enabled ...`

### WL-1.4 � Primeiro passo mais seguro (recomendado)
- **Passo mais seguro:** WL-1.1 (clarifica��o de ownership sem alterar fluxo/evento/DI).
- Motivo: reduz ambiguidade operacional sem tocar contratos V1/V2 nem publishers/consumers.

---

## Evid�ncias externas ao m�dulo (escopo cruzado)
- Registro de servi�os WL no GCR:
  - `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs:138-143`
- Consumer externo de `WorldLifecycleResetCompletedEvent`:
  - `Modules/GameLoop/Runtime/Bridges/GameLoopSceneFlowCoordinator.cs:57`
- Limpeza de evento em bootstrap events clear:
  - `Infrastructure/Composition/GlobalCompositionRoot.Events.cs:40`

---

## Conclus�es r�pidas
- Coexist�ncia de **2 orquestradores** confirmada com callsites concretos.
- Coexist�ncia de **eventos V1/V2** confirmada.
- Publica��o duplicada de completion em **fallback** (driver + service) confirmada.
- Passo WL-1 mais seguro: **clarificar ownership (WL-1.1)** sem mudan�a comportamental.
