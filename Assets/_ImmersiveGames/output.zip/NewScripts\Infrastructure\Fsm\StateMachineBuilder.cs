using _ImmersiveGames.NewScripts.Infrastructure.Predicates;

namespace _ImmersiveGames.NewScripts.Infrastructure.Fsm
{
    /// <summary>
    /// Builder para criar uma StateMachine de forma fluida e modular.
    /// Permite adicionar estados, configurar transições específicas (At) e genéricas (Any),
    /// definir o estado inicial e construir a máquina de estados.
    /// </summary>
    public class StateMachineBuilder
    {
        private readonly StateMachine _stateMachine = new();

        public StateMachineBuilder AddState(IState state, out IState reference)
        {
            reference = Preconditions.CheckNotNull(state, "State cannot be null.");
            _stateMachine.RegisterState(reference);
            return this;
        }

        public StateMachineBuilder At(IState from, IState to, IPredicate predicate)
        {
            Preconditions.CheckNotNull(from, "From state cannot be null.");
            Preconditions.CheckNotNull(to, "To state cannot be null.");
            Preconditions.CheckNotNull(predicate, "Predicate cannot be null.");
            _stateMachine.AddTransition(from, to, predicate);
            return this;
        }

        public StateMachineBuilder Any(IState to, IPredicate predicate)
        {
            Preconditions.CheckNotNull(to, "To state cannot be null.");
            Preconditions.CheckNotNull(predicate, "Predicate cannot be null.");
            _stateMachine.AddAnyTransition(to, predicate);
            return this;
        }

        public StateMachineBuilder StateInitial(IState state)
        {
            Preconditions.CheckNotNull(state, "Initial state cannot be null.");
            _stateMachine.SetState(state);
            return this;
        }

        public StateMachine Build()
        {
            return _stateMachine;
        }
    }
}
