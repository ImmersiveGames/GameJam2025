﻿A seguir está um **plano técnico incremental (passo a passo)**, com **checklists** e **critérios de validação**, alinhado ao ADR-0016 (fonte de verdade) .

---

## Objetivos técnicos (derivados do ADR)

1. **Phase é input do Reset** (não do SceneFlow).
2. Dois caminhos explícitos:

    * **InPlacePhaseChange** (mesmas cenas, reset no local).
    * **SceneFlowPhaseTransition** (fade/loading/troca de cenas, reset canônico em `ScenesReady`).
3. **PreReveal (PreGame)** é **apresentação opcional**, **nunca bloqueante**, com **timeout**, executada **entre** `WorldLifecycleResetCompleted` e `FadeOut`.

---

## Princípios de arquitetura a manter

* **SRP:** Phase ≠ SceneFlow ≠ Presentation.
* **OCP:** adicionar novas fases e novas apresentações sem alterar orquestradores centrais.
* **DIP:** orquestração depende de interfaces (serviços/gates), não de cenas específicas.
* **Determinismo:** phase só “vira realidade” quando aplicada em reset (in-place ou canônico).

---

## Plano incremental por marcos (testáveis e validáveis)

### Marco 0 — Baseline de observabilidade (pré-requisito)

**Objetivo:** garantir que cada etapa futura tenha evidência objetiva (logs + asserts leves).

**Implementar**

* Padronizar **assinaturas de log** (string constants) para:

    * `PhaseRequested(phaseId, reason)`
    * `ResetRequested(sourceSignature)`
    * `PreRevealStarted(id)` / `PreRevealCompleted(id, outcome, elapsedMs)`
    * `PreRevealSkipped(reason)`
    * `PreRevealTimeout(timeoutMs)`
* Introduzir um “**test harness**” (editor/QA) mínimo para disparar:

    * RequestPhase (in-place)
    * Navigate (scene-flow)
    * PreReveal on/off

**Checklist**

* [ ] Constants de assinatura criadas e usadas em pontos-chave.
* [ ] Logs aparecem 1x por execução (evitar spam).
* [ ] Harness permite reproduzir sem depender de GameplayScene “instável”.

**Validação**

* Evidência por log: ao rodar o harness, você consegue “ler o fluxo” sem ambiguidade.

---

### Marco 1 — Contratos de Phase (sem alterar fluxo ainda)

**Objetivo:** isolar o conceito de phase como **estado solicitado** + **estado aplicado**.

**Implementar (interfaces e modelo)**

* `IWorldPhaseService`

    * `PhaseId CurrentRequested { get; }`
    * `PhaseId LastApplied { get; }`
    * `void RequestPhase(PhaseId id, string reason)`
* `PhaseId` (value object / struct simples) e convenção de ids.
* Integração com o reset:

    * No início do reset (ou antes do spawn), capturar `CurrentRequested` e marcar como `LastApplied`.

**Checklist**

* [ ] RequestPhase não executa reset nem navegação (somente registra intenção).
* [ ] Reset lê phase solicitada e “aplica” como `LastApplied` de forma atômica.
* [ ] Logs: `PhaseRequested` e `PhaseApplied` (quando reset roda).

**Validação**

* Rodar um reset canônico atual (sem mudanças de cena) e verificar:

    * `PhaseRequested` → (no reset) `PhaseApplied`.

---

### Marco 2 — InPlacePhaseChange (caminho 1 do ADR)

**Objetivo:** permitir “fase 1 → fase 2” no mesmo gameplay **sem SceneFlow**, via reset local.

**Implementar**

* Um serviço de comando (ou caso de uso) para orquestrar:

    * `RequestPhase(phaseId, reason)`
    * `RequestResetAsync(source="Phase/InPlace/...")` (via `IWorldResetRequestService`)
* Garantir que **o reset é total** (despawn/spawn pipeline) e que a fase entra como input do spawn.

**Checklist**

* [ ] Não toca em `SceneTransitionService` nem `IGameNavigationService`.
* [ ] `sourceSignature` do reset identifica claramente “Phase/InPlace”.
* [ ] Idempotência: chamar 2x a mesma fase não cria estado quebrado (apenas reaplica no reset).
* [ ] Spawn pipeline consegue ler `LastApplied` para selecionar conteúdo.

**Validação**

* Harness: tecla/botão “Next Phase (InPlace)”:

    * Logs esperados:

        * `PhaseRequested(P2)`
        * `ResetRequested(Phase/InPlace/...)`
        * `PhaseApplied(P2)`
        * spawn condizente com P2 (mesmo que seja só “dummy spawn” inicialmente)

---

### Marco 3 — SceneFlowPhaseTransition (caminho 2 do ADR)

**Objetivo:** troca de fase **com transição completa** (fade/loading/troca de cenas) mantendo reset canônico em `ScenesReady`.

**Implementar**

* No fluxo de navegação:

    * `RequestPhase(phaseId, reason)` **antes** de `NavigateAsync(...)`
    * `NavigateAsync` executa transição normal
    * Em `ScenesReady`, o reset canônico ocorre e aplica a phase solicitada
* Garantir que “phase solicitada” sobrevive à transição (serviço global/scoped corretamente).

**Checklist**

* [ ] Phase é solicitada antes de navegar.
* [ ] Reset continua disparando em `ScenesReady` (sem atalhos).
* [ ] Logs exibem ordem inequívoca:

    * `PhaseRequested` → `SceneTransitionStarted` → `ScenesReady` → `Reset...` → `PhaseApplied`

**Validação**

* Harness: botão “Go Gameplay Phase 2 (SceneFlow)”:

    * Fade + load/unload + `ScenesReady`
    * Reset canônico
    * `PhaseApplied(P2)` antes do spawn.

---

### Marco 4 — PreRevealGate (apresentação opcional e não-bloqueante)

**Objetivo:** inserir a etapa **PreReveal** entre `WorldLifecycleResetCompleted` e `FadeOut`, **sem quebrar Baseline 2.0**.

**Implementar**

* `IPreRevealService` (ou `IPreRevealStep`) com contrato explícito:

    * `bool HasStepFor(context)`
    * `Task RunAsync(context, CancellationToken ct)`
* `PreRevealGate` como “completion gate” adicional:

    * Composição: `WorldLifecycleResetCompletionGate` + `PreRevealGate`
    * Se não configurado: completa imediatamente
    * Se configurado: roda com **timeout** e sempre completa (success/skip/timeout)
* Regras mandatórias:

    * timeout hard
    * cancellation token respeitado
    * nunca impede `FadeOut` definitivo

**Checklist**

* [ ] Gate compõe sem alterar a semântica atual quando PreReveal está OFF.
* [ ] Timeout configurável (e com default seguro).
* [ ] Logs por outcome: started/completed/skipped/timeout.
* [ ] “Sem PreReveal” = comportamento idêntico ao atual.

**Validação**

* Caso A: PreReveal OFF → não muda nada (mesmos logs do baseline).
* Caso B: PreReveal ON (dummy 0.5s) → aparece `PreRevealStarted/Completed` e depois `FadeOut`.
* Caso C: PreReveal travado (simulado) → `PreRevealTimeout` e segue para `FadeOut`.

---

### Marco 5 — Catálogo de PreReveal (exemplos “seguros”)

**Objetivo:** provar extensibilidade sem acoplamento em cena.

**Implementar exemplos**

* `PhaseCardPreReveal`: mostra “Fase X” por N segundos (UI overlay simples).
* `CutscenePreRevealStub`: placeholder que termina sozinho.
* `WarmupPreReveal`: prewarm leve (sem tocar GameplayScene diretamente).

**Checklist**

* [ ] Nenhum PreReveal depende de tipos concretos da GameplayScene.
* [ ] PreReveal roda com cortina fechada e sempre finaliza.
* [ ] Cada step é testável isoladamente (injeção de dependências).

**Validação**

* Trocar o step via DI/config sem alterar orquestrador.

---

### Marco 6 — Checklist final de regressão (Baseline 2.0 + novos cenários)

**Objetivo:** consolidar matriz de verificação para fases.

**Novos cenários mínimos**

* [ ] **InPlacePhaseChange** dentro do gameplay: P1→P2 sem troca de cena.
* [ ] **SceneFlowPhaseTransition**: Menu→Gameplay com phase pré-selecionada.
* [ ] PreReveal OFF (no-op)
* [ ] PreReveal ON (completa)
* [ ] PreReveal TIMEOUT (não bloqueia)

**Invariantes**

* [ ] Reset canônico continua em `ScenesReady` quando há transição de cenas.
* [ ] PreReveal nunca impede `FadeOut`.
* [ ] Phase só é considerada aplicada quando reset roda (`LastApplied`).

---

## Estrutura sugerida do documento técnico (para vocês versionarem no repo)

Você pode criar algo como:

* `Assets/_ImmersiveGames/NewScripts/Docs/Plans/Phases-Implementation-Plan.md`

Conteúdo:

1. Escopo e não-escopo (referenciando ADR-0016)
2. Marcos 0–6 (como acima)
3. Checklists
4. Assinaturas de log obrigatórias
5. Critérios de aceitação por marco

---

## Próximo passo prático (para iniciar implementação sem risco)

Se você quiser executar já o **primeiro incremento com ganho imediato**, comece pelo:

* **Marco 0 (observabilidade)** + **Marco 1 (contratos de phase)**

Isso não mexe em SceneFlow nem em Fade/Loading, mas cria a base para validar tudo o que vem depois.

---

Se você colar aqui a **lista real de serviços existentes** (interfaces/classes) que hoje participam de:

* `IWorldResetRequestService`
* `WorldLifecycle...ResetCompletedEvent`
* “Completion Gate” atual entre reset e fade-out

eu adapto este plano para nomes e pontos de extensão exatamente do seu código, sem inventar contratos.
