# RM-1.1 - RuntimeMode + Logging governance audit

Date: 2026-03-07
Status: DOC-only

## Escopo
- `Infrastructure/RuntimeMode/**`
- `Core/Logging/**`
- `Infrastructure/Composition/GlobalCompositionRoot.Entry.cs`
- `Infrastructure/Composition/GlobalCompositionRoot.*.cs` que tocam runtime policy/logging

## 1) Inventario por evidencia
### Entry points
Comando:
```text
rg -n "RuntimeInitializeOnLoadMethod|InitializeOnLoadMethod|DidReloadScripts|ExecuteAlways" Assets/_ImmersiveGames/NewScripts -g "*.cs"
```
Resultado curto:
- `Core/Logging/DebugUtility.cs:51: [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]`
- `Infrastructure/Composition/GlobalCompositionRoot.Entry.cs:61: [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]`
- `Editor/Core/Events/EventBusUtil.Editor.cs:8: [InitializeOnLoadMethod]`
Resumo:
- entrypoints runtime reais no escopo auditado: 2
- hook de editor encontrado fora do escopo de governanca de runtime mode/logging: `EventBusUtil.Editor.cs`

### Defines / toggles
Comando:
```text
rg -n "NEWSCRIPTS_|DEVELOPMENT_BUILD|UNITY_EDITOR|BASELINE_ASSERTS|DEBUG|TRACE" Assets/_ImmersiveGames/NewScripts -g "*.cs"
```
Resultado curto:
- `Infrastructure/RuntimeMode/UnityRuntimeModeProvider.cs`: `UNITY_EDITOR`, `DEVELOPMENT_BUILD`
- `Infrastructure/Composition/GlobalCompositionRoot.Entry.cs`: `!NEWSCRIPTS_MODE`
- `Core/Logging/DebugUtility.cs`: `#if NEWSCRIPTS_MODE`
- `Infrastructure/Composition/GlobalCompositionRoot.Baseline.cs` e `.Pipeline.cs`: `NEWSCRIPTS_BASELINE_ASSERTS`
- `Dev/Core/Logging/DebugManagerConfig*.cs`: `UNITY_EDITOR || DEVELOPMENT_BUILD`
Resumo:
- toggles reais de governanca: `NEWSCRIPTS_MODE`, `UNITY_EDITOR`, `DEVELOPMENT_BUILD`, `NEWSCRIPTS_BASELINE_ASSERTS`
- `DEBUG` e `TRACE` nao apareceram como gates relevantes no escopo

### Logging policy write sites
Comando:
```text
rg -n "Configure|ConfigureLogging|LogLevel|DebugManagerConfig|DebugLogSettings|Set.*Log|Initialize.*Logging" Assets/_ImmersiveGames/NewScripts/Core/Logging Assets/_ImmersiveGames/NewScripts/Infrastructure -g "*.cs"
```
Resultado curto:
- `Core/Logging/DebugUtility.cs:85: SetVerboseLogging`
- `Core/Logging/DebugUtility.cs:86: SetLogFallbacks`
- `Infrastructure/Composition/GlobalCompositionRoot.Entry.cs:76: InitializeLogging();`
- `Infrastructure/Composition/GlobalCompositionRoot.Entry.cs:96: private static void InitializeLogging()`
Resumo:
- writer runtime canonico observado: `GlobalCompositionRoot.Entry.InitializeLogging()` sobre `DebugUtility`
- writer dev-only observado: `Dev/Core/Logging/DebugManagerConfig.ApplyConfiguration()`

### Consumers do runtime mode config
Comando:
```text
rg -n "RuntimeModeConfig|IRuntimeMode|runtimeMode|NEWSCRIPTS_MODE" Assets/_ImmersiveGames/NewScripts/Infrastructure Assets/_ImmersiveGames/NewScripts/Modules -g "*.cs"
```
Resultado curto:
- `Infrastructure/Composition/GlobalCompositionRoot.RuntimePolicy.cs` registra `RuntimeModeConfig`, `IRuntimeModeProvider`, `IDegradedModeReporter` e `IWorldResetPolicy`
- `Infrastructure/Composition/GlobalCompositionRoot.InputModes.cs` consome `RuntimeModeConfig.inputModes`
- `Infrastructure/Composition/GlobalCompositionRoot.BootstrapConfig.cs` resolve `RuntimeModeConfig.NewScriptsBootstrapConfig`
- `Modules/SceneFlow/Loading/Runtime/LoadingHudService.cs`, `Modules/WorldLifecycle/.../ProductionWorldResetPolicy.cs`, `Modules/ContentSwap/Runtime/InPlaceContentSwapService.cs`, `Modules/Gameplay/.../DefaultRunRearmTargetClassifier.cs` consomem `IRuntimeModeProvider`
Resumo:
- consumo de runtime mode e real e transversal, com owner central no trilho `Infrastructure/RuntimeMode` + `GlobalCompositionRoot.RuntimePolicy`

## 2) Classificacao A/B/C/D (DOC-only)
### A canonical
- `Core/Logging/DebugUtility.cs`
- `Infrastructure/Composition/GlobalCompositionRoot.Entry.cs`
- `Infrastructure/RuntimeMode/RuntimeModeConfig.cs`
- `Infrastructure/RuntimeMode/RuntimeModeConfigLoader.cs`
- `Infrastructure/RuntimeMode/IRuntimeModeProvider.cs`
- `Infrastructure/RuntimeMode/UnityRuntimeModeProvider.cs`
- `Infrastructure/RuntimeMode/ConfigurableRuntimeModeProvider.cs`
- `Infrastructure/RuntimeMode/DegradedModeReporter.cs`
- `Infrastructure/Composition/GlobalCompositionRoot.RuntimePolicy.cs`
### B dev-only
- `Dev/Core/Logging/DebugManagerConfig.cs`
- `Dev/Core/Logging/DebugManagerConfig.DevQA.cs`
- `Dev/Core/Logging/DebugLogSettings.cs`
### C reserve
- nenhum candidato forte novo no escopo primario; hotspots atuais sao de governanca, nao de superficie morta
### D legacy compat
- nenhum candidato explicito novo no escopo primario auditado

## 3) Riscos reais suportados por evidencia
- multiplos writers da policy de logging: runtime default em `GlobalCompositionRoot.Entry.InitializeLogging()` e writer dev-only em `DebugManagerConfig.ApplyConfiguration()`
- toggles em camadas diferentes: `NEWSCRIPTS_MODE` controla boot inteiro, `RuntimeModeConfig.modeOverride` controla strict/release, `NEWSCRIPTS_BASELINE_ASSERTS` injeta asserts fora do eixo de logging
- leitura duplicada de `RuntimeModeConfig`: `RuntimePolicy` para DI/policy e `BootstrapConfig` para resolver `NewScriptsBootstrapConfig`
- nao houve evidencia de entrypoints runtime redundantes: apenas 2 entrypoints can�nicos no workspace local

## Conclusao
- boot can�nico: `DebugUtility.Initialize` -> `GlobalCompositionRoot.Entry.Initialize` -> `InitializeLogging` -> `RegisterRuntimePolicyServices`
- policy can�nica de logging no runtime: `DebugUtility`
- policy can�nica de runtime mode: `RuntimeModeConfig` + `IRuntimeModeProvider` + `ConfigurableRuntimeModeProvider`
- `DebugManagerConfig`/`DebugLogSettings` permanecem trilho dev-only, fora da governanca de release

## Arquivos relacionados
- `Docs/Modules/RuntimeMode-Logging.md`
- `Docs/Reports/Audits/2026-03-06/Audit-Index.md`
- `Docs/Reports/Audits/2026-03-06/Module-Audit-Summary.md`
