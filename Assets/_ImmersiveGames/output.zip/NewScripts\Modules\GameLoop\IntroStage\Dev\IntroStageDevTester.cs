#nullable enable
using System;
using System.Collections;
using _ImmersiveGames.NewScripts.Core.Composition;
using _ImmersiveGames.NewScripts.Core.Logging;
using _ImmersiveGames.NewScripts.Modules.SceneFlow.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;
namespace _ImmersiveGames.NewScripts.Modules.GameLoop.IntroStage.Dev
{
    /// <summary>
    /// QA helper para:
    /// - Disparar IntroStageController manualmente (sem depender do SceneFlow).
    /// - Forçar Complete/Skip da IntroStageController (o gatilho canônico que destrava o gameplay).
    /// - (Opcional) Auto-Complete com delay usando Coroutine (main thread), evitando Task/threads.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class IntroStageDevTester : MonoBehaviour
    {
        [Header("Run IntroStageController QA")]
        [SerializeField] private string qaSignature = "qa.introstage";
        [SerializeField] private string qaReason = "QA/IntroStageOptional";

        [Header("Completion QA")]
        [SerializeField, Min(0f)] private float autoCompleteDelaySeconds = 0.5f;

        private Coroutine? _autoCompleteRoutine;

        [ContextMenu("QA/LevelFlow/IntroStage/Run Optional (TestCase: IntroStageOptional)")]
        private async void QA_RunIntroStageOptional()
        {
            var coordinator = ResolveCoordinator();
            if (coordinator == null)
            {
                DebugUtility.LogWarning<IntroStageDevTester>(
                    "[QA][IntroStageController] IIntroStageCoordinator não encontrado no DI global.");
                return;
            }

            string? activeScene = SceneManager.GetActiveScene().name;
            var context = new IntroStageContext(
                contextSignature: qaSignature,
                profileId: SceneFlowProfileId.Gameplay,
                targetScene: activeScene,
                reason: qaReason);

            try
            {
                DebugUtility.Log<IntroStageDevTester>(
                    $"[QA][IntroStageController] RunIntroStageOptional solicitado. signature='{qaSignature}' scene='{activeScene}'.",
                    DebugUtility.Colors.Info);

                await coordinator.RunIntroStageAsync(context);
            }
            catch (Exception ex)
            {
                DebugUtility.LogWarning<IntroStageDevTester>(
                    $"[QA][IntroStageController] Falha ao executar IntroStageController QA. ex='{ex.GetType().Name}: {ex.Message}'.");
            }
        }

        [ContextMenu("QA/LevelFlow/IntroStage/Complete Active (Force)")]
        private void QA_CompleteActiveIntroStage_Force()
        {
            CancelAutoCompleteIfRunning();

            var control = ResolveControlService();
            if (control == null)
            {
                DebugUtility.LogWarning<IntroStageDevTester>(
                    "[QA][IntroStageController] IIntroStageControlService não encontrado no DI global; Complete ignorado.");
                return;
            }

            control.CompleteIntroStage("QA/IntroStageDevTester/Complete");
            DebugUtility.Log<IntroStageDevTester>(
                "[QA][IntroStageController] CompleteIntroStage solicitado (Force).",
                DebugUtility.Colors.Info);
        }

        [ContextMenu("QA/LevelFlow/IntroStage/Skip Active (Force)")]
        private void QA_SkipActiveIntroStage_Force()
        {
            CancelAutoCompleteIfRunning();

            var control = ResolveControlService();
            if (control == null)
            {
                DebugUtility.LogWarning<IntroStageDevTester>(
                    "[QA][IntroStageController] IIntroStageControlService não encontrado no DI global; Skip ignorado.");
                return;
            }

            control.SkipIntroStage("QA/IntroStageDevTester/Skip");
            DebugUtility.Log<IntroStageDevTester>(
                "[QA][IntroStageController] SkipIntroStage solicitado (Force).",
                DebugUtility.Colors.Info);
        }

        [ContextMenu("QA/LevelFlow/IntroStage/Auto-Complete in 0.5s (Force)")]
        private void QA_AutoCompleteActiveIntroStage_Force()
        {
            CancelAutoCompleteIfRunning();
            _autoCompleteRoutine = StartCoroutine(AutoCompleteRoutine());
        }

        private IEnumerator AutoCompleteRoutine()
        {
            float delay = Mathf.Max(0f, autoCompleteDelaySeconds);
            DebugUtility.Log<IntroStageDevTester>(
                $"[QA][IntroStageController] Auto-Complete agendado. delay='{delay:0.###}s'.",
                DebugUtility.Colors.Info);

            yield return new WaitForSecondsRealtime(delay);

            var control = ResolveControlService();
            if (control == null)
            {
                DebugUtility.LogWarning<IntroStageDevTester>(
                    "[QA][IntroStageController] IIntroStageControlService indisponível; Auto-Complete abortado.");
                _autoCompleteRoutine = null;
                yield break;
            }

            control.CompleteIntroStage("QA/IntroStageDevTester/AutoComplete");
            DebugUtility.Log<IntroStageDevTester>(
                "[QA][IntroStageController] Auto-Complete executado (CompleteIntroStage).",
                DebugUtility.Colors.Info);

            _autoCompleteRoutine = null;
        }

        private void CancelAutoCompleteIfRunning()
        {
            if (_autoCompleteRoutine != null)
            {
                StopCoroutine(_autoCompleteRoutine);
                _autoCompleteRoutine = null;
            }
        }

        private static IIntroStageCoordinator? ResolveCoordinator()
        {
            return DependencyManager.Provider.TryGetGlobal<IIntroStageCoordinator>(out var coordinator)
                ? coordinator
                : null;
        }

        private static IIntroStageControlService? ResolveControlService()
        {
            return DependencyManager.Provider.TryGetGlobal<IIntroStageControlService>(out var control)
                ? control
                : null;
        }
    }
}


