﻿# ADR-0018 — Gate de Promoção do Baseline 2.1 → 2.2 (WorldCycle Config-Driven)

## Status
- Estado: Aceito
- Data: 2026-01-18
- Escopo: Docs/Reports + critérios de promoção (Baseline 2.2)

## Contexto

O Baseline 2.1 estabeleceu um pipeline canônico estável e verificável por logs/evidências:

`SceneFlow → ScenesReady → WorldLifecycleResetCompleted → Completion Gate → FadeOut/Completed`

A evolução para o Baseline 2.2 introduz uma camada “por cima” (WorldCycle config-driven) que depende da estabilidade do contrato base.
Para evitar regressões e “promoção por sensação”, a promoção para 2.2 deve ser condicionada a critérios objetivos (“gates”) verificáveis por evidência datada.

Este ADR define esses gates e estabelece a regra: a promoção não é declarada aqui; ela é declarada em um ADR separado (ADR-0019) após todos os gates PASS.

## Decisão

1) Adotar um conjunto de gates objetivos (G-01…G-04) como critério de “pronto para promover Baseline 2.2”.

2) Exigir evidência datada para fechamento dos gates:
    - Snapshot em `Docs/Reports/Evidence/<YYYY-MM-DD>/`
    - Log bruto (Console) + verificação curada (âncoras/invariantes)
    - Atualização de `Docs/Reports/Evidence/LATEST.md` para apontar para o snapshot vigente

3) A promoção Baseline 2.1 → 2.2 só pode ser declarada via ADR-0019:
    - ADR-0019 referencia explicitamente o snapshot datado onde todos os gates PASS
    - ADR-0019 registra o “ato” de promoção (data, evidência, escopo)

### Gates obrigatórios

#### G-01 — Phases Nível B “fechado” (contrato visual do In-Place)
**Motivação**
O In-Place não pode virar “SceneTransition disfarçada” e não pode introduzir ruído visual como padrão.

**Critério de aceite**
- PhaseChange/In-Place:
    - não usa SceneFlow;
    - não exibe Loading HUD (por design);
    - no teste padrão de evidência, ocorre sem Fade/HUD (sem ruído visual).
- O QA do In-Place não pode habilitar opções visuais que violem o contrato do checklist.

**Evidência exigida**
- Snapshot datado contendo:
    - log bruto do Console
    - verificação curada com âncoras demonstrando:
        - ausência de logs `[Fade]` e `[LoadingHUD]` entre “solicitação” e “PhaseCommitted”
        - ordem: `PhasePendingSet → Reset → PhaseCommitted`
- Atualizar `Docs/ADRs/Checklist-phase.md` movendo o item 2.1 para PASS com referência ao snapshot.

#### G-02 — Coerência do contrato de observabilidade (reasons + links + fonte de verdade)
**Motivação**
`Observability-Contract.md` é fonte de verdade. Ambiguidade em reasons/links vira regressão por interpretação.

**Critério de aceite**
1. Link válido para índice de reasons
    - Se o contrato referencia `Reason-Map.md`, deve existir e estar versionado, OU a referência deve ser removida/ajustada para o que é canônico.
2. Regra oficial (documentada) para reason:
    - reason do `WorldLifecycleResetCompletedEvent(signature, reason)`
    - reason usado por driver/controller nos logs
    - Se forem diferentes, a diferença deve ser explicitada como regra (não como “acidente”).

**Evidência exigida**
- Snapshot datado contendo âncoras que mostrem:
    - `WorldLifecycleResetCompletedEvent(signature, reason)` com o formato canônico
    - invariantes preservados: Started → ScenesReady → ResetCompleted → Completed

#### G-03 — Docs sem drift (arquitetura/índices sem links quebrados)
**Motivação**
O Baseline 2.2 adiciona camada nova (WorldCycle). Docs inconsistentes tornam a evolução reativa.

**Critério de aceite**
- `Docs/ARCHITECTURE.md`
    - corrigir referências de ADR (ex.: fechamento Baseline 2.0 em ADR-0015)
    - remover/corrigir links para relatórios inexistentes; apontar apenas para documentos canônicos existentes
- `Docs/README.md`
    - alinhar descrições para refletir o runtime atual (sem citar integrações “obsoletas” como se fossem primárias)
- Nenhum link quebrado para `Reports/*` e `ADRs/*` na árvore de docs base

**Evidência exigida**
- Commit/PR documental (sem necessidade de mudança de runtime), com revisão de links e apontamento para `Evidence/LATEST.md`.

### Gate condicional

#### G-04 — Trigger de produção para ResetWorld operacionalizado (apenas se Baseline 2.2 depender disso)
**Motivação**
Se o 2.2 depender de reset fora do SceneFlow em produção (ex.: reconfig por fase sem transição), precisa existir trigger de produção.

**Critério de aceite (se aplicável)**
- Existe um caminho de produção para disparar reset direto com reason canônico `ProductionTrigger/<source>`
- É best-effort (não trava fluxo) e sempre emite `WorldLifecycleResetCompletedEvent`

**Evidência exigida**
- Snapshot datado com âncora mostrando `ProductionTrigger/<source>` e o `ResetCompleted` correspondente.

## Fora de escopo
- Implementar WorldCycleDefinition em runtime (isso é o conteúdo do Baseline 2.2 e do plano 2.2)
- Refatorações grandes de SceneFlow/GameLoop fora do necessário para fechar gates
- Navegação 100% data-driven substituindo `GameNavigationCatalog`

## Consequências

### Benefícios
- Promoção para 2.2 baseada em critérios objetivos, não “sensação”
- Reduz risco de regressão documental/observabilidade
- Deixa explícito o que deve estar “fechado” antes de subir a camada WorldCycle

### Trade-offs / Riscos
- Exige disciplina de evidência (snapshot datado + verificação curada)
- Pode “parecer burocrático”, mas previne retrabalho quando o 2.2 começar

## Notas de implementação
- Ao fechar gates: atualizar `Docs/Reports/Evidence/LATEST.md` e registrar no changelog documental (se existir).
- Após G-01..G-03 PASS (e G-04 se aplicável), criar ADR-0019 para declarar a promoção.

## Evidências
- Metodologia: `Docs/Reports/Evidence/README.md`
- Evidência vigente (ponte): `Docs/Reports/Evidence/LATEST.md`
- Checklist de fases: `Docs/ADRs/Checklist-phase.md`

## Referências
- [ADR-0015 — Baseline 2.0: Fechamento Operacional](ADR-0015-Baseline-2.0-Fechamento.md)
- [ADR-0016 — Phases + modos de avanço + IntroStage opcional](ADR-0016-Phases-WorldLifecycle.md)
- [ADR-0017 — Tipos de troca de fase (In-Place vs SceneTransition)](ADR-0017-Tipos-de-troca-fase.md)
- [Plano 2.2 — WorldCycle Config-Driven](../Reports/plano2.2.md)
- [WORLD_LIFECYCLE.md](../WORLD_LIFECYCLE.md)
- [Observability-Contract.md](../Reports/Observability-Contract.md)
