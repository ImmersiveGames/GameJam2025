# GameLoop Module Audit

## A) Scope
- Entra: `Modules/GameLoop/**` e integra��es de runtime (`Runtime`, `Commands`, `IntroStage`, `Bindings`).
- EventBus inputs: `SceneTransitionStartedEvent`, `SceneTransitionCompletedEvent`, `WorldLifecycleResetCompletedEvent`, pause/resume/exit.
- Chamadas publicas: `IGameLoopService`, `IGameCommands`, `IGameRunStateService`, `IGameRunOutcomeService`.
- Unity callbacks: bindings (`GameLoopBootstrap`, `GameLoopDriver`, controllers de UI/pause/end conditions).

## B) Outputs
- Publica eventos de run/start/end/reset intent via contratos de GameLoop.
- Emite `GameResetRequestedEvent` via `GameCommands`.
- Efeito em Gate/InputMode: indireto (consome sinais do SceneFlow/InputMode para RequestReady/Resume/Start).

## C) DI Registration
- `Infrastructure/Composition/GlobalCompositionRoot.GameLoop.cs`:
  - `IGameCommands` -> `GameCommands`
  - `IGameRunEndRequestService` -> `GameRunEndRequestService`
  - `IGameRunStateService` -> `GameRunStateService`
  - `IGameRunOutcomeService` -> `GameRunOutcomeService`
  - `IIntroStageCoordinator`, `IIntroStageControlService`, `IIntroStagePolicyResolver`, `IIntroStageStep`
  - `IPostGameOwnershipService` -> `PostGameOwnershipService`
- `GlobalCompositionRoot.Coordinator.cs`: registra `GameLoopSceneFlowCoordinator` se dependencies existirem.

## D) Canonical Runtime Rail
- Start/restart can�nico no ecossistema: `GameCommands.RequestRestart` -> `EventBus<GameResetRequestedEvent>.Raise` -> owner de restart em Navigation (`MacroRestartCoordinator`) -> `ILevelFlowRuntimeService.StartGameplayDefaultAsync`.
- Dentro de GameLoop, trilho can�nico de estado: `GameLoopService` + `GameLoopSceneFlowCoordinator` + `IntroStageCoordinator`.

## E) LEGACY/Compat
- `Modules/GameLoop/Runtime/Bridges/GameLoopCommandEventBridge.cs`: listener de `GameResetRequestedEvent` explicitamente desativado com marcador `[OBS][LEGACY]`.

## F) Redundancy Candidates
- `Modules/GameLoop/Runtime/Bridges/GameLoopCommandEventBridge.cs` - bridge ainda existe com ramo legacy desativado; risco baixo.
- `Modules/GameLoop/Runtime/Bridges/GameLoopSceneFlowCoordinator.cs` e `Modules/InputModes/Interop/SceneFlowInputModeBridge.cs` ambos atuam sobre sincroniza��o de estado por `SceneTransitionCompletedEvent`; risco medio.
- `Modules/GameLoop/Bindings/Bootstrap/GameLoopBootstrap.cs` + composi��o global podem gerar duplicidade de ponto de registro; risco medio se ordem mudar.

## G) Deletion/Merge Plan (DOC-ONLY)
- Manter `GameLoopCommandEventBridge` sem reset listener ate remo��o definitiva da compat.
- Consolidar regra de sincroniza��o SceneFlow->GameLoop para reduzir sobreposi��o com InputModeBridge.
- Documentar owner unico por evento de transi��o em Runtime.

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Modules/GameLoop/Commands/GameCommands.cs | Runtime | `RequestRestart`, `RequestPause`, `RequestResume` | N/A | `GameResetRequestedEvent` | `IGameCommands` | Canon (publisher reset) |
| Modules/GameLoop/Runtime/Services/GameLoopService.cs | Runtime | `RequestReady`, `RequestReset`, `RequestPause`, `RequestResume` | eventos de run via bridges | eventos de run | `IGameLoopService` (via bootstrap) | Canon |
| Modules/GameLoop/Runtime/Bridges/GameLoopSceneFlowCoordinator.cs | Runtime | ctor/Dispose | `SceneTransitionStartedEvent`, `SceneTransitionCompletedEvent`, `WorldLifecycleResetCompletedEvent` | requisicoes de estado no loop | concrete coordinator | Canon |
| Modules/GameLoop/Runtime/Bridges/GameLoopCommandEventBridge.cs | Runtime | ctor/Dispose | `GamePauseCommandEvent`, `GameResumeRequestedEvent`, `GameExitToMenuRequestedEvent` | N/A | concrete bridge | Legacy reset path disabled |
| Modules/GameLoop/IntroStage/Runtime/IntroStageCoordinator.cs | Runtime | `RunIntroStageAsync` | N/A | efeitos de intro/run | `IIntroStageCoordinator` | Canon |
| Modules/GameLoop/Bindings/Bootstrap/GameLoopBootstrap.cs | Runtime | `Ensure(...)` | N/A | N/A | bootstrap runtime services | Canon |