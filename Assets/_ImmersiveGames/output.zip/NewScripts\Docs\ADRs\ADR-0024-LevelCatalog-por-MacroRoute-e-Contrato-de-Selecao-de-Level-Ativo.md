# ADR-0024 - LevelCollection por MacroRoute e Contrato de Selecao de Level Ativo

## Status

- Estado: **Aceito (Implementado)**
- Data (decisao): 2026-02-19
- Ultima atualizacao: 2026-03-05

## Mini-resumo (Status atual + contrato can�nico)

- Identidade de level no can�nico: `LevelDefinitionAsset` (`levelRef`).
- Fonte unica em gameplay: `SceneRouteDefinitionAsset.LevelCollection`.
- Colecao ordenada; default = `levels[0]`.
- Gate executa `PrepareOrClear` antes do FadeOut.
- Macro sem `LevelCollection`: `LevelClear` (idempotente: sem ativo => skip observado).
- Mudanca de macro invalida selecao anterior por unload/clear.

## Evidencia (log)

- `lastlog:737` `StartGameplayRouteAsync without level selection; default will be selected in LevelPrepare.`
- `lastlog:1145` `LevelDefaultSelected ... levelRef='Level1'`
- `lastlog:1155` `ResetRequested kind='Level' ... contentId='level-ref:Level1'`
- `lastlog:2181` `LevelAdditiveClearSummary ...`
- `lastlog:2185` `LevelCleared ...`
- `lastlog:2254` `LevelClearSkipped reason='no_active_level' ...`
- `lastlog:1211` `IntroStageStartRequested ... levelSignature='level:Level1|route:to-gameplay|reason:Menu/PlayButton'`
- `lastlog:1459` `PostLevelActionRequested action='RestartLevel' ...`

## Observacao LEGADO

- Referencias a `LevelCatalog`, `levelId` e `contentId` como identidade pertencem ao legado.
