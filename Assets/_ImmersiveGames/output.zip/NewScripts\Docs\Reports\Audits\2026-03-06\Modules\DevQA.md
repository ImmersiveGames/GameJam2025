# DevQA Module Audit

## A) Scope
- Entra: `Modules/**/Dev/**`, `Modules/**/Editor/**` e instaladores acionados por `Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs`.
- EventBus inputs: variavel por ferramenta dev (ex.: listeners de validacao/contagem).
- Chamadas publicas: `EnsureInstalled()` de installers e menus de QA.
- Unity callbacks: context menus, editor tools e bootstrap dev.

## B) Outputs
- Instala gameobjects/menu tools de QA em runtime dev/editor.
- Adiciona observabilidade adicional e comandos de teste para SceneFlow/LevelFlow/IntroStage/ContentSwap.
- Efeito em Gate/InputMode: indireto, via comandos de QA que acionam trilhos de runtime.

## C) DI Registration
- `Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs` chama:
  - `IntroStageDevInstaller.EnsureInstalled()`
  - `ContentSwapDevInstaller.EnsureInstalled()`
  - `SceneFlowDevInstaller.EnsureInstalled()`
  - `LevelFlowDevInstaller.EnsureInstalled()`
  - `IntroStageRuntimeDebugGui.EnsureInstalled()` (`UNITY_EDITOR || DEVELOPMENT_BUILD`)

## D) Canonical Runtime Rail
- Nao e trilho de producao. Rail can�nico de DevQA e exclusivamente habilitacao condicional por compile flags no bootstrap de composicao.

## E) LEGACY/Compat
- Ferramentas dev antigas coexistem com novas, inclusive em diferentes flags (`NEWSCRIPTS_DEV`, `NEWSCRIPTS_QA`, `UNITY_EDITOR`, `DEVELOPMENT_BUILD`).

## F) Redundancy Candidates
- `Modules/SceneFlow/Dev/SceneFlowDevInstaller.cs`, `Modules/LevelFlow/Dev/LevelFlowDevInstaller.cs`, `Modules/ContentSwap/Dev/Runtime/ContentSwapDevInstaller.cs`, `Modules/GameLoop/IntroStage/Dev/IntroStageDevInstaller.cs` repetem padrao de instalacao; risco baixo.
- Multiplicidade de context menus de QA cobrindo fluxos semelhantes de restart/transicao; risco baixo/medio.
- Drivers dev de WorldLifecycle e Gameplay podem sobrepor evidencias quando habilitados simultaneamente; risco medio para auditoria.

## G) Deletion/Merge Plan (DOC-ONLY)
- Padronizar um contrato unico de `EnsureInstalled` para todos os installers dev.
- Consolidar flags de compilacao para reduzir combinatoria de modos QA.
- Agrupar comandos de QA por dominio com ownership unico.

| FilePath | Type (Runtime/Editor/Shared) | Public Entry Points | EventBus IN | EventBus OUT | DI Provides | Notes (Canon/Legacy/Dead) |
|---|---|---|---|---|---|---|
| Infrastructure/Composition/GlobalCompositionRoot.DevQA.cs | Runtime | `Register*QaInstaller` | N/A | N/A | aciona installers | Canon DevQA owner |
| Modules/GameLoop/IntroStage/Dev/IntroStageDevInstaller.cs | Runtime | `EnsureInstalled` | N/A | N/A | N/A | Dev/QA |
| Modules/ContentSwap/Dev/Runtime/ContentSwapDevInstaller.cs | Runtime | `EnsureInstalled` | N/A | N/A | N/A | Dev/QA |
| Modules/SceneFlow/Dev/SceneFlowDevInstaller.cs | Runtime | `EnsureInstalled` | N/A | N/A | N/A | Dev/QA |
| Modules/LevelFlow/Dev/LevelFlowDevInstaller.cs | Runtime | `EnsureInstalled` | N/A | N/A | N/A | Dev/QA |
| Modules/WorldLifecycle/Dev/WorldResetRequestHotkeyDevBootstrap.cs | Runtime | bootstrap dev | N/A | comandos QA | N/A | Dev/QA |
| Modules/Gameplay/Editor/RunRearm/RunRearmRequestDevDriver.cs | Editor | editor/dev driver | N/A | comandos QA | N/A | Dev/QA |