# Pause Cleanup Audit v1 (PA-1.1)

Data: 2026-03-07

Escopo: `Modules/GameLoop/Pause/**` + checagem de composi��o em `Infrastructure/Composition/**`.

Fonte da verdade: workspace local.

## Behavior-preserving statement

- N�o houve altera��o de contratos p�blicos, assinaturas p�blicas, payloads/eventos ou pipeline/callsites.
- N�o houve mudan�a de ordem/timing do fluxo runtime de pause/resume.
- N�o houve move do arquivo runtime principal (`Bindings/PauseOverlayController.cs`) para preservar GUID/meta/refer�ncias.
- Mudan�a aplicada: isolamento estrutural de DevQA para parcial dedicado sob guard.

## Invent�rio A/B/C

| Component | FilePath | Role | Guards | HasRuntimeCallsite | Recommendation |
|---|---|---|---|---|---|
| PauseOverlayController (runtime) | `Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs` | Overlay runtime + eventos pause/resume + input mode | None | Sim | A) KEEP |
| PauseOverlayController DevQA parcial | `Modules/GameLoop/Pause/Dev/PauseOverlayController.DevQA.cs` | ContextMenu QA (Pause/Resume) | `UNITY_EDITOR || DEVELOPMENT_BUILD` (+ `UnityEditor` sob `UNITY_EDITOR`) | N�o (Dev-only) | B) MOVE to Dev (aplicado) |
| Qualquer depend�ncia de composi��o para `Modules.GameLoop.Pause.Dev` | `Infrastructure/Composition/**` | N�o aplic�vel | N/A | N�o encontrada | C) N/A (sem risco detectado) |

## Evid�ncias rg obrigat�rias

### Invent�rio
Comando:
`rg -n "PauseOverlayController|state\.pause|PauseOverlay|GamePause|GameResume|ContextMenu|MenuItem|UnityEditor" Modules -g "*.cs"`

Trechos relevantes:
- `Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs:38` (`PauseOverlayController`)
- `Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs:159` (`GamePauseCommandEvent` publish)
- `Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs:180` (`GameResumeRequestedEvent` publish)
- `Modules/Gates/SimulationGateTokens.cs:16` (`state.pause`)
- `Modules/Gates/Interop/GamePauseGateBridge.cs:49-50` (pause/resume bridge)

### Guards
Comando:
`rg -n "#if\s+UNITY_EDITOR|#if\s+DEVELOPMENT_BUILD|UNITY_EDITOR\s*\|\|\s*DEVELOPMENT_BUILD|MenuItem|ContextMenu|UnityEditor|AssetDatabase|FindAssets" Modules/GameLoop/Pause -g "*.cs"`

Trechos relevantes (p�s-change):
- `Modules/GameLoop/Pause/Dev/PauseOverlayController.DevQA.cs:1` (`#if UNITY_EDITOR || DEVELOPMENT_BUILD`)
- `Modules/GameLoop/Pause/Dev/PauseOverlayController.DevQA.cs:5` (`using UnityEditor;` sob `#if UNITY_EDITOR`)
- `Modules/GameLoop/Pause/Dev/PauseOverlayController.DevQA.cs:14` e `:23` (`[ContextMenu(...)]`)

### Composi��o / callsites
Comando:
`rg -n "PauseOverlayController|InstallGameLoopServices\(|InstallDevQaServices\(|Register.*Pause" Infrastructure/Composition -g "*.cs"`

Trechos relevantes:
- `Infrastructure/Composition/GlobalCompositionRoot.PauseReadiness.cs:14` (`RegisterPauseBridge`)
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs:98` (`InstallGameLoopServices`)
- `Infrastructure/Composition/GlobalCompositionRoot.Pipeline.cs:116` (`InstallDevQaServices`)

### P�s-check de vazamento no runtime
Comando:
`rg -n "UnityEditor|AssetDatabase|FindAssets|MenuItem|ContextMenu" Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs`

Resultado:
- sem matches (exit code 1).

## Mudan�as realizadas

- Modificado: `Modules/GameLoop/Pause/Bindings/PauseOverlayController.cs`
  - `class` convertida para `partial`
  - bloco DevQA removido do runtime
- Adicionado: `Modules/GameLoop/Pause/Dev/PauseOverlayController.DevQA.cs`
  - DevQA/context menu isolado sob guard de build
- Nenhum arquivo movido.
- Nenhum arquivo removido.
