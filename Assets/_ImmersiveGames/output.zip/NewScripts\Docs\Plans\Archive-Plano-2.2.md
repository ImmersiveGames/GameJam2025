# Archive — Plano 2.2 (histórico / placeholder)

Este arquivo existe para **evitar links quebrados** e manter rastreabilidade.

O “Plano 2.2” original foi referenciado como movido no `Docs/CHANGELOG.md`, mas o conteúdo não está mais presente neste snapshot.

## Fonte de verdade (para o estado atual)

- **Fechamento do Baseline 2.0:** `Docs/ADRs/ADR-0015-Baseline-2.0-Fechamento.md`
- **Evidência vigente:** `Docs/Reports/Evidence/LATEST.md`
- **Snapshots Baseline 2.2 (histórico):**
  - `Docs/Reports/Evidence/2026-01-29/Baseline-2.2-Evidence-2026-01-29.md`
  - `Docs/Reports/Evidence/2026-01-31/Baseline-2.2-Evidence-2026-01-31.md`
  - `Docs/Reports/Evidence/2026-02-03/Baseline-2.2-Evidence-2026-02-03.md`

## Se você precisar do conteúdo original

Recupere pelo histórico do repositório (git) usando o caminho citado no changelog:

- `Archive/Plans/Plano-2.2.md`
