using System;
using System.Threading.Tasks;
using _ImmersiveGames.NewScripts.Core.Composition;
using _ImmersiveGames.NewScripts.Core.Events;
using _ImmersiveGames.NewScripts.Core.Logging;
using _ImmersiveGames.NewScripts.Modules.SceneFlow.Fade.Runtime;
using _ImmersiveGames.NewScripts.Modules.SceneFlow.Transition;
using _ImmersiveGames.NewScripts.Modules.SceneFlow.Transition.Runtime;
using _ImmersiveGames.NewScripts.Modules.WorldLifecycle.Runtime;
using UnityEngine;
namespace _ImmersiveGames.NewScripts.Modules.GameLoop.Runtime.Bridges
{
    public sealed partial class GameLoopSceneFlowCoordinator : IDisposable
    {
        private readonly ISceneTransitionService _sceneFlow;
        private readonly SceneTransitionRequest _startPlan;

        private bool _startInProgress;
        private bool _transitionCompleted;
        private bool _worldResetCompleted;
        private bool _syncIssued;

        private string _expectedContextSignature;

        private readonly EventBinding<GameStartRequestedEvent> _startRequestedBinding;
        private readonly EventBinding<SceneTransitionStartedEvent> _transitionStartedBinding;
        private readonly EventBinding<SceneTransitionCompletedEvent> _transitionCompletedBinding;
        private readonly EventBinding<WorldLifecycleResetCompletedEvent> _worldResetCompletedBinding;

        private bool _disposed;

        public GameLoopSceneFlowCoordinator(ISceneTransitionService sceneFlow, SceneTransitionRequest startPlan)
        {
            _sceneFlow = sceneFlow ?? throw new ArgumentNullException(nameof(sceneFlow));
            _startPlan = startPlan;

            _startRequestedBinding = new EventBinding<GameStartRequestedEvent>(_ => OnStartRequestedCommon());
            _transitionStartedBinding = new EventBinding<SceneTransitionStartedEvent>(OnTransitionStarted);
            _transitionCompletedBinding = new EventBinding<SceneTransitionCompletedEvent>(OnTransitionCompleted);
            _worldResetCompletedBinding = new EventBinding<WorldLifecycleResetCompletedEvent>(OnWorldResetCompleted);

            EventBus<GameStartRequestedEvent>.Register(_startRequestedBinding);
            EventBus<SceneTransitionStartedEvent>.Register(_transitionStartedBinding);
            EventBus<SceneTransitionCompletedEvent>.Register(_transitionCompletedBinding);
            EventBus<WorldLifecycleResetCompletedEvent>.Register(_worldResetCompletedBinding);

            if (_startPlan == null)
            {
                DebugUtility.LogWarning(typeof(GameLoopSceneFlowCoordinator),
                    "[GameLoopSceneFlow] Coordinator registrado com startPlan NULL. Start sera ignorado ate corrigir o GlobalCompositionRoot.");
                return;
            }

            DebugUtility.Log(typeof(GameLoopSceneFlowCoordinator),
                $"[GameLoopSceneFlow] Coordinator registrado. StartPlan: Load=[{string.Join(", ", _startPlan.ScenesToLoad)}], Unload=[{string.Join(", ", _startPlan.ScenesToUnload)}], Active='{_startPlan.TargetActiveScene}', UseFade={_startPlan.UseFade}, Style='{_startPlan.StyleLabel}'.");
        }

        public void Dispose()
        {
            if (_disposed)
            {
                return;
            }

            _disposed = true;
            EventBus<GameStartRequestedEvent>.Unregister(_startRequestedBinding);
            EventBus<SceneTransitionStartedEvent>.Unregister(_transitionStartedBinding);
            EventBus<SceneTransitionCompletedEvent>.Unregister(_transitionCompletedBinding);
            EventBus<WorldLifecycleResetCompletedEvent>.Unregister(_worldResetCompletedBinding);
        }

        private void OnStartRequestedCommon()
        {
            if (_startPlan == null)
            {
                DebugUtility.LogError(typeof(GameLoopSceneFlowCoordinator),
                    "[GameLoopSceneFlow] Start REQUEST recebido, mas startPlan e NULL. Abortando.");
                return;
            }

            if (_startInProgress)
            {
                DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                    "[GameLoopSceneFlow] Start REQUEST ignorado (ja em progresso).",
                    DebugUtility.Colors.Info);
                return;
            }

            _startInProgress = true;
            ResetStartState();

            DebugUtility.Log(typeof(GameLoopSceneFlowCoordinator),
                "[GameLoopSceneFlow] Start REQUEST recebido. Disparando transicao de cenas...");

            _ = StartTransitionAsync();
        }

        private async Task StartTransitionAsync()
        {
            try
            {
                if (_startPlan.UseFade)
                {
                    await EnsureFadeReadyForStartTransitionAsync();
                }

                await _sceneFlow.TransitionAsync(_startPlan);
            }
            catch (Exception ex)
            {
                DebugUtility.LogError(typeof(GameLoopSceneFlowCoordinator),
                    $"[GameLoopSceneFlow] Falha ao executar TransitionAsync(startPlan). ex={ex}");

                _startInProgress = false;
            }
        }

        private static async Task EnsureFadeReadyForStartTransitionAsync()
        {
            if (!DependencyManager.Provider.TryGetGlobal<IFadeService>(out var fadeService) || fadeService == null)
            {
                HandleFadeStartFailure("IFadeService is not available in global DI before start transition.");
                return;
            }

            try
            {
                await fadeService.EnsureReadyAsync();
            }
            catch (Exception ex)
            {
                HandleFadeStartFailure($"EnsureReadyAsync failed before start transition. ex='{ex.GetType().Name}: {ex.Message}'");
            }
        }

        private static void HandleFadeStartFailure(string detail)
        {
            if (ShouldDegradeFadeInRuntime())
            {
                DebugUtility.LogError(typeof(GameLoopSceneFlowCoordinator),
                    $"[DEGRADED][Fade] {detail} Continuing without fade.");
                return;
            }

            string message = $"[FATAL][Fade] {detail}";
            DebugUtility.LogError(typeof(GameLoopSceneFlowCoordinator), message);

            DevStopPlayModeInEditor();
            if (!Application.isEditor)
            {
                Application.Quit();
            }

            throw new InvalidOperationException(message);
        }

        static partial void DevStopPlayModeInEditor();

        private static bool ShouldDegradeFadeInRuntime()
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            return true;
#else
            return false;
#endif
        }

        private void OnTransitionStarted(SceneTransitionStartedEvent evt)
        {
            if (!ShouldHandleTransition(evt.context))
            {
                return;
            }

            DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                $"[GameLoopSceneFlow] TransitionStarted recebido. expectedSignature='{_expectedContextSignature ?? "<null>"}'.",
                DebugUtility.Colors.Info);
        }

        private void OnTransitionCompleted(SceneTransitionCompletedEvent evt)
        {
            if (!ShouldHandleTransition(evt.context))
            {
                return;
            }

            string ctxSig = SceneTransitionSignature.Compute(evt.context);
            if (!string.IsNullOrEmpty(_expectedContextSignature) &&
                !string.Equals(ctxSig, _expectedContextSignature, StringComparison.Ordinal))
            {
                DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                    $"[GameLoopSceneFlow] TransitionCompleted ignorado (signature mismatch). expected='{_expectedContextSignature}', got='{ctxSig}'.",
                    DebugUtility.Colors.Info);
                return;
            }

            _transitionCompleted = true;

            DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                $"[GameLoopSceneFlow] TransitionCompleted recebido. expectedSignature='{_expectedContextSignature ?? "<null>"}'.",
                DebugUtility.Colors.Info);

            TryIssueGameLoopSync();
        }

        private void OnWorldResetCompleted(WorldLifecycleResetCompletedEvent evt)
        {
            if (!_startInProgress)
            {
                return;
            }

            if (!string.IsNullOrEmpty(evt.ContextSignature))
            {
                if (string.IsNullOrEmpty(_expectedContextSignature))
                {
                    _expectedContextSignature = evt.ContextSignature;
                }
                else if (!string.Equals(evt.ContextSignature, _expectedContextSignature, StringComparison.Ordinal))
                {
                    DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                        $"[GameLoopSceneFlow] WorldLifecycleResetCompleted ignorado (signature mismatch). expected='{_expectedContextSignature}', got='{evt.ContextSignature}', reason='{evt.Reason ?? "<null>"}'.",
                        DebugUtility.Colors.Info);
                    return;
                }
            }
            else if (!string.IsNullOrEmpty(_expectedContextSignature))
            {
                DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                    $"[GameLoopSceneFlow] WorldLifecycleResetCompleted ignorado (sem assinatura, mas expectedSignature='{_expectedContextSignature}'). reason='{evt.Reason ?? "<null>"}'.",
                    DebugUtility.Colors.Info);
                return;
            }

            _worldResetCompleted = true;

            DebugUtility.LogVerbose(typeof(GameLoopSceneFlowCoordinator),
                $"[GameLoopSceneFlow] WorldLifecycle reset concluido (ou skip). reason='{evt.Reason ?? "<null>"}'.",
                DebugUtility.Colors.Info);

            TryIssueGameLoopSync();
        }

        private bool IsMatchingStartPlan(SceneTransitionContext context)
        {
            if (_startPlan == null)
            {
                return false;
            }

            if (_startPlan.RouteId.IsValid && context.RouteId.IsValid && context.RouteId != _startPlan.RouteId)
            {
                return false;
            }

            if (!string.IsNullOrWhiteSpace(_startPlan.TargetActiveScene) &&
                !string.IsNullOrWhiteSpace(context.TargetActiveScene) &&
                !string.Equals(context.TargetActiveScene, _startPlan.TargetActiveScene, StringComparison.Ordinal))
            {
                return false;
            }

            return true;
        }

        private void EnsureExpectedSignatureFromContext(SceneTransitionContext context)
        {
            if (!string.IsNullOrEmpty(_expectedContextSignature))
            {
                return;
            }

            _expectedContextSignature = SceneTransitionSignature.Compute(context);
        }

        private void ResetStartState()
        {
            _transitionCompleted = false;
            _worldResetCompleted = false;
            _syncIssued = false;
            _expectedContextSignature = null;
        }

        private bool ShouldHandleTransition(SceneTransitionContext context)
        {
            if (!_startInProgress)
            {
                return false;
            }

            if (!IsMatchingStartPlan(context))
            {
                return false;
            }

            EnsureExpectedSignatureFromContext(context);
            return true;
        }

        private void TryIssueGameLoopSync()
        {
            if (_syncIssued)
            {
                return;
            }

            if (!_startInProgress || !_transitionCompleted || !_worldResetCompleted)
            {
                return;
            }

            if (!DependencyManager.Provider.TryGetGlobal<IGameLoopService>(out var gameLoop) || gameLoop == null)
            {
                DebugUtility.LogError(typeof(GameLoopSceneFlowCoordinator),
                    "[GameLoopSceneFlow] IGameLoopService indisponivel no DI global; nao foi possivel sincronizar GameLoop.");

                _startInProgress = false;
                return;
            }

            _syncIssued = true;
            gameLoop.Initialize();

            DebugUtility.LogVerbose<GameLoopSceneFlowCoordinator>(
                $"[GameLoopSceneFlow] Sync concluido. routeId='{_startPlan.RouteId}' activeScene='{_startPlan.TargetActiveScene}'. Chamando RequestReady() no GameLoop (start via pipeline/IntroStageController).",
                DebugUtility.Colors.Info);

            gameLoop.RequestReady();
            _startInProgress = false;
        }
    }
}

