# ADR-0055 - Seam de Integracao Semantica de Sessao como area propria da arquitetura

## Status
- Estado: Aceito
- Data: 2026-04-18
- Tipo: Direction / Canonical architecture
- Fonte de verdade canonica deste contrato: este ADR.
- Nota de fechamento: implementacao principal concluida e validada por smoke/runtime no ciclo incremental F1-F7, com fechamento final de pureza do seam e restauracao do rail canonicamente correto de IntroStage.

## 1. Contexto

O sistema atual nao esta conceitualmente quebrado. Ele esta em transicao com cheiros.

Ja existem owners semanticos e operacionais relativamente saudaveis:

- `GameplaySessionFlow` como owner semantico da sessao
- `GameplayParticipationFlowService` como owner semantico da participacao
- `InputModes` como rail operacional de request e aplicacao
- `IntroStage` como stage local de entrada
- `PostRun` como rail explicita de resultado e decisao

O problema real nao esta em um bloco isolado como participacao, nem em uma fase especifica.
O problema e estrutural: falta um seam canonicamente explicito para integrar dominio semantico de sessao com dominios operacionais adjacentes.

Sem esse seam, a costura fica difusa e tende a migrar por oportunidade para:

- `SceneFlowBootstrap`
- installers de composicao
- bridges transitorias
- coordinators de sincronizacao
- snapshots espalhados sem owner de integracao claro

## 2. Problema estrutural real

Quando a integracao entre semantica e operacao nao tem um lugar proprio, o sistema passa a produzir solucoes de conveniencia:

- bridges oportunistas aparecem para fechar o que nao tem seam central
- bootstraps absorvem integracao alem do ideal
- `InputModes` deduplica emissao util, mas pode mascarar ambiguidade de ownership
- contratos, owners, adapters e bridges acabam misturados no mesmo artefato
- snapshots deixam de ser apenas leitura canonica e passam a carregar costura de integracao

Tratar isso como "problema da fase", "problema da participacao" ou "problema do bootstrap" e insuficiente.
Esses blocos sao apenas sintomas do vazio arquitetural entre:

- ownership semantico
- traducao de intencao
- execucao operacional

## 3. Decisao

Adota-se uma area propria chamada **Session Integration** para ser o seam canonico de integracao semantica de sessao, no arquétipo de **seam explicito puro**.

Nome recomendado em codigo:

- `GameplaySessionIntegration`

Nome recomendado de pasta/namespace:

- `Orchestration/GameplaySession/Integration`

Esta area nao e um novo centro semantico.
Ela nao substitui `GameplaySessionFlow`.
Ela tambem nao substitui `Session Transition` como camada acima do baseline.

O papel desta area e ser a fronteira explicita que traduz estado semantico canonico de sessao em intencao operacional canonica para dominios adjacentes.
O seam encerra no handoff operacional canonicamente definido.

Em termos arquiteturais:

- `GameplaySessionFlow` produz a verdade semantica da sessao
- `Session Integration` consome essa verdade e emite intencoes operacionais canonicas
- os dominios operacionais executam essas intencoes
- `Session Integration` nao executa efeito final concreto nem absorve ownership semantico/macro de outro eixo

O seam deve ser uma area modular propria, nao um bootstrap, nao um workaround e nao uma classe unica que acumula tudo.

## 4. O que entra no seam

Entra no seam tudo o que faz a traducao/correlacao entre semantica de sessao e operacao adjacente:

- bridges semanticas de sessao
- traducao de snapshots canonicos em intencao operacional
- dispatch/handoff canonico para continuidade, run-reset, phase-reset e continuidade pos-run
- request canonico para `InputModes`
- coordenacao de sinais correlatos da sessao
- adaptacao para futuros blocos semanticos que precisem conversar com dominios operacionais, sem executar efeitos finais

O seam pode conter bridges, pequenos translators, request publishers e coordinators finos.
O que nao pode e perder a fronteira de ownership.

## 5. O que fica fora

Fica fora do seam:

- ownership do dominio semantico da sessao
- ownership da participacao em si
- `SceneTransitionService`
- execucao concreta de spawn
- execucao concreta de reset
- execucao concreta de navegacao
- execucao concreta de phase prepare/composition
- `ActorRegistry` como source of truth operacional de participacao
- presenter local de `IntroStage`
- `InputModes` como aplicador efetivo de map
- bootstraps macro usados por conveniencia historica
- gameplay interaction / binders concretos quando forem apenas operacao de conexao, e nao o proprio seam

O seam pode conversar com esses dominios, mas nao deve absorve-los.

## 6. Relacao com as demais camadas

### `GameplaySessionFlow`

`GameplaySessionFlow` continua sendo o owner semantico da sessao.
Ele deriva e publica o estado canonico da sessao, incluindo phase, participation e sinais correlatos.
O seam apenas consome esse material semantico.

### `SceneFlow`

`SceneFlow` continua sendo o rail macro de transicao.
O seam nao altera ownership de transicao, nao decide readiness de scene e nao substitui `SceneTransitionService`.
Ele reage ao momento canonico em que a transicao ja foi resolvida.

### `InputModes`

`InputModes` continua operacional.
`InputModeCoordinator` continua sendo o writer canonico de requests.
`InputModeService` continua sendo o aplicador canonico do estado efetivo.

O seam e o emissor canonico de intencao adjacente para session-side concerns.
`InputModes` aplica a request; nao resolve ownership semantico.

### spawn / reset

Spawn e reset continuam sendo operacao.
O seam pode emitir requests, planos ou pistas de integracao, mas nao executa spawn nem reset.

Navegacao concreta permanece no owner de `Navigation/SceneFlow`.
Reset concreto permanece no owner de `ResetFlow`.
Contrato de handoff de reset pertence ao owner `ResetFlow` (nao ao `Session Integration`).

### `ActorRegistry`

`ActorRegistry` continua sendo registry operacional de atores vivos.
Ele nao deve virar source of truth semantico de participacao.
O seam pode correlacionar, observar ou compor sinais com ele, mas nao delega para ele o ownership da intencao.

### phase composition

O seam consome a phase ja resolvida.
Ele nao seleciona phase, nao autoriza autoria da phase e nao substitui `PhaseDefinition`.
No caso de prepare de phase, o seam despacha handoff; a materializacao operacional ocorre fora do seam.

### baseline / layer acima do baseline

O baseline continua responsavel por macro rails, boot e execucao tecnica.
Esta area vive acima do baseline, no espaco em que a sessao semantica precisa conversar com dominios operacionais sem vazar para o bootstrap.

### futuros blocos semanticos

O seam deve servir tambem para futuros blocos semanticos, inclusive os que ainda nao existem, desde que o papel deles seja traduzir semantica de sessao em intencao operacional.

## 7. Como este seam evita os cheiros atuais

Este ADR existe para evitar a consolidacao dos seguintes cheiros:

- bootstrap bloat
- bridges oportunistas
- multiplas fontes de intencao
- mistura entre contracts, owners e adapters
- snapshots distribuidos sem owner de integracao claro
- dedupe operacional mascarando ambiguidade de ownership

Em particular:

- `SceneFlowBootstrap` deve voltar a ser composition root fino
- bridges atuais devem ser relocados para a area propria de integracao
- cada intencao downstream deve ter um emissor canonico claro
- `ParticipationReadinessState.NotReady` continua pedindo politica operacional explicita, sem fallback silencioso e sem ser absorvido por dedupe local

## 8. Trincheiras canonicas de saida do seam

As saidas oficiais do `Session Integration` sao:

- continuidade (`IGameplaySessionFlowContinuityService`)
- run-reset (`IGameplaySessionRunResetService`)
- phase-reset (consumindo contrato de handoff do owner `ResetFlow`)
- sceneflow prepare handoff (prepare operacional fora do seam)
- run continuation handoff (dispatch para trilho operacional de continuacao)
- input mode request (request canonico para rail de `InputModes`)

Regra normativa:
- o seam publica/despacha
- consumidores operacionais executam
- o seam nao executa efeito final concreto

## 9. Regra canonica da ligacao com IntroStage

O prepare operacional pode materializar phase/conteudo.
Ele nao pode substituir o rail da `IntroStage`.

A entrada da `IntroStage` deve retornar ao ponto canonico consumido pelo owner do rail:

- `GameplayPhaseFlowService` como owner de queue/ready (`PhaseIntroStageQueued`, `PhaseIntroStageReady`)
- `IntroStageLifecycleOrchestrator` como owner de defer/release/start request (`IntroStageDeferred`, `IntroStageReleasedOnSceneTransitionCompleted`, `IntroStageStartRequested`)
- `IntroStageCoordinator` como owner de started/completed/gameplay unblock (`IntroStageStarted` e desbloqueio para gameplay)

Quando `PhaseContentApplied` for parte do contrato que arma o rail, o metadado/contract `source` canonico exigido pelo owner downstream deve ser preservado.
Alterar esse metadado sem contrato explicito/documentado e desvio arquitetural.

## 10. Anti-padroes explicitos

Sao anti-padroes neste eixo:

- seam executando navegacao concreta
- seam executando reset concreto
- seam coordenando macro owner de outro eixo por conveniencia
- owner operacional dependendo de contratos definidos dentro do seam
- prepare operacional absorvendo o rail da `IntroStage`
- mudanca de metadado/contract `source` quebrando owner downstream sem documentacao

## 11. Ordem de migracao e implicacoes

A adocao deste seam deve preceder ou reorganizar os proximos passos do plano de participacao.

Sequencia recomendada:

1. criar a area propria de `Session Integration`
2. mover para ela as bridges e translators hoje espalhados
3. reduzir `SceneFlowBootstrap` ao papel de wiring macro
4. separar contracts, owners e adapters que hoje estao misturados
5. clarificar emissor canonico de intencao para `InputModes`, spawn e reset
6. depois disso, continuar a evolucao de participacao, actors e binders

O mesmo seam vira base para analises e refatoracoes futuras em:

- `Players` / `Actors`
- reset
- spawn
- `InputModes`
- gameplay interaction / binders

Este ADR tambem habilita uma leitura futura mais limpa do baseline, inclusive comparando estado atual versus shape ideal sem confundir integracao com ownership semantico.

## 12. Relacao com ADRs anteriores

Este ADR nao substitui os seguintes contratos; ele os organiza na fronteira correta:

- `ADR-0044`: continua sendo o canon guarda-chuva da arquitetura ideal do baseline
- `ADR-0045`: continua posicionando `Gameplay Runtime Composition` como centro semantico do gameplay
- `ADR-0046`: continua fixando `GameplaySessionFlow` como primeiro bloco interno desse centro
- `ADR-0052`: continua definindo `Session Transition` como camada acima do baseline para transformacao composta da sessao/runtime
- `ADR-0054`: continua fixando participacao semantica como bloco dentro ou ao lado de `GameplaySessionFlow`
- `ADR-0040`: continua definindo `InputModes` como rail canonico de request e aplicacao

O que este ADR adiciona e a fronteira explicita que faltava entre esses owners e os dominios operacionais.

## 13. Estado atual validado

Smoke recente validou:

- handoff puro no `Session Integration` (sem execucao final concreta)
- navegacao concreta no owner de navegacao
- reset concreto no owner de reset, com contrato de handoff pertencendo a `ResetFlow`
- `Integration/SceneFlow` e `GameRunEndedEventBridge` encerrando em handoff operacional canonicamente definido
- prepare operacional fora do seam, com retorno ao owner canonico do rail de `IntroStage`
- trilho completo da `IntroStage` restaurado (queue -> ready -> deferred -> release -> start request -> started)
- `GameLoop` chegando em `Playing` pelo trilho correto apos confirmacao da intro

## 14. Fechamento

`Session Integration` passa a ser a area propria da arquitetura responsavel por fazer a costura canonica entre semantica de sessao e operacao adjacente.

Isso nao e um workaround transitivo.
E a fronteira que permite que `GameplaySessionFlow`, `SceneFlow`, `InputModes`, spawn, reset e `ActorRegistry` evoluam sem concentrar a costura em bootstraps oportunistas.

Validacao registrada: a area foi materializada como seam real e entrou em uso operacional no fluxo estabilizado da `Base 1.0`.

## 15. Hardening incremental consolidado (2026-04-22)

Sem reabrir o contrato deste ADR, ficam congelados os seguintes pontos de hardening no seam:

- gate de prepare (`GameplaySessionFlowPrepareCompletionGate`) com dependencia explicita de handoff operacional, removendo service locator do caminho quente.
- composicao do run-end bridge exigindo `RunEndBridgeRuntimeComposer.ComposeOrFail()` antes de instanciar `GameRunEndedEventBridge`.
- contratos menores de integracao de sessao estabilizados como superficie do seam, sem mover ownership para bootstrap.
- read-port minimo (`ISpawnResetParticipationReadPort`) mantido como contrato oficial de leitura para spawn/reset.

Esses ajustes sao refinamento mecanico de wiring/contrato, sem mudanca de ownership semantico.

## 16. Congelamento do handoff do eixo Actors (2026-04-23)

Sem alterar o papel do seam, fica congelado:

- route/macro, phase e runtime dinamico entregam contexto e referencia (`actorSpecId`/`ActorSetRef`), nao prefab direto.
- a execucao operacional de actors consome `ActorSpec`/`ActorSetRef` como entrada canonica.
- `WorldDefinition` nao e fonte normativa de prefab/body no shape final.

Regra de boundary:

- `Session Integration` traduz e despacha;
- executores operacionais realizam (`Spawn`, `RegisterExisting`, `Preserve`, `Rematerialize`);
- legitimidade e definicao de actor permanecem no `ActorsSystem`.
