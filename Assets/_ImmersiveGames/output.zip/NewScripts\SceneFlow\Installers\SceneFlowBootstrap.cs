using System;
using _ImmersiveGames.NewScripts.Foundation.Core.Logging;
using _ImmersiveGames.NewScripts.Foundation.Platform.Composition;
using _ImmersiveGames.NewScripts.Foundation.Platform.Config;
using _ImmersiveGames.NewScripts.ResetFlow.WorldReset.Policies;
using _ImmersiveGames.NewScripts.SceneFlow.Contracts.RuntimeCore;
using _ImmersiveGames.NewScripts.SceneFlow.LoadingFade.Fade.Runtime;
using _ImmersiveGames.NewScripts.SceneFlow.LoadingFade.Loading.Runtime;
using _ImmersiveGames.NewScripts.SceneFlow.Transition;
using _ImmersiveGames.NewScripts.SceneFlow.Transition.Interop;
using _ImmersiveGames.NewScripts.SceneFlow.Transition.Runtime;
namespace _ImmersiveGames.NewScripts.SceneFlow.Installers
{
    /// <summary>
    /// Runtime composer do SceneFlow.
    ///
    /// Responsabilidade:
    /// - compor e ativar o runtime do SceneFlow depois que os installers relevantes concluíram;
    /// - nao registrar contratos de boot.
    /// </summary>
    public static class SceneFlowBootstrap
    {
        private static bool _runtimeComposed;
        private static SceneFlowInputModeBridge _inputModeBridge;
        private static LoadingHudOrchestrator _loadingHudOrchestrator;
        private static LoadingProgressOrchestrator _loadingProgressOrchestrator;

        public static void ComposeRuntime(BootstrapConfigAsset bootstrapConfig)
        {
            CompositionPipelineExecutor.RequireBootstrapPhaseOpen(nameof(SceneFlowBootstrap));

            if (_runtimeComposed)
            {
                return;
            }

            if (bootstrapConfig == null)
            {
                throw new InvalidOperationException("[FATAL][Config][SceneFlow] BootstrapConfigAsset obrigatorio ausente para compor o runtime.");
            }

            EnsureSceneTransitionService();
            EnsureRouteActorSetRefContext();
            EnsureInputModeBridge();
            EnsureLoadingOrchestrators();
            EnsureFadeReadyAsync();
            EnsureSceneFlowModuleComposition();

            _runtimeComposed = true;

            DebugUtility.Log(typeof(SceneFlowBootstrap),
                "[SceneFlow] Runtime composition concluida.",
                DebugUtility.Colors.Info);
        }

        private static void EnsureSceneTransitionService()
        {
            if (DependencyManager.Provider.TryGetGlobal<ISceneTransitionService>(out var existing) && existing != null)
            {
                return;
            }

            var loaderAdapter = SceneFlowAdapterFactory.CreateLoaderAdapter();
            var fadeAdapter = SceneFlowAdapterFactory.CreateFadeAdapter(DependencyManager.Provider);
            var completionGate = ResolveRequired<ISceneTransitionCompletionGate>();
            var navigationPolicy = ResolveRequired<INavigationPolicy>();
            var routeGuard = ResolveRequired<IRouteGuard>();
            var routeResetPolicy = ResolveRequired<IRouteResetPolicy>();

            var service = new SceneTransitionService(
                loaderAdapter,
                fadeAdapter,
                completionGate,
                navigationPolicy,
                routeGuard,
                routeResetPolicy);

            DependencyManager.Provider.RegisterGlobal<ISceneTransitionService>(service);

            DebugUtility.LogVerbose(typeof(SceneFlowBootstrap),
                $"[SceneFlow] SceneTransitionService composto no runtime (Loader={loaderAdapter.GetType().Name}, FadeAdapter={fadeAdapter.GetType().Name}, Gate={completionGate.GetType().Name}, Policy={navigationPolicy.GetType().Name}, RouteGuard={routeGuard.GetType().Name}, RouteResetPolicy={routeResetPolicy.GetType().Name}).",
                DebugUtility.Colors.Info);
        }

        private static void EnsureInputModeBridge()
        {
            if (_inputModeBridge != null)
            {
                return;
            }

            if (DependencyManager.Provider.TryGetGlobal<SceneFlowInputModeBridge>(out var existing) && existing != null)
            {
                _inputModeBridge = existing;
                return;
            }

            _inputModeBridge = new SceneFlowInputModeBridge();
            DependencyManager.Provider.RegisterGlobal(_inputModeBridge);
        }

        private static void EnsureRouteActorSetRefContext()
        {
            if (DependencyManager.Provider.TryGetGlobal<ISceneFlowRouteActorSetRefContext>(out var existingContext) && existingContext != null)
            {
                return;
            }

            var service = new SceneFlowRouteActorSetRefService();
            DependencyManager.Provider.RegisterGlobal<ISceneFlowRouteActorSetRefContext>(service);
            DependencyManager.Provider.RegisterGlobal(service);

            DebugUtility.Log(typeof(SceneFlowBootstrap),
                "[OBS][ActorsExecution] Route actor-set context composed (SceneFlow owner).",
                DebugUtility.Colors.Info);
        }

        private static void EnsureLoadingOrchestrators()
        {
            ResolveRequired<ILoadingPresentationService>();
            ResolveRequired<ILoadingHudService>();

            if (_loadingHudOrchestrator == null)
            {
                if (DependencyManager.Provider.TryGetGlobal<LoadingHudOrchestrator>(out var existingHud) && existingHud != null)
                {
                    _loadingHudOrchestrator = existingHud;
                }
                else
                {
                    _loadingHudOrchestrator = new LoadingHudOrchestrator();
                    DependencyManager.Provider.RegisterGlobal(_loadingHudOrchestrator);
                }
            }

            if (_loadingProgressOrchestrator == null)
            {
                if (DependencyManager.Provider.TryGetGlobal<LoadingProgressOrchestrator>(out var existingProgress) && existingProgress != null)
                {
                    _loadingProgressOrchestrator = existingProgress;
                }
                else
                {
                    _loadingProgressOrchestrator = new LoadingProgressOrchestrator();
                    DependencyManager.Provider.RegisterGlobal(_loadingProgressOrchestrator);
                }
            }
        }

        private static async void EnsureFadeReadyAsync()
        {
            if (!DependencyManager.Provider.TryGetGlobal<IFadeService>(out var fadeService) || fadeService == null)
            {
                return;
            }

            try
            {
                await fadeService.EnsureReadyAsync();
                DebugUtility.LogVerbose(typeof(SceneFlowBootstrap),
                    "[OBS][Fade] FadeScene ready (source=SceneFlowBootstrap/ComposeRuntime).",
                    DebugUtility.Colors.Info);
            }
            catch (Exception ex)
            {
                DebugUtility.LogError(typeof(SceneFlowBootstrap),
                    $"[ERROR][Fade] Failed to preload FadeScene during SceneFlow runtime bootstrap. ex='{ex.GetType().Name}: {ex.Message}'");
            }
        }

        private static void EnsureSceneFlowModuleComposition()
        {
            ResolveRequired<ISceneTransitionService>();
            ResolveRequired<INavigationPolicy>();
            ResolveRequired<IRouteGuard>();
            ResolveRequired<IRouteResetPolicy>();
            ResolveRequired<ISceneFlowRouteActorSetRefContext>();
            ResolveRequired<ILoadingPresentationService>();
            ResolveRequired<ILoadingHudService>();
            ResolveRequired<IFadeService>();
            ResolveRequired<SceneFlowInputModeBridge>();
            ResolveRequired<LoadingHudOrchestrator>();
            ResolveRequired<LoadingProgressOrchestrator>();

            DebugUtility.Log(typeof(SceneFlowBootstrap),
                "[OBS][SceneFlow] Runtime composition consolidada. scope='transition macro -> loading/fade -> navigation'.",
                DebugUtility.Colors.Info);
        }

        private static T ResolveRequired<T>() where T : class
        {
            if (DependencyManager.Provider.TryGetGlobal<T>(out var service) && service != null)
            {
                return service;
            }

            if (typeof(T) == typeof(ISceneTransitionCompletionGate))
            {
                throw new InvalidOperationException(
                    "[FATAL][Config][SceneFlow] ISceneTransitionCompletionGate obrigatorio ausente no DI global antes da composicao runtime. " +
                    "O gate canonico deve ser registrado por SessionFlow / GameplaySessionFlowCompletionGateComposer antes de SceneFlowBootstrap.");
            }

            throw new InvalidOperationException($"[FATAL][Config][SceneFlow] {typeof(T).Name} obrigatorio ausente no DI global antes da composicao runtime.");
        }
    }
}

