namespace _ImmersiveGames.NewScripts.Modules.Gameplay.Actions
{
    public enum GameplayAction
    {
        Spawn,
        Move,
        Shoot,
        Interact
    }
}

