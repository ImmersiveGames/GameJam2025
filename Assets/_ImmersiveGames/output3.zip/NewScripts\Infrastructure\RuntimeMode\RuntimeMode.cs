namespace _ImmersiveGames.NewScripts.Infrastructure.RuntimeMode
{
    public enum RuntimeMode
    {
        Strict = 0,
        Release = 1
    }
}
