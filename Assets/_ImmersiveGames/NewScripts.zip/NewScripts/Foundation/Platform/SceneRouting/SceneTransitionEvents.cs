using System;
using System.Collections.Generic;
using _ImmersiveGames.NewScripts.Foundation.Core.Events;
using _ImmersiveGames.NewScripts.Foundation.Platform.Transitions;
using _ImmersiveGames.NewScripts.UnityUtils;
namespace _ImmersiveGames.NewScripts.Foundation.Platform.SceneRouting
{
    public readonly struct SceneTransitionContext : IEquatable<SceneTransitionContext>
    {
        public IReadOnlyList<string> ScenesToLoad { get; }
        public IReadOnlyList<string> ScenesToUnload { get; }
        public string TargetActiveScene { get; }
        public bool UseFade { get; }
        public SceneRouteId RouteId { get; }
        public string RouteIdentity => RouteId.Value ?? string.Empty;
        public string Reason { get; }
        public SceneTransitionProfile TransitionProfile { get; }
        public string TransitionProfileName => TransitionProfile != null ? TransitionProfile.name.Trim() : string.Empty;
        public bool RequiresResetDelegation { get; }
        public string ResetDecisionSource { get; }
        public string ResetDecisionReason { get; }
        public SceneTransitionPayload Payload { get; }
        public SceneTransitionGameplayEntryKind GameplayEntryKind => Payload?.GameplayEntryKind ?? SceneTransitionGameplayEntryKind.None;
        public bool IsGameplayInitialEntry => Payload is { IsGameplayInitialEntry: true };
        public bool IsGameplayReentry => Payload is { IsGameplayReentry: true };
        public string ContextSignature { get; }

        public SceneTransitionContext(
            IReadOnlyList<string> scenesToLoad,
            IReadOnlyList<string> scenesToUnload,
            string targetActiveScene,
            bool useFade,
            SceneRouteId routeId,
            string reason,
            SceneTransitionProfile transitionProfile,
            bool requiresResetDelegation = false,
            string resetDecisionSource = null,
            string resetDecisionReason = null,
            string contextSignature = null,
            SceneTransitionPayload payload = null)
        {
            ScenesToLoad = scenesToLoad;
            ScenesToUnload = scenesToUnload;
            TargetActiveScene = targetActiveScene;
            UseFade = useFade;
            RouteId = routeId;
            Reason = reason.TrimToEmpty();
            TransitionProfile = transitionProfile;
            RequiresResetDelegation = requiresResetDelegation;
            ResetDecisionSource = resetDecisionSource.TrimToEmpty();
            ResetDecisionReason = resetDecisionReason.TrimToEmpty();
            Payload = payload ?? SceneTransitionPayload.Empty;

            ContextSignature = !string.IsNullOrWhiteSpace(contextSignature)
                ? contextSignature.Trim()
                : ComputeSignature(scenesToLoad, scenesToUnload, targetActiveScene, routeId, useFade, Payload.GameplayEntryKind);
        }

        public SceneTransitionContext WithRouteDelegationDecision(bool requiresResetDelegation, string decisionSource, string decisionReason)
        {
            return new SceneTransitionContext(
                ScenesToLoad,
                ScenesToUnload,
                TargetActiveScene,
                UseFade,
                RouteId,
                Reason,
                TransitionProfile,
                requiresResetDelegation,
                decisionSource,
                decisionReason,
                ContextSignature,
                Payload);
        }

        private static string ComputeSignature(
            IReadOnlyList<string> scenesToLoad,
            IReadOnlyList<string> scenesToUnload,
            string targetActiveScene,
            SceneRouteId routeId,
            bool useFade,
            SceneTransitionGameplayEntryKind gameplayEntryKind)
        {
            string load = JoinList(scenesToLoad);
            string unload = JoinList(scenesToUnload);
            string active = (targetActiveScene ?? string.Empty).Trim();
            string route = routeId.Value ?? string.Empty;
            string fade = useFade ? "1" : "0";
            return $"r:{route}|ge:{gameplayEntryKind}|a:{active}|f:{fade}|l:{load}|u:{unload}";
        }

        private static string JoinList(IReadOnlyList<string> list)
        {
            if (list == null || list.Count == 0)
            {
                return string.Empty;
            }

            string result = string.Empty;
            for (int i = 0; i < list.Count; i++)
            {
                string entry = (list[i] ?? string.Empty).Trim();
                if (entry.Length == 0)
                {
                    continue;
                }

                result = result.Length == 0 ? entry : result + "|" + entry;
            }

            return result;
        }

        public override string ToString()
        {
            return $"Route='{RouteId}', Reason='{Reason}', " +
                $"Load=[{string.Join(", ", ScenesToLoad)}], Unload=[{string.Join(", ", ScenesToUnload)}], " +
                $"Active='{TargetActiveScene}', UseFade={UseFade}, Profile='{TransitionProfileName}', " +
                $"RequiresResetDelegation={RequiresResetDelegation}, DecisionSource='{ResetDecisionSource}', DecisionReason='{ResetDecisionReason}', " +
                $"GameplayEntryKind='{GameplayEntryKind}'";
        }

        public bool Equals(SceneTransitionContext other)
        {
            return Equals(ScenesToLoad, other.ScenesToLoad) &&
                Equals(ScenesToUnload, other.ScenesToUnload) &&
                TargetActiveScene == other.TargetActiveScene &&
                UseFade == other.UseFade &&
                RouteId.Equals(other.RouteId) &&
                Reason == other.Reason &&
                Equals(TransitionProfile, other.TransitionProfile) &&
                GameplayEntryKind == other.GameplayEntryKind;
        }

        public override bool Equals(object obj)
        {
            return obj is SceneTransitionContext other && Equals(other);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hashCode = ScenesToLoad != null ? ScenesToLoad.GetHashCode() : 0;
                hashCode = hashCode * 397 ^ (ScenesToUnload != null ? ScenesToUnload.GetHashCode() : 0);
                hashCode = hashCode * 397 ^ (TargetActiveScene != null ? TargetActiveScene.GetHashCode() : 0);
                hashCode = hashCode * 397 ^ UseFade.GetHashCode();
                hashCode = hashCode * 397 ^ RouteId.GetHashCode();
                hashCode = hashCode * 397 ^ (Reason != null ? Reason.GetHashCode() : 0);
                hashCode = hashCode * 397 ^ (TransitionProfile != null ? TransitionProfile.GetHashCode() : 0);
                hashCode = hashCode * 397 ^ GameplayEntryKind.GetHashCode();
                return hashCode;
            }
        }

        public static bool operator ==(SceneTransitionContext left, SceneTransitionContext right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(SceneTransitionContext left, SceneTransitionContext right)
        {
            return !left.Equals(right);
        }
    }

    public readonly struct SceneTransitionStartedEvent : IEvent
    {
        public readonly SceneTransitionContext context;
        public SceneTransitionStartedEvent(SceneTransitionContext context) { this.context = context; }
    }
    public readonly struct SceneTransitionFadeInCompletedEvent : IEvent
    {
        public readonly SceneTransitionContext context;
        public SceneTransitionFadeInCompletedEvent(SceneTransitionContext context) { this.context = context; }
    }
    public readonly struct SceneTransitionScenesReadyEvent : IEvent
    {
        public readonly SceneTransitionContext context;
        public SceneTransitionScenesReadyEvent(SceneTransitionContext context) { this.context = context; }
    }
    public readonly struct SceneTransitionBeforeFadeOutEvent : IEvent
    {
        public readonly SceneTransitionContext context;
        public SceneTransitionBeforeFadeOutEvent(SceneTransitionContext context) { this.context = context; }
    }
    public readonly struct SceneTransitionCompletedEvent : IEvent
    {
        public readonly SceneTransitionContext context;
        public SceneTransitionCompletedEvent(SceneTransitionContext context) { this.context = context; }
    }
}
