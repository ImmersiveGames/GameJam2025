namespace _ImmersiveGames.NewScripts.Foundation.Platform.RuntimeMode
{
    /// <summary>
    /// Chaves padronizadas para logs de degradação (DEGRADED_MODE).
    /// Objetivo: facilitar busca no log e evitar variações de escrita entre módulos.
    /// </summary>
    public static class DegradedKeys
    {
        public static class Feature
        {
            public const string SceneRouting = "SceneRouting";
            public const string Loading = "Loading";
            public const string Fade = "Fade";
            public const string WorldLifecycle = "WorldLifecycle";
            public const string RunLifecycle = "RunLifecycle";
            public const string Gameplay = "Gameplay";
            public const string Levels = "Levels";
            public const string Navigation = "Navigation";
            public const string Gates = "Gates";
            public const string InputModes = "InputModes";
            public const string Infrastructure = "Infrastructure";
        }

        public static class Reason
        {
            public const string MissingService = "MissingService";
            public const string MissingAsset = "MissingAsset";
            public const string Timeout = "Timeout";
            public const string Disabled = "Disabled";
            public const string CapacityLimit = "CapacityLimit";
            public const string InvalidConfig = "InvalidConfig";
            public const string Unsupported = "Unsupported";
            public const string Unknown = "Unknown";
        }
    }
}
