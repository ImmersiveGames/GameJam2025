using System;
using System.Collections;
using _ImmersiveGames.NewScripts.Foundation.Core.Logging;
using _ImmersiveGames.NewScripts.UnityUtils;
using UnityEngine;
namespace _ImmersiveGames.NewScripts.AudioRuntime.Playback.Runtime.Core
{
    /// <summary>
    /// Handle runtime de playback direto de SFX (F4, sem pooling).
    /// </summary>
    public sealed class AudioSfxPlaybackHandle : MonoBehaviour, IAudioPlaybackHandle
    {
        private AudioSource _source;
        private Transform _followTarget;
        private Action<AudioSfxPlaybackHandle, EntityId, string, string, string> _onCompleted;
        private Coroutine _stopRoutine;

        private EntityId _cueId;
        private string _cueName;
        private string _modeLabel;
        private string _reason;
        private bool _isStopping;
        private bool _destroyOwnerOnComplete;

        public bool IsValid { get; private set; }
        public bool IsPlaying => IsValid && _source != null && _source.isPlaying;

        public void Initialize(
            EntityId cueId,
            string cueName,
            AudioSource source,
            Transform followTarget,
            string modeLabel,
            string reason,
            bool destroyOwnerOnComplete,
            Action<AudioSfxPlaybackHandle, EntityId, string, string, string> onCompleted)
        {
            _cueId = cueId;
            _cueName = cueName.TrimToOrDefault("<unknown>");
            _source = source;
            _followTarget = followTarget;
            _modeLabel = modeLabel.TrimToOrDefault("2D");
            _reason = reason.TrimToOrDefault("unspecified");
            _destroyOwnerOnComplete = destroyOwnerOnComplete;
            _onCompleted = onCompleted;
            IsValid = true;
            _isStopping = false;
            enabled = true;
        }

        public void Stop(float fadeOutSeconds = 0f)
        {
            if (!IsValid)
            {
                return;
            }

            if (_source == null)
            {
                Complete("stop_source_missing");
                return;
            }

            float fade = Mathf.Max(0f, fadeOutSeconds);
            if (fade <= 0f || !_source.isPlaying)
            {
                _source.Stop();
                Complete(fade <= 0f ? "stop_immediate" : "stop_not_playing");
                return;
            }

            _isStopping = true;
            if (_stopRoutine != null)
            {
                StopCoroutine(_stopRoutine);
            }

            _stopRoutine = StartCoroutine(FadeStopRoutine(fade));
            DebugUtility.LogVerbose(typeof(AudioSfxPlaybackHandle),
                $"[Audio][SFX] Stop requested cue='{_cueName}' cueId={_cueId} mode='{_modeLabel}' fade={fade:0.###} reason='{_reason}'.",
                DebugUtility.Colors.Info);
        }

        private void Update()
        {
            if (!IsValid)
            {
                return;
            }

            if (_followTarget != null)
            {
                transform.position = _followTarget.position;
            }

            if (_isStopping)
            {
                return;
            }

            if (_source == null)
            {
                Complete("source_missing");
                return;
            }

            if (!_source.loop && !_source.isPlaying)
            {
                Complete("clip_finished");
            }
        }

        private IEnumerator FadeStopRoutine(float fadeOutSeconds)
        {
            if (_source == null)
            {
                Complete("fade_source_missing");
                yield break;
            }

            float startVolume = _source.volume;
            float elapsed = 0f;

            while (elapsed < fadeOutSeconds)
            {
                if (!IsValid || _source == null)
                {
                    Complete("fade_aborted");
                    yield break;
                }

                elapsed += Time.unscaledDeltaTime;
                float t = Mathf.Clamp01(elapsed / fadeOutSeconds);
                _source.volume = Mathf.Lerp(startVolume, 0f, t);
                yield return null;
            }

            if (_source != null)
            {
                _source.Stop();
            }

            Complete("stop_fade_complete");
        }

        private void OnDestroy()
        {
            if (IsValid)
            {
                Complete("destroyed");
            }
        }

        private void Complete(string completionReason)
        {
            if (!IsValid)
            {
                return;
            }

            IsValid = false;
            _isStopping = false;

            if (_source != null)
            {
                _source.Stop();
                _source.clip = null;
            }

            _onCompleted?.Invoke(this, _cueId, _cueName, _modeLabel, completionReason);
            _onCompleted = null;

            if (_destroyOwnerOnComplete)
            {
                Destroy(gameObject);
                return;
            }

            enabled = false;
        }
    }
}
