using System;
using _ImmersiveGames.NewScripts.AudioRuntime.Authoring.Config;
using _ImmersiveGames.NewScripts.AudioRuntime.Playback.Runtime;
using _ImmersiveGames.NewScripts.AudioRuntime.Playback.Runtime.Core;
using _ImmersiveGames.NewScripts.AudioRuntime.Playback.Runtime.Host;
using _ImmersiveGames.NewScripts.Foundation.Core.Logging;
using _ImmersiveGames.NewScripts.Foundation.Platform.Composition;
using _ImmersiveGames.NewScripts.Foundation.Platform.Pooling.Contracts;
using _ImmersiveGames.NewScripts.Foundation.Platform.RuntimeMode;
using _ImmersiveGames.NewScripts.PreferencesRuntime.Contracts;
namespace _ImmersiveGames.NewScripts.AudioRuntime.Playback.Bootstrap
{
    /// <summary>
    /// Runtime composer do Audio.
    ///
    /// Responsabilidade:
    /// - compor o wiring operacional do Audio depois que os installers concluirem;
    /// - nao registrar contratos pre-runtime;
    /// - nao mascarar ausencias de prerequisitos do installer;
    /// - manter o runtime de playback isolado do trilho operacional.
    /// </summary>
    public static class AudioRuntimeComposer
    {
        private static bool _runtimeComposed;

        public static void ComposeRuntime(RuntimeModeConfig runtimeModeConfig)
        {
            CompositionPipelineExecutor.RequireBootstrapPhaseOpen(nameof(AudioRuntimeComposer));

            if (_runtimeComposed)
            {
                return;
            }

            if (runtimeModeConfig == null)
            {
                throw new InvalidOperationException("[FATAL][Config][Audio] RuntimeModeConfig obrigatorio ausente para compor o runtime.");
            }

            ResolveRuntimeModeConfigOrFail();

            ApplyPreferencesToAudioSettings();
            EnsureAudioListenerHost();
            EnsureAudioBgmService();
            PrepareAudioSfxVoicePools();

            EnsureGlobalAudioService();

            _runtimeComposed = true;

            DebugUtility.Log(typeof(AudioRuntimeComposer),
                "[Audio] Runtime composition concluida.",
                DebugUtility.Colors.Info);
        }

        private static RuntimeModeConfig ResolveRuntimeModeConfigOrFail()
        {
            if (DependencyManager.Provider.TryGetGlobal<RuntimeModeConfig>(out var runtimeModeConfig) && runtimeModeConfig != null)
            {
                return runtimeModeConfig;
            }

            throw new InvalidOperationException("[FATAL][Config][Audio] RuntimeModeConfig obrigatorio ausente para compor o Audio.");
        }

        private static void EnsureAudioListenerHost()
        {
            AudioListenerRuntimeHost.EnsureCreated();

            DebugUtility.LogVerbose(
                typeof(AudioRuntimeComposer),
                "[Audio][BOOT] Canonical AudioListener runtime host ensured.",
                DebugUtility.Colors.Info);
        }

        private static void ApplyPreferencesToAudioSettings()
        {
            if (!DependencyManager.Provider.TryGetGlobal<IPreferencesStateService>(out var preferencesState) || preferencesState == null)
            {
                throw new InvalidOperationException("[FATAL][Preferences] IPreferencesStateService obrigatorio ausente antes do apply de AudioRuntimeComposer.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IAudioSettingsService>(out var audioSettings) || audioSettings == null)
            {
                throw new InvalidOperationException("[FATAL][Audio] IAudioSettingsService obrigatorio ausente antes do apply de Preferences.");
            }

            if (!preferencesState.HasSnapshot)
            {
                throw new InvalidOperationException("[FATAL][Preferences] Snapshot obrigatorio ausente antes do apply para o runtime de Audio.");
            }

            preferencesState.ApplyTo(audioSettings, "AudioRuntimeComposer/ApplyPreferences");
        }

        private static void EnsureAudioBgmService()
        {
            RegisterIfMissing(
                factory: () =>
                {
                    DependencyManager.Provider.TryGetGlobal<AudioDefaultsAsset>(out var defaults);
                    DependencyManager.Provider.TryGetGlobal<IAudioSettingsService>(out var settings);
                    DependencyManager.Provider.TryGetGlobal<IAudioRoutingResolver>(out var routing);

                    return AudioBgmService.Create(defaults, settings, routing);
                },
                alreadyRegisteredMessage: "[Audio][BOOT] IAudioBgmService already registered.",
                registeredMessage: "[Audio][BOOT] IAudioBgmService registered (F3 BGM runtime).");
        }

        private static void EnsureGlobalAudioService()
        {
            if (!DependencyManager.Provider.TryGetGlobal<IPoolService>(out var poolService) || poolService == null)
            {
                throw new InvalidOperationException("[FATAL][Pooling] IPoolService obrigatorio ausente antes de compor o AudioGlobalSfxService.");
            }

            RegisterIfMissing(
                factory: () =>
                {
                    DependencyManager.Provider.TryGetGlobal<AudioDefaultsAsset>(out var defaults);
                    DependencyManager.Provider.TryGetGlobal<IAudioSettingsService>(out var settings);
                    DependencyManager.Provider.TryGetGlobal<IAudioRoutingResolver>(out var routing);

                    return AudioGlobalSfxService.Create(defaults, settings, routing, poolService);
                },
                alreadyRegisteredMessage: "[Audio][BOOT] IGlobalAudioService already registered.",
                registeredMessage: "[Audio][BOOT] IGlobalAudioService registered (F4/F5 direct + pooled SFX runtime).");
        }

        private static void PrepareAudioSfxVoicePools()
        {
            if (!DependencyManager.Provider.TryGetGlobal<AudioDefaultsAsset>(out var defaults) || defaults == null)
            {
                throw new InvalidOperationException("[FATAL][Audio] AudioDefaultsAsset obrigatorio ausente antes do preload de pools SFX.");
            }

            if (!DependencyManager.Provider.TryGetGlobal<IPoolService>(out var poolService) || poolService == null)
            {
                throw new InvalidOperationException("[FATAL][Pooling] IPoolService obrigatorio ausente antes do preload de pools SFX.");
            }

            AudioSfxPoolPreparationStage.Execute(
                defaults,
                poolService,
                source: nameof(AudioRuntimeComposer),
                reason: "global_sfx_voice_pool_preload");
        }

        private static void RegisterIfMissing<T>(
            Func<T> factory,
            string alreadyRegisteredMessage,
            string registeredMessage) where T : class
        {
            if (DependencyManager.Provider.TryGetGlobal<T>(out var existing) && existing != null)
            {
                DebugUtility.LogVerbose(typeof(AudioRuntimeComposer), alreadyRegisteredMessage, DebugUtility.Colors.Info);
                return;
            }

            var instance = factory();
            if (instance == null)
            {
                throw new InvalidOperationException($"Factory returned null while registering {typeof(T).Name}.");
            }

            DependencyManager.Provider.RegisterGlobal(instance);
            DebugUtility.LogVerbose(typeof(AudioRuntimeComposer), registeredMessage, DebugUtility.Colors.Info);
        }
    }
}
