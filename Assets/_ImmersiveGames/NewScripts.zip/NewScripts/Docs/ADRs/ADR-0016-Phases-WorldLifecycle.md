# ADR-0016 — Phases + modos de avanço + Pregame opcional (WorldLifecycle/SceneFlow)

## Status

**Aceito / Ativo**

## Contexto

Com o **Baseline 2.0** estabelecido, o projeto já possui:

- **WorldLifecycle determinístico**, com reset canônico em `SceneTransitionScenesReadyEvent`.
- **SceneFlow** com ordem estável de eventos (FadeIn → ScenesReady → Reset → FadeOut → Completed).
- **PhaseContext** com `Pending` e `Current`, além de `PhaseIntentRegistry` para transições de cena.

A necessidade atual é padronizar, sem ambiguidade, dois modos de **“Nova Phase”** e a existência de um **Pregame opcional** entre o reset e a revelação final (FadeOut), sem bloquear o fluxo e respeitando os invariantes do baseline.

Além disso, o Pregame introduz um requisito funcional específico:

- **Durante o Pregame, não pode haver simulação de gameplay**, mas **o menu/UI deve continuar operacional** (ex.: sair para menu, reset, navegação, submit/cancel).

## Decisão

### 1) Nomenclatura e modos de avanço de Phase

Definimos dois modos explícitos para “Nova Phase”:

1. **Phase In-Place** (`PhaseAdvanceInPlace`)
    - Troca de phase **no mesmo gameplay** (sem troca de cenas).
    - Pode exigir uma transição “curta” (ex.: fechar cortina/fade) para remontar o mundo, mas **não** executa SceneFlow de carga/descarga de cenas.
    - Deve ser observável e determinístico.

2. **Phase With Transition** (`PhaseAdvanceWithTransition`)
    - Troca de phase com **transição completa**: fade + loading + novas cenas (SceneFlow).
    - Deve produzir as evidências canônicas do SceneFlow e do WorldLifecycle.

> Nota: o ADR-0017 detalha a taxonomia e critérios de escolha. O ADR-0016 registra a intenção do pipeline e a posição do Pregame no fluxo.

### 2) Pregame opcional (posição no fluxo)

O **Pregame** é uma etapa opcional executada **após** o reset determinístico do WorldLifecycle e **antes** do FadeOut/Completed do SceneFlow, com finalidade típica de:

- splash screen,
- cutscene,
- preparação de UI/estado,
- confirmação explícita para iniciar (QA/Debug).

**Ordem canônica (quando Pregame está ativo):**

**FadeIn → ScenesReady → Reset → Pregame → FadeOut → Completed**

Quando o Pregame estiver desativado (ou não aplicável), o fluxo segue o baseline:

**FadeIn → ScenesReady → Reset → FadeOut → Completed**

### 3) Intenções funcionais do Pregame (o que é “correto”)

Durante o Pregame:

- **Bloquear apenas a simulação de gameplay**, sem bloquear UI/menu.
    - Gameplay: movimentação/ações de jogo, spawns, ticks de sistemas de simulação.
    - UI/Menu: navegação, submit/cancel e comandos de “sair/reset” devem continuar disponíveis.
- **O início do Pregame deve ser explícito no log**, com orientação de como prosseguir.
- **Deve existir uma saída determinística**:
    - conclusão normal (Complete),
    - skip explícito (Skip),
    - fail-safe (timeout ou falha do step) para evitar deadlock.

## Detalhes de implementação (contratos)

### Gate de simulação durante Pregame

- Ao entrar em Pregame, o sistema adquire o token **`sim.gameplay`** (SimulationGate).
- Esse token deve significar: **“bloqueie apenas gameplay”**, e **não** “bloqueie tudo”.
- Políticas recomendadas no `IStateDependentService` / input gating:
    - Com **apenas** `sim.gameplay` ativo:
        - **Move** e demais ações de gameplay: **bloqueadas**.
        - **Navigate / UiSubmit / UiCancel / RequestReset / RequestQuit**: **permitidas**.
    - Com tokens de fluxo (ex.: `flow.scene_transition`, `flow.loading`, `flow.soft_reset`):
        - comportamento pode ser mais restritivo, conforme regras do baseline.

### Observabilidade obrigatória (logs)

O Pregame deve produzir logs com assinatura inequívoca:

- `[OBS][Pregame] PregameStarted ...`
- `[OBS][Pregame] GameplaySimulationBlocked token='sim.gameplay' ...`
- Log de orientação (humano):
    - `"[Pregame] Pregame ativo: simulação gameplay bloqueada; use QA/Pregame/Complete ou QA/Pregame/Skip para prosseguir."`
- `[OBS][Pregame] PregameCompleted ...` (result: completed/skipped/failed)
- `[OBS][Pregame] GameplaySimulationUnblocked token='sim.gameplay' ...`

Quando o Pregame for pulado por regra (ex.: perfil não gameplay / cena não gameplay / sem conteúdo), deve registrar:

- `[OBS][Pregame] PregameSkipped reason='...' ...`

### Anti-deadlock (não bloquear o fluxo)

- `WaitForCompletionAsync` **não pode** ficar pendente indefinidamente em produção.
- Deve existir, no mínimo, um dos seguintes mecanismos:
    - timeout do pregame,
    - step que conclui automaticamente,
    - fail-safe que faz `SkipPregame("step_failed" | "timeout")` em caso de falha.

## Como testar (QA)

### Context Menu

- `QA/Phase/Advance In-Place (TestCase: PhaseInPlace)`.
- `QA/Phase/Advance With Transition (TestCase: PhaseWithTransition)`.
- `QA/Pregame/Complete (Force)` (encerra o Pregame e permite Playing).
- `QA/Pregame/Skip (Force)` (pula o Pregame e permite Playing).

### Disponibilidade do QA (não depender de cena)

- Deve existir um instalador idempotente que garanta um `GameObject` persistente (ex.: `QA_Pregame` em `DontDestroyOnLoad`) contendo o componente de Context Menu.
- Opcional (Editor): `MenuItem` equivalente para Complete/Skip sem selecionar o objeto.

### Evidência esperada

- Logs de `PhaseChangeRequested` + `PhaseCommitted`.
- Logs de `PregameSkipped` **ou** `PregameStarted` + `GameplaySimulationBlocked` + (`PregameCompleted` ou `PregameTimedOut`) + `GameplaySimulationUnblocked`.
- SceneFlow com ordem:
    - **FadeIn → ScenesReady → Reset → (Pregame opcional) → FadeOut → Completed**.
- Durante Pregame:
    - UI/menu operacionais (navegação + reset/quit funcionam),
    - ações de gameplay bloqueadas.

## Consequências

- O Pregame se torna uma etapa observável e testável, sem introduzir travas silenciosas.
- O token `sim.gameplay` passa a ter semântica clara: bloquear apenas simulação de gameplay.
- QA ganha um mecanismo determinístico para liberar o fluxo e validar PostGame/Outcome sem depender de UI específica do step.
