# Guia Visual — Reset de Componente Base 2.0

Abra primeiro:

- `index.html`

Este conjunto explica como configurar e usar o novo reset de componente sem depender de rails antigos.

Regras centrais:

- o reset é dirigido por `ActivityResetIntent`;
- a receita de estado vem de `ActivityResetStateProfileKind`;
- o componente precisa estar no caminho de descoberta da Activity;
- o reset não acontece sozinho; ele é chamado pelo pipeline ou por QA.
- o teardown de atributo reaproveita `EntryInitialize` e não usa um intent separado de cleanup.

Como ler o conjunto:

- `01-reset.html` mostra como criar e ligar um novo reset;
- `02-snapshot.html` mostra captura de estado;
- `03-restore.html` mostra restauração;
- `04-release.html` mostra liberação/limpeza;
- `05-setup.html` mostra preparação do componente;
- `06-binding.html` mostra conexão de capacidades;
- `07-permission-gate.html` mostra bloqueio/liberação de uso;
- `08-save-persistencia.html` mostra persistência via snapshot.

Arquivos incluídos:

- `index.html`
- `Guia-Visual-Componentes-Activity-Base20.html`
- `Guia-Visual-Componentes-Activity-Base20-v2.html`
- `01-reset.html`
- `02-snapshot.html`
- `03-restore.html`
- `04-release.html`
- `05-setup.html`
- `06-binding.html`
- `07-permission-gate.html`
- `08-save-persistencia.html`

Com Actor:

Actor + `ActorCapabilitySurface` + componente com endpoints de reset.

Sem Actor:

Activity Object / Contributor / Marker + componente com endpoints de reset.
