# RESET-ARCH-5D — Remove Actor Reset Generic Fallback

Status: Applied / pending compile + smoke.

## Objetivo

Remover o rail genérico de execução do actor reset e exigir handlers explícitos por `ActivityResetIntent`.

## Perguntas obrigatórias

- Owner da decisão: `SessionActivityPipeline` classifica QA/lifecycle e `ActivityEntryPipeline` resolve `ActivityResetScopePlan`; `ActorResetAdapter` apenas despacha o handler já comandado.
- Tipo: contratos + adapter + endpoints. O adapter é side-effect técnico, endpoints executam receita, groups permanecem detalhe técnico.
- Comportamento final ou bridge: remoção de bridge genérica. `ActorResetGroup` ainda é bridge técnica transitória.
- Compatibilidade necessária: não. `IActorResetEndpoint.ApplyReset(...)` era fallback legado e foi removido do contrato.
- Sintoma ou fronteira: fronteira. O fallback permitia execução sem intent/profile handler explícito.
- Owner duplicado: não. O adapter não decide policy; falha quando o endpoint não suporta o intent comandado.

## Alterações

- `IActorResetEndpoint` mantém apenas `Supports(ActorResetGroup group)`.
- `ActorResetAdapter` remove `endpoint.ApplyReset(context)`.
- Falha explícita: `actor_reset_intent_handler_missing`.
- Endpoints principais mantêm handlers específicos por intent.
- Métodos públicos legados `ApplyReset(ActorResetContext)` foram removidos dos endpoints migrados.

## Arquivos alterados

- `Actors/Capabilities/Reset/ActorResetContracts.cs`
- `Actors/Capabilities/Reset/ActorResetAdapter.cs`
- `GameplayRuntime/Authoring/Actors/Player/PlayerActor.cs`
- `GameplayRuntime/Authoring/Actors/Player/Movement/PlayerMovementController.cs`
- `Actors/Players/Runtime/PlayerActorParticipationState.cs`
- `Actors/Projectile/Runtime/ActorProjectileSpawnRuntimeTracker.cs`
- `Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md`

## Smoke esperado

- Sem `FATAL`.
- Sem `Exception`.
- Sem `route_transition_failed`.
- Sem `checkpointStatus='Failed'`.
- Sem foreign/stale indevido.
- `resetHandler='IActorEntryInitializeResetEndpoint'`.
- `resetHandler='IActorRuntimeLocalResetEndpoint'`.
- `resetHandler='IActorRuntimeActivityResetEndpoint'`.
- `resetHandler='IActorRuntimeActivityTransitionResetEndpoint'`.
- `IActorResetEndpoint.ApplyReset = 0`.
- `legacy_apply_reset = 0`.
- `actor_reset_intent_handler_missing = 0`.
- `RestartCurrentActivity = Passed`.
- `Activity01ToActivity02 = Passed`.
- `RouteExitBackToMenu = Passed`.
