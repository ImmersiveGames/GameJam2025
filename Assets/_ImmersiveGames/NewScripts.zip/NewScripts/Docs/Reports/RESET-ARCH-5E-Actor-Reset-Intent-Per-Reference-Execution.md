# RESET-ARCH-5E — Actor Reset Intent Per Reference Execution

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActorResetGroup` do loop de execução do actor reset. O actor reset deve executar uma vez por referência canônica de inventory e sempre por handler explícito de `ActivityResetIntent`.

## Perguntas obrigatórias

- Owner da decisão: `SessionActivityPipeline` classifica QA/lifecycle, `ActivityEntryPipeline` resolve o `ActivityResetScopePlan`, `ActivityEntryParticipantResetStage` ordena o participant reset e `ActorResetAdapter` executa side-effect técnico comandado.
- Tipo: adapter + observabilidade. `ActorResetGroup` permanece metadado técnico transitório; não é mais multiplicador de execução.
- Comportamento final ou bridge: redução de bridge. O final é reset por `Intent + StateProfile`; o grupo técnico ainda existe para inventory/diagnóstico.
- Compatibilidade necessária: apenas para metadado técnico temporário. Não há mais fallback genérico nem loop de execução por grupo.
- Sintoma ou fronteira: fronteira. O erro era deixar grupo técnico decidir a execução material.
- Owner duplicado: não. O adapter não decide lifecycle/policy, só executa o handler do intent recebido.

## Alterações

- `ActorResetAdapter` executa uma vez por `ActorCapabilityResetEndpointReference`.
- O loop interno por `SupportedGroups` foi removido.
- `ActorResetGroup` agora é resolvido como metadado técnico primário por referência.
- Se uma referência vier sem grupo técnico, com `Unknown` ou misturando múltiplos grupos técnicos, o adapter falha explicitamente.
- Logs do adapter passam a expor:
  - `technicalGroupMode='legacy_capability_group_metadata_only'`
  - `executionMode='intent_handler_per_reference'`

## Falhas explícitas novas

```text
actor_reset_reference_missing_technical_group
actor_reset_reference_unknown_technical_group
actor_reset_reference_mixes_technical_groups
```

## Arquivos alterados

- `Actors/Capabilities/Reset/ActorResetAdapter.cs`
- `Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md`

## Smoke esperado

- Sem `FATAL`.
- Sem `Exception`.
- Sem `route_transition_failed`.
- Sem `checkpointStatus='Failed'`.
- Sem foreign/stale indevido.
- `resetHandler='IActorEntryInitializeResetEndpoint'`.
- `resetHandler='IActorRuntimeLocalResetEndpoint'`.
- `resetHandler='IActorRuntimeActivityResetEndpoint'`.
- `resetHandler='IActorRuntimeActivityTransitionResetEndpoint'`.
- `IActorResetEndpoint.ApplyReset = 0`.
- `actor_reset_intent_handler_missing = 0`.
- `actor_reset_reference_mixes_technical_groups = 0`.
- `technicalGroupMode='legacy_capability_group_metadata_only'`.
- `executionMode='intent_handler_per_reference'`.
- `RestartCurrentActivity = Passed`.
- `Activity01ToActivity02 = Passed`.
- `RouteExitBackToMenu = Passed`.
