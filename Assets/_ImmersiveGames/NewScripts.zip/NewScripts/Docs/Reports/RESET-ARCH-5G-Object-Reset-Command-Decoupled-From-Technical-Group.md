# RESET-ARCH-5G — Object Reset Command Decoupled From Technical Group

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActivityStateResetGroup` do contrato principal de execução do object reset, mantendo o grupo apenas como metadado técnico transitório enquanto authoring/inventory ainda dependem dele.

## Perguntas obrigatórias

- Pipeline dono da decisão: `SessionActivityPipeline` classifica QA/lifecycle e `ActivityEntryPipeline` resolve `ActivityResetScopePlan`; `ActivityResetStage` executa object reset por report elegível.
- Tipo: `ActivityObjectResetCommand` é command runtime resolvido; `IActivityObjectResetEndpoint` é endpoint base; handlers por intent são execução.
- Comportamento final ou bridge: corte intermediário. Remove o enum do command/endpoint, mas deixa metadata técnica no report.
- Compatibilidade necessária: apenas temporária para authoring/inventory/checkpoints já existentes.
- Erro corrigido: `ActivityStateResetGroup` ainda vazava para o command e para o endpoint como se decidisse suporte.
- Owner duplicado: não introduzido. Endpoint não decide lifecycle/policy.

## Alterações

- `ActivityObjectResetCommand` não recebe nem valida mais `ActivityStateResetGroup`.
- `ActivityObjectResetCommand` passa a carregar `TechnicalResetGroupMetadata` como string observacional.
- `IActivityObjectResetEndpoint` deixa de expor `Supports(ActivityStateResetGroup)`.
- `ActivityObjectDefaultResetEndpoint` remove `Supports(...)`.
- Validação foreign/stale de object reset deixa de exigir `result.Command.ResetGroup`.
- Logs preservam `technicalResetGroup` apenas como metadata transitória.

## Arquivos alterados

- `NewScripts/SessionActivity/Contracts/ActivityObjectResetContracts.cs`
- `NewScripts/SessionActivity/Authoring/ActivityObjectDefaultResetEndpoint.cs`
- `NewScripts/SessionActivity/Pipeline/Stages/ActivityResetStage.cs`
- `NewScripts/SessionActivity/Pipeline/Stages/ActivityEntryObjectSetupStages.cs`
- `NewScripts/SessionActivity/Pipeline/SessionActivityPipeline.cs`
- `NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md`

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActivityObjectStateProfileApplied
resetHandler='IActivityObjectEntryInitializeResetEndpoint'
resetHandler='IActivityObjectRuntimeLocalResetEndpoint'

IActivityObjectResetEndpoint.ApplyReset = 0
object_reset_intent_handler_missing = 0
object_reset_report_mixes_technical_groups = 0

technicalGroupMode='legacy_activity_state_reset_group_metadata_only'
executionMode='intent_handler_per_report'

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```

## Pendência explícita

Ainda restam `ActivityStateResetGroup` em authoring/inventory/checkpoints. Isso deve ser removido em corte posterior de fechamento, não por alias/compat.
