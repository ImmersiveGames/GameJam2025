# RESET-ARCH-5C — Remove Object Reset Generic Fallback

Status: Applied / pending compile + smoke.

## Objetivo

Remover o fallback genérico de object reset para que a execução dependa obrigatoriamente de handlers explícitos por `ActivityResetIntent`.

## Perguntas obrigatórias

- Owner da decisão: `SessionActivityPipeline` e `ActivityEntryPipeline` classificam lifecycle/intent/profile; `ActivityResetStage` e `ActivityEntryObjectSetupStages` executam o reset comandado.
- Tipo: contrato + stage dispatch + endpoint authoring.
- Comportamento final ou bridge: aproxima comportamento final; `ActivityStateResetGroup` ainda é bridge técnica de seleção.
- Compat necessária: não para fallback genérico de execução; removida.
- Sintoma ou fronteira: a falha estava na fronteira de execução, onde o endpoint podia receber reset sem handler específico.
- Owner duplicado: não introduzido; endpoint aplica estado, stage despacha, pipeline decide intent/profile.

## Alterações

- `IActivityObjectResetEndpoint` deixa de expor `ApplyReset(...)`.
- `ActivityObjectDefaultResetEndpoint` remove `ApplyReset(...)` legado.
- `ActivityEntryObjectSetupStages.ApplyObjectResetByIntent(...)` deixa de chamar fallback genérico.
- Ausência de handler específico retorna `ActivityObjectResetResultKind.Failed` com `object_reset_intent_handler_missing`.

## Critério de smoke

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
ActivityObjectStateProfileApplied
resetHandler='IActivityObjectEntryInitializeResetEndpoint'
resetHandler='IActivityObjectRuntimeLocalResetEndpoint'
IActivityObjectResetEndpoint.ApplyReset = 0
legacy_object_reset_fallback = 0
object_reset_intent_handler_missing = 0
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
