# RESET-ARCH-4C — Actor MovementTransient StateProfile Split

Status: Applied / pending compile + smoke.

## Objetivo

Migrar o reset de `MovementTransient` do `PlayerMovementController` para receitas explícitas por `ActivityResetIntent` + `ActivityResetStateProfileKind`, sem alterar ainda o contrato legado `ActorResetGroup`.

## Owner

- `SessionActivityPipeline` classifica QA/lifecycle macro.
- `ActivityEntryPipeline` resolve o `ActivityResetScopePlan`.
- `ActivityEntryParticipantResetStage` executa participant reset na ordem canônica.
- `ActorResetAdapter` despacha o handler por intent.
- `PlayerMovementController` aplica somente a receita de limpeza transitória.

## Alteração

`PlayerMovementController` agora aplica `ApplyMovementTransientStateProfile(...)` para:

```text
EntryInitialize -> InitialState
RuntimeLocalReset -> RuntimeLocalState
RuntimeActivityReset -> RuntimeActivityState
RuntimeActivityTransitionReset -> RuntimeActivityTransitionState
RuntimeRouteTransitionReset -> RuntimeRouteTransitionState
```

A receita atual é comum e intencionalmente limitada:

```text
- limpar input de movimento;
- zerar velocidade horizontal;
- zerar angular velocity quando houver Rigidbody;
- preservar o owner de enable/disable do controle no pipeline/permissão.
```

## Observabilidade esperada

```text
PlayerMovementTransientStateProfileApplied
resetIntent='EntryInitialize'
resetStateProfile='InitialState'
movementProfileKind='InitialState'

PlayerMovementTransientStateProfileApplied
resetIntent='RuntimeLocalReset'
resetStateProfile='RuntimeLocalState'
movementProfileKind='RuntimeLocalState'

PlayerMovementTransientStateProfileApplied
resetIntent='RuntimeActivityReset'
resetStateProfile='RuntimeActivityState'
movementProfileKind='RuntimeActivityState'

PlayerMovementTransientStateProfileApplied
resetIntent='RuntimeActivityTransitionReset'
resetStateProfile='RuntimeActivityTransitionState'
movementProfileKind='RuntimeActivityTransitionState'
```

## Fora do corte

- Remover `ActorResetGroup`.
- Migrar projectile reset para receita real.
- Migrar object reset.
- Migrar QA attribute commands.
- Criar target groups.

## Critério de smoke

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
resetHandler='IActorResetEndpoint.ApplyReset' = 0
```
