# RESET-ARCH-5J-H1 — Object Setup Stages Utility Restore Compile Fix

## Status

Applied / pending compile.

## Objetivo

Corrigir regressão de compilação introduzida no pacote `RESET-ARCH-5J`, sem avançar arquitetura de reset.

## Problema

O arquivo `ActivityEntryObjectSetupStages.cs` foi empacotado truncado após `ActivityEntryObjectResetStage`.
Com isso, classes auxiliares que continuavam sendo dependência legítima dos stages deixaram de existir no projeto compilado:

- `ActivityEntryObjectSnapshotRestoreStage`
- `ActivityEntryObjectSetupStageUtility`

A ausência dessas classes quebrou chamadas em:

- `ActivityEntryPipeline`
- `ActivityEntryActorInventoryStage`
- `ActivityEntryObjectSetupStages`
- `SessionActivityPipeline`

## Correção

O arquivo `ActivityEntryObjectSetupStages.cs` foi recomposto preservando as alterações do `RESET-ARCH-5J` e restaurando:

- `ActivityEntryObjectSnapshotRestoreStage`
- `ActivityEntryObjectSetupStageUtility`
- helpers de identity/current-entry validation
- helpers de snapshot contract/restore
- helpers de inventory endpoint resolution
- helpers de object reset result validation

A mensagem de failure do handler de object reset também foi alinhada ao shape 5J:

- usa `resetDescriptor`
- usa `descriptorMode='endpoint_inventory'`
- não volta a emitir `technicalResetGroup` no object reset

## Ownership

- Pipeline owner: `ActivityEntryPipeline` para setup/readiness/object state na entry.
- Stage owner: `ActivityEntryObjectSetupStages` e sub-stages internos.
- Policy owner: `ActivityResetBoundaryPolicy` para intent/scope/profile.
- Adapter/endpoint owner: endpoints concretos de object reset/snapshot.

## Fora do corte

- Não remove `StateResetRequirement.ResetGroups`.
- Não altera runtime behavior.
- Não altera QA flow.
- Não adiciona fallback.
- Não reintroduz `supportedResetGroups` em contributor/report.

## Verificação estática local

- `ActivityEntryObjectSetupStages.cs` brace balance = 0.
- `ActivityEntryObjectSnapshotRestoreStage` presente.
- `ActivityEntryObjectSetupStageUtility` presente.
- `SupportedResetGroups` ausente no arquivo corrigido.
- `TechnicalResetGroupMetadata` ausente no arquivo corrigido.
