# RESET-ARCH-6C — Actor Reset Result Decoupled From Technical Group

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActorResetGroup` do resultado de execução do actor reset. O adapter já executa por referência de inventory e por handler explícito de `ActivityResetIntent`; o resultado não deve voltar a expor grupos técnicos como eixo de sucesso/falha.

## Classificação

- Pipeline owner: `ActivityEntryPipeline` / QA macro apenas orquestram chamada.
- Adapter owner: `ActorResetAdapter` executa side-effect por handler.
- Resultado: fact/observabilidade de execução por referência, não policy.
- `ActorResetGroup`: metadado técnico transitório restante em contribution/reference.

## Mudanças

- Removido `ActorResetResult.AppliedGroups`.
- Removido `ActorResetResult.SkippedGroups`.
- Removido `ActorResetResult.SkippedGroupReasons`.
- Criado `AppliedReferenceCount`.
- Criado `SkippedReferenceCount`.
- Criado `ActorResetSkippedReferenceReason(capabilityId, reasonCode)`.
- Validação de required reset passa a falhar por referência/capability, não por group.
- Logs de stage/QA passam a reportar `appliedReferenceCount` e `skippedReferenceCount`.

## Ainda pendente

- Remover `ActorResetGroup` de `IActorResetContribution.SupportedGroups`.
- Remover `ActorCapabilityResetEndpointReference.SupportedGroups`.
- Trocar o metadado técnico de referência por descriptor/capability sem enum de group.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem error CS
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActorResetResult.AppliedGroups = 0
ActorResetResult.SkippedGroups = 0
ActorResetSkippedGroupReason = 0
appliedReferenceCount presente
skippedReferenceCount presente
actor_reset_intent_handler_missing = 0
required_reset_reference_failed = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
