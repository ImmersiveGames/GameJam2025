# RESET-ARCH-5H — Object Reset Report Gated By Endpoint Inventory

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActivityStateResetGroup` como gate de execução no report de object reset. O grupo técnico permanece apenas como metadado transitório, quando existir, mas não bloqueia a emissão do command nem a execução do handler de intent.

## Perguntas obrigatórias

- Pipeline owner da decisão: `SessionActivityPipeline` classifica o intent de QA/local e `ActivityEntryPipeline` resolve o intent/profile na entrada. O stage executa o command já resolvido.
- Tipo: stage + command runtime. O report fornece target/contributor; o inventory fornece endpoints; o handler executa side-effect.
- Comportamento final ou bridge: bridge transitória. `SupportedResetGroups` ainda existe como metadado, mas deixou de ser gate.
- Compatibilidade necessária: não como shape final. Mantida só enquanto os assets/documentos ainda carregam o campo antigo.
- Erro no sintoma ou fronteira: fronteira antiga; report/authoring de grupo técnico ainda influenciava execução.
- Owner duplicado: reduzido. O endpoint inventory, não o grupo técnico, passa a definir se há executor.

## Alterações

- `ActivityResetStage` não exige mais `report.SupportedResetGroups` para executar object reset.
- `ActivityEntryObjectSetupStages` aplica a mesma regra no reset de entrada.
- `ActivityObjectResetCommand` recebe `TechnicalResetGroupMetadata` apenas para observabilidade.
- `required_reset_endpoint_missing` falha explicitamente quando um report `Required` não possui endpoint de reset resolvido.
- `reset_endpoint_missing` registra skip explícito para report opcional sem endpoint.

## Não feito

- Não remove `ActivityObjectContributor.supportedResetGroups`.
- Não remove `ActivityStateResetGroup`.
- Não altera `StateResetRequirement.ResetGroups`.
- Não cria target groups.
- Não muda snapshot/restore/release.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActivityObjectStateProfileApplied
resetHandler='IActivityObjectEntryInitializeResetEndpoint'
resetHandler='IActivityObjectRuntimeLocalResetEndpoint'

IActivityObjectResetEndpoint.ApplyReset = 0
object_reset_intent_handler_missing = 0
required_reset_endpoint_missing = 0
reset_endpoint_missing = 0

technicalGroupMode='legacy_activity_state_reset_group_metadata_only'
executionMode='intent_handler_per_report'

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
