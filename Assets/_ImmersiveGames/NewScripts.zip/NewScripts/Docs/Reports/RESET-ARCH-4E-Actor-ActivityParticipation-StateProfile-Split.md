# RESET-ARCH-4E — Actor ActivityParticipation StateProfile Split

Status: Applied / pending compile + smoke.

## Objetivo

Separar o reset de `ActivityParticipation` por `ActivityResetIntent` + `ActivityResetStateProfileKind` no `PlayerActorParticipationState`, sem remover ainda `ActorResetGroup.ActivityParticipation`.

## Perguntas obrigatórias

### Qual pipeline é dono desta decisão?

`SessionActivityPipeline` classifica o lifecycle macro e QA. `ActivityEntryPipeline` resolve o `ActivityResetScopePlan`. `ActivityEntryParticipantResetStage` executa o reset de participantes. `PlayerActorParticipationState` apenas aplica a receita recebida.

### Isso é stage, policy, command, fact, adapter, endpoint, snapshot ou authoring data?

- `resetIntent`/`resetStateProfile`: payload de command/policy resolvido.
- `PlayerActorParticipationState`: endpoint runtime de reset.
- Logs `PlayerActorParticipationStateProfileApplied`: observabilidade/fact.

### Isso é comportamento final ou bridge transitória?

Parcialmente final para participação do PlayerActor; ainda existe bridge transitória porque `ActorResetGroup.ActivityParticipation` continua no inventário como detalhe técnico.

### Essa compatibilidade ainda é necessária?

Sim, temporariamente, para preservar scanner/inventory/checkpoints atuais enquanto os endpoints migram para receitas por intent/profile.

### O erro está no sintoma ou na fronteira arquitetural errada?

Na fronteira antiga: `ActivityParticipation` era tratado como grupo técnico de reset. Agora o comportamento passa a ser dirigido por intent/profile.

### Existe owner duplicado para o mesmo lifecycle?

Não. O endpoint não decide lifecycle; apenas aplica a receita comandada.

## Receita implementada

```text
EntryInitialize -> InitialState -> marca o PlayerActor como ativo na activity/entry inicial.
RuntimeLocalReset -> RuntimeLocalState -> reafirma participação ativa na activity/entry corrente.
RuntimeActivityReset -> RuntimeActivityState -> marca participação ativa na nova entry de restart.
RuntimeActivityTransitionReset -> RuntimeActivityTransitionState -> marca participação ativa na próxima activity/entry materializada.
RuntimeRouteTransitionReset -> RuntimeRouteTransitionState -> limpa participação de activity.
```

## Arquivos alterados

```text
NewScripts/Actors/Players/Runtime/PlayerActorParticipationState.cs
NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
NewScripts/Docs/Reports/RESET-ARCH-4E-Actor-ActivityParticipation-StateProfile-Split.md
```

## Evidência esperada

```text
PlayerActorParticipationStateProfileApplied
resetIntent='EntryInitialize'
resetStateProfile='InitialState'
participationProfileKind='InitialState'

PlayerActorParticipationStateProfileApplied
resetIntent='RuntimeLocalReset'
resetStateProfile='RuntimeLocalState'
participationProfileKind='RuntimeLocalState'

PlayerActorParticipationStateProfileApplied
resetIntent='RuntimeActivityReset'
resetStateProfile='RuntimeActivityState'
participationProfileKind='RuntimeActivityState'

PlayerActorParticipationStateProfileApplied
resetIntent='RuntimeActivityTransitionReset'
resetStateProfile='RuntimeActivityTransitionState'
participationProfileKind='RuntimeActivityTransitionState'
```

## Fora do corte

```text
- Remover ActorResetGroup.ActivityParticipation.
- Migrar object reset.
- Criar target groups.
- Eliminar rails paralelos de QA attribute/object reset.
- Atualizar guia final de uso do reset.
```
