# RESET-ARCH-6H — Reset Bridge Vocabulary Cleanup

Status: Applied / pending compile + smoke.

## Objetivo

Remover vocabulário de bridge da observabilidade ativa de reset após o fechamento da frente `ResetGroup`.

Este corte é deliberadamente textual/observacional. Ele não altera execução, policy, commands, inventory, handlers ou adapters.

## Perguntas obrigatórias

| Pergunta | Resposta |
|---|---|
| Qual pipeline é dono desta decisão? | `SessionActivityPipeline` continua dono do lifecycle macro; `ActivityEntryPipeline` executa entry; `ActivityResetBoundaryPolicy` classifica boundary/eligibilidade. |
| Isso é stage, policy, command, fact, adapter, endpoint, snapshot ou authoring data? | Observabilidade de policy/stage/endpoint. Não é novo command, adapter ou authoring. |
| Isso é comportamento final ou bridge transitória? | Comportamento final parcial já validado; o corte remove apenas nomes que ainda sugeriam bridge transitória. |
| Essa compatibilidade ainda é necessária? | Não. Os termos `Bridge` eram nomes transitórios em logs/sources, sem valor funcional. |
| O erro está no sintoma ou na fronteira arquitetural errada? | Fronteira de linguagem/observabilidade: o runtime já estava correto, mas os logs ainda comunicavam shape transitório. |
| Existe owner duplicado para o mesmo lifecycle? | Não introduz owner. Apenas alinha nomes aos owners já existentes. |

## Mudanças

```text
ResetIntentStateProfileBridge -> ResetIntentStateProfilePolicy
entry_initialize_object_reset_bridge -> entry_initialize_object_state_profile
runtime_local_object_reset_bridge -> runtime_local_object_state_profile
runtime_activity_object_reset_bridge -> runtime_activity_object_state_profile
runtime_activity_transition_object_reset_bridge -> runtime_activity_transition_object_state_profile
runtime_route_transition_object_reset_bridge -> runtime_route_transition_object_state_profile
attribute_setup_lifecycle_bridge -> attribute_setup_state_profile
```

## Arquivos alterados

```text
NewScripts/SessionActivity/Authoring/ActivityObjectDefaultResetEndpoint.cs
NewScripts/SessionActivity/Pipeline/Policies/ActivityResetBoundaryPolicy.cs
NewScripts/SessionActivity/Pipeline/Stages/ActivityResetStage.cs
NewScripts/SessionActivity/Pipeline/Stages/ActivityEntryObjectSetupStages.cs
NewScripts/SessionActivity/Pipeline/Stages/ActivityEntryParticipantResetStage.cs
NewScripts/SessionActivity/Pipeline/Stages/ActivityEntryActorAttributeStage.cs
NewScripts/SessionActivity/Pipeline/ActivityEntryPipeline.cs
NewScripts/SessionActivity/Pipeline/SessionActivityPipeline.cs
NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
```

## Verificação estática esperada

```text
ResetIntentStateProfileBridge = 0 em código ativo
entry_initialize_object_reset_bridge = 0 em código ativo
runtime_local_object_reset_bridge = 0 em código ativo
runtime_activity_object_reset_bridge = 0 em código ativo
runtime_activity_transition_object_reset_bridge = 0 em código ativo
runtime_route_transition_object_reset_bridge = 0 em código ativo
attribute_setup_lifecycle_bridge = 0 em código ativo
```

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem error CS
sem checkpointStatus='Failed'
sem foreign/stale indevido

ResetIntentStateProfilePolicy presente
ResetIntentStateProfileBridge = 0
*_reset_bridge = 0
attribute_setup_lifecycle_bridge = 0

resetDescriptor='endpoint_inventory' preservado
descriptorMode='endpoint_inventory' preservado
executionMode='intent_handler_per_reference' preservado
executionMode='intent_handler_per_report' preservado

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
