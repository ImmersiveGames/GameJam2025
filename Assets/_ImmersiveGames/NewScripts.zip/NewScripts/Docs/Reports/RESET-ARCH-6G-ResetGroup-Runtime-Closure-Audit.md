# RESET-ARCH-6G — ResetGroup Runtime Closure Audit

Status: CLOSED / documentação + auditoria estática.

## Objetivo

Fechar a frente de remoção dos grupos técnicos antigos do runtime ativo de reset.

## Perguntas obrigatórias

### Qual pipeline é dono desta decisão?

`SessionActivityPipeline` continua dono do lifecycle macro; `ActivityEntryPipeline` coordena entry/setup/reset; `ActivityResetBoundaryPolicy` classifica intent/profile/boundary; stages executam reset por inventory endpoint.

### Isso é stage, policy, command, fact, adapter, endpoint, snapshot ou authoring data?

Este corte é documentação/auditoria. O comportamento validado é: policy decide boundary/eligibility; command carrega intent/profile/endpoint inventory; adapter executa side-effect por handler explícito; facts observam descriptor/handler.

### Isso é comportamento final ou bridge transitória?

Remover `ResetGroup` é comportamento final. `resetDescriptor='endpoint_inventory'` permanece como descriptor operacional atual. `TargetGroup` futuro deve nascer em corte próprio.

### Essa compatibilidade ainda é necessária?

Não. `ActorResetGroup` e `ActivityStateResetGroup` não são mais necessários no código ativo.

### O erro está no sintoma ou na fronteira arquitetural errada?

A fronteira errada era usar grupos técnicos de capability como policy/target/runtime execution axis.

### Existe owner duplicado para o mesmo lifecycle?

Não no shape validado: lifecycle fica no pipeline/stage; eligibility na policy; side-effect no endpoint/adapter; inventory é índice técnico.

## Evidência estática

Grep no código ativo após `RESET-ARCH-6F`:

```text
ActorResetGroup = 0
ActivityStateResetGroup = 0
SupportedGroups = 0
supportedResetGroups = 0
supportedResetGroup = 0
technicalResetGroup = 0
technicalResetGroups = 0
legacy_capability_group = 0
legacy_activity_state_reset_group = 0
```

## Evidência funcional do smoke 6F

```text
FATAL = 0
Exception = 0
route_transition_failed = 0
error CS = 0
checkpointStatus='Failed' = 0
foreign = 0
stale = 0

ActorResetGroup = 0
SupportedGroups = 0
technicalResetGroup = 0
technicalResetGroups = 0

resetDescriptor='endpoint_inventory' = presente
descriptorMode='endpoint_inventory' = presente
executionMode='intent_handler_per_reference' = presente

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```

## Resultado

A frente `ResetGroup` está fechada para runtime ativo de reset.

Próxima frente recomendada: auditar e reduzir o vocabulário `Bridge` ainda presente em `ActivityResetIntentStateProfilePolicy`/profile sources, sem alterar comportamento funcional.
