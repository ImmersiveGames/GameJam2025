# RESET-ARCH-4B1 — Actor Attribute Lifecycle Cleanup Reset

Status: Applied / pending compile + smoke.

## Objetivo

Adicionar o primeiro reset real de `ActorAttribute` sem criar um rail paralelo e sem inserir atributo no `ActivityEntryParticipantResetStage` antes do setup.

O reset de atributo deste corte acontece no cleanup de teardown:

```text
ActivityExitActorTeardownStage
-> ActorAttributeEndpoint.TryResetToInitialForLifecycleCleanup(...)
-> ActorAttributeEndpoint.TryRelease(...)
```

## Decisão

`ActorAttribute` não entra ainda como `IActorResetEndpoint` do participant reset.

Motivo:

```text
ActivityEntryParticipantResetStage roda antes de ActivityEntryActorAttributeStage.
```

Se `ActorAttributeEndpoint` fosse descoberto como reset endpoint de entrada agora, o reset ocorreria antes da criação dos estados de atributo.

## Alteração aplicada

Criado um reset de cleanup explícito para atributos:

```text
ActivityResetIntent.LifecycleCleanupReset
-> ActivityResetStateProfileKind.InitialState
```

O `ActorAttributeEndpoint` ganhou:

```text
TryResetToInitialForLifecycleCleanup(...)
```

Esse método:

```text
- exige intent LifecycleCleanupReset;
- exige profile InitialState;
- valida identity da activity;
- reseta todos os atributos runtime criados para InitialValue;
- retorna ActorAttributeResetResult;
- não executa release;
```

O release continua sendo responsabilidade do teardown após o cleanup reset.

## Logs esperados

```text
ActorAttributeCleanupResetApplied
resetIntent='LifecycleCleanupReset'
resetStateProfile='InitialState'
resetProfileSource='lifecycle_cleanup_initial_state'
resetAttributeCount='...'
```

Quando não houver atributos ativos:

```text
ActorAttributeReleaseSkipped
reason='no_active_attribute_capability'
```

## O que este corte não faz

```text
- Não migra QA attribute commands.
- Não cria target groups.
- Não cria ActorResetGroup.Attribute.
- Não muda ordem do pipeline.
- Não move ActorAttribute para ActivityEntryParticipantResetStage.
- Não define receitas runtime de dano/vida para RuntimeLocalReset.
```

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
ActorAttributeCleanupResetApplied aparece antes de ActorAttributeReleased
```
