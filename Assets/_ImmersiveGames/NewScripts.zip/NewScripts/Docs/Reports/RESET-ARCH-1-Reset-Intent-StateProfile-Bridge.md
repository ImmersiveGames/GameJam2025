# RESET-ARCH-1 — Reset Intent + State Profile Bridge

Status: Applied / pending compile + smoke

## Objetivo

Introduzir o eixo canonico `ActivityResetIntent` + `ActivityResetStateProfileKind` sem remover ainda os `ResetGroup` tecnicos. Este corte e uma ponte arquitetural para migrar o reset de `boundary + capability groups` para `intent + state profile + target selector futuro`.

## Decisoes aplicadas

- `ActivityResetIntent` passa a identificar a intencao do reset.
- `ActivityResetStateProfileKind` passa a identificar a receita/perfil de estado esperado.
- `ActivityResetScopePlan` agora carrega `ResetIntent` e `StateProfileKind`.
- `ActivityEntryCommand` agora carrega o intent resolvido pela pipeline.
- `EntryInitialize` representa cleanup inicial usando o proprio sistema de reset.
- `RuntimeLocalReset` representa QA/reset local runtime.
- `RuntimeActivityReset` representa restart/reset da activity atual.
- `RuntimeActivityTransitionReset` representa transicao entre activities.
- `ResetGroup` permanece temporario como detalhe tecnico de execucao e observabilidade secundaria.

## Mapeamento inicial

| Fluxo | Intent | State profile | Boundary legado |
|---|---|---|---|
| Entrada inicial por handoff | `EntryInitialize` | `InitialState` | `Activity` |
| Start local da pipeline | `EntryInitialize` | `InitialState` | `Activity` |
| Restart current activity | `RuntimeActivityReset` | `RuntimeActivityState` | `Activity` |
| QA actor/object reset | `RuntimeLocalReset` | `RuntimeLocalState` | `Local` |
| activity_01 -> activity_02 | `RuntimeActivityTransitionReset` | `RuntimeActivityTransitionState` | `ActivityTransition` |

## Interfaces adicionadas

Foram adicionadas interfaces especificas por intent herdando da interface base comum de reset. O scanner continua enxergando a interface base; o adapter pode despachar para interface especifica quando existir e manter fallback temporario para `ApplyReset(...)`.

Actor:

- `IActorEntryInitializeResetEndpoint`
- `IActorRuntimeLocalResetEndpoint`
- `IActorRuntimeActivityResetEndpoint`
- `IActorRuntimeActivityTransitionResetEndpoint`
- `IActorRuntimeRouteTransitionResetEndpoint`

Activity object:

- `IActivityObjectEntryInitializeResetEndpoint`
- `IActivityObjectRuntimeLocalResetEndpoint`
- `IActivityObjectRuntimeActivityResetEndpoint`
- `IActivityObjectRuntimeActivityTransitionResetEndpoint`
- `IActivityObjectRuntimeRouteTransitionResetEndpoint`

## Fora do corte

- Remover `ActorResetGroup` / `ActivityStateResetGroup`.
- Criar assets de `StateProfile`.
- Criar `ResetTargetGroup`.
- Alterar comportamento real de placement, health/lives ou snapshot.
- Trocar todos endpoints para handlers especificos.

## Smoke esperado

O log deve mostrar:

- `resetIntent='EntryInitialize'` na primeira entrada da activity.
- `resetIntent='RuntimeActivityReset'` no restart.
- `resetIntent='RuntimeLocalReset'` no QA actor/object reset.
- `resetIntent='RuntimeActivityTransitionReset'` na entrada de `activity_02` por auto-continue.
- `resetStateProfile='InitialState'`, `RuntimeLocalState`, `RuntimeActivityState` ou `RuntimeActivityTransitionState` conforme o fluxo.
- Sem `FATAL`, `Exception`, `route_transition_failed`, `checkpointStatus='Failed'`, foreign/stale indevido.

## Observacao

Este corte nao fecha a migracao arquitetural. Ele torna o intent visivel e passavel pelo plano/command/adapter, permitindo que os proximos cortes substituam os groups tecnicos por handlers/receitas reais sem quebrar o inventory atual.
