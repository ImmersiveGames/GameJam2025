# RESET-ARCH-6F — Actor Reset Contribution SupportedGroups Removal

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActorResetGroup` e `SupportedGroups` do contrato ativo de actor reset.

## Perguntas obrigatórias

- Pipeline dono da decisão: `SessionActivityPipeline` / `ActivityEntryPipeline`, via `ActivityEntryParticipantResetStage` e `ActivityResetBoundaryPolicy`.
- Tipo: contrato + adapter + inventory scanner + endpoint marker.
- Comportamento final ou bridge: remoção de bridge técnica. `IActorPlacementResetEndpoint` fica como endpoint marker explícito para contexto de placement.
- Compatibilidade necessária: não. Nada em `NewScripts` é produção.
- Erro de sintoma ou fronteira: fronteira arquitetural; `ActorResetGroup` ainda vazava como fonte de metadata.
- Owner duplicado: reduzido; reset segue por intent/profile + endpoint inventory.

## Alterações

- Removido `ActorResetGroup` do código ativo.
- Removido `IActorResetContribution.SupportedGroups`.
- Removido `ActorCapabilityResetEndpointReference.SupportedGroups`.
- Removido metadata `supportedResetGroup[*]` do scanner de actor lifecycle.
- `ActivityResetBoundaryPolicy` filtra actor reset apenas por `ResetBoundaryEligibility`.
- `ActorResetAdapter` não resolve mais grupo técnico.
- `PlayerActor` implementa `IActorPlacementResetEndpoint`; a validação de placement usa esse marker, não `ActorResetGroup.Placement`.
- Contributions concretas validam `Descriptor.IsValid`, sem depender de grupos.

## Arquivos alterados

```text
NewScripts/Actors/Capabilities/Contracts/ActorCapabilityContributionContracts.cs
NewScripts/Actors/Capabilities/Reset/ActorResetContracts.cs
NewScripts/Actors/Capabilities/Reset/ActorResetAdapter.cs
NewScripts/Actors/Players/Runtime/PlayerActorParticipationState.cs
NewScripts/Actors/Projectile/Runtime/ActorProjectileSpawnRuntimeTracker.cs
NewScripts/GameplayRuntime/Authoring/Actors/Player/Movement/PlayerMovementController.cs
NewScripts/GameplayRuntime/Authoring/Actors/Player/PlayerActor.cs
NewScripts/SessionActivity/Capabilities/Inventory/ActivityCapabilityActorLifecycleScanner.cs
NewScripts/SessionActivity/Pipeline/Policies/ActivityResetBoundaryPolicy.cs
NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
NewScripts/Docs/Reports/RESET-ARCH-6F-Actor-Reset-Contribution-SupportedGroups-Removal.md
```

## Verificação estática

```text
ActorResetGroup = 0 em código ativo
SupportedGroups = 0 em código ativo
supportedResetGroup = 0 em código ativo
technicalResetGroup = 0 em código ativo
technicalResetGroups = 0 em código ativo
legacy_capability_group = 0 em código ativo
IActorPlacementResetEndpoint = presente
brace_balance = 0 nos arquivos C# alterados
```

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem error CS
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActorResetAdapter com:
resetDescriptor='endpoint_inventory'
descriptorMode='endpoint_inventory'
executionMode='intent_handler_per_reference'

ActorResetAdapter sem:
ActorResetGroup
SupportedGroups
supportedResetGroup
technicalResetGroup
technicalResetGroups
technicalGroupMode='legacy_capability_group_metadata_only'

ActivityParticipantResetAppliedFromInventory com:
resetDescriptor='endpoint_inventory'
descriptorMode='endpoint_inventory'

IActorResetEndpoint.ApplyReset = 0
IActorResetEndpoint.Supports = 0
actor_reset_intent_handler_missing = 0
required_reset_reference_failed = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
