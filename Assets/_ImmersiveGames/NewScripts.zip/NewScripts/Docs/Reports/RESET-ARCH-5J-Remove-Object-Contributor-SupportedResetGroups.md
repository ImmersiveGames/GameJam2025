# RESET-ARCH-5J — Remove Object Contributor SupportedResetGroups

Status: Applied / pending compile + smoke.

## Objetivo

Remover `supportedResetGroups` do authoring/report de object reset, porque o grupo técnico já não decide execução, requiredness, support ou gate de inventory.

## Owner

- `SessionActivityPipeline`: macro lifecycle e QA.
- `ActivityEntryPipeline`: ordem e resolução de `ActivityResetScopePlan`.
- `ActivityEntryObjectSetupStages` / `ActivityResetStage`: execução de object reset por report elegível e endpoint inventory.
- `ActivityObjectDefaultResetEndpoint`: aplica handler de intent/profile.

## Alterações

```text
ActivityObjectContributor.supportedResetGroups removido.
ActivityObjectContributionReport.SupportedResetGroups removido.
ActivityObjectCapabilityScanner deixou de publicar supportedResetGroup[*].
ActivityObjectResetCommand renomeou TechnicalResetGroupMetadata para ResetDescriptorMetadata.
Object reset logs/facts/checkpoint usam resetDescriptor/resetDescriptors.
```

## Shape esperado

```text
ActivityObjectContributor
-> targetId / roleId / contributorKind / requiredness / resetBoundaryEligibility / releaseKinds

ActivityObjectContributionReport
-> target + requiredness + boundary eligibility + releaseKinds

ActivityObjectResetCommand
-> resetIntent + resetStateProfile + resetDescriptorMetadata

Execution
-> endpoint inventory + intent handler
```

## Fora do corte

```text
Não remove StateResetRequirement.ResetGroups.
Não remove ActorResetGroup.
Não implementa receita material real de transform/object state.
Não muda política de boundary/eligibility.
```

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActivityObjectStateProfileApplied
resetHandler='IActivityObjectEntryInitializeResetEndpoint'
resetHandler='IActivityObjectRuntimeLocalResetEndpoint'

IActivityObjectResetEndpoint.ApplyReset = 0
object_reset_intent_handler_missing = 0
required_reset_inventory_missing_or_invalid = 0
required_reset_endpoint_missing = 0
reset_endpoint_missing = 0

resetDescriptor='endpoint_inventory'
resetDescriptors='endpoint_inventory'
descriptorMode='endpoint_inventory'

technicalResetGroup = 0 em object reset
technicalResetGroups = 0 em ActivityObjectReset checkpoint
legacy_activity_state_reset_group_metadata_only = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
