# RESET-ARCH-5J-H2 — Actor Inventory Utility Qualification Compile Fix

## Status

Applied / pending compile.

## Objetivo

Corrigir o erro de compilação residual do corte `RESET-ARCH-5J-H1` sem alterar a arquitetura do reset.

## Problema

`ActivityEntryActorInventoryStage` chamava `BuildIdentityFromCommandIdentity(...)` sem qualificação local. Depois da restauração de `ActivityEntryObjectSetupStageUtility`, alguns ambientes não resolviam o helper por static import, gerando `CS0103`.

## Correção

As chamadas foram qualificadas explicitamente:

```csharp
ActivityEntryObjectSetupStageUtility.BuildIdentityFromCommandIdentity(...)
```

## Arquivos alterados

- `NewScripts/SessionActivity/Pipeline/Stages/ActivityEntryActorInventoryStage.cs`

## Critério de validação

Compile deve remover os erros:

- `BuildIdentityFromCommandIdentity` em `ActivityEntryActorInventoryStage.cs`.

Depois do compile, manter o smoke do `RESET-ARCH-5J`.
