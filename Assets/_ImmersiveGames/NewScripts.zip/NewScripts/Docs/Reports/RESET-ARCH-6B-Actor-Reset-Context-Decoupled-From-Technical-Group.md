# RESET-ARCH-6B — Actor Reset Context Decoupled From Technical Group

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActorResetGroup` do `ActorResetContext` para impedir que endpoint concreto valide execução por grupo técnico. A execução canônica já é `resetIntent + resetStateProfile + handler explícito`.

## Arquivos alterados

```text
NewScripts/Actors/Capabilities/Reset/ActorResetContracts.cs
NewScripts/Actors/Capabilities/Reset/ActorResetAdapter.cs
NewScripts/Actors/Players/Runtime/PlayerActorParticipationState.cs
NewScripts/Actors/Projectile/Runtime/ActorProjectileSpawnRuntimeTracker.cs
NewScripts/GameplayRuntime/Authoring/Actors/Player/Movement/PlayerMovementController.cs
NewScripts/GameplayRuntime/Authoring/Actors/Player/PlayerActor.cs
NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
```

## Mudanças

- Removido `ActorResetContext.Group`.
- Removido parâmetro `ActorResetGroup group` do construtor de `ActorResetContext`.
- Removida validação de `Group != ActorResetGroup.Unknown` em `ActorResetContext.IsValid`.
- Removidos guards `context.Group != ...` dos endpoints concretos:
  - `PlayerActorParticipationState`;
  - `ActorProjectileSpawnRuntimeTracker`;
  - `PlayerMovementController`;
  - `PlayerActor`.
- `ActorResetAdapter` não envia mais grupo técnico para o contexto.
- `actor_reset_intent_handler_missing` não referencia mais `context.Group`.

## Fora do corte

- `ActorResetGroup` ainda não foi removido.
- `ActorCapabilityResetEndpointReference.SupportedGroups` ainda existe como metadado técnico transitório.
- `ActorResetResult.AppliedGroups/SkippedGroups` ainda existe para observabilidade/QA transitória.
- `IActorResetContribution.SupportedGroups` ainda existe.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem error CS
sem checkpointStatus='Failed'
sem foreign/stale indevido

resetHandler='IActorEntryInitializeResetEndpoint'
resetHandler='IActorRuntimeLocalResetEndpoint'
IActorResetEndpoint.ApplyReset = 0
IActorResetEndpoint.Supports = 0
actor_reset_intent_handler_missing = 0
context.Group = 0 no código ativo

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
