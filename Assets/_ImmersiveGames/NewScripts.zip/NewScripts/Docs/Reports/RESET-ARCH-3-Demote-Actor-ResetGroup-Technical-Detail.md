# RESET-ARCH-3 — Demote Actor ResetGroup to Technical Detail

Status: Applied / pending compile + smoke

## Objetivo

Rebaixar `ActorResetGroup` de eixo principal de observabilidade para detalhe técnico transitório, sem alterar comportamento runtime.

O corte preserva o executor atual e mantém `ActorResetGroup` no resultado interno porque ele ainda sustenta validações técnicas e compatibilidade com o scanner/inventory durante a migração para `ActivityResetIntent + ActivityResetStateProfile`.

## Decisões aplicadas

- `resetIntent`, `resetStateProfile` e `resetHandler` passam a ser os campos principais dos logs de actor reset.
- `ActorResetGroup` não é removido neste corte.
- `ActorResetGroup` passa a aparecer em logs como campo técnico: `technicalResetGroup`, `technicalResetGroups` ou `technicalGroupMode='legacy_capability_group'`.
- Contadores de groups passam a ser emitidos como `technicalAppliedGroupCount` e `technicalSkippedGroupCount` nos logs de actor reset/QA.
- O fallback por `IActorResetEndpoint.ApplyReset` permanece existente, mas não deve ser usado pelos actor endpoints principais já migrados no `RESET-ARCH-2`.

## Arquivos alterados

```text
Actors/Capabilities/Reset/ActorResetAdapter.cs
SessionActivity/Pipeline/Stages/ActivityEntryParticipantResetStage.cs
SessionActivity/Pipeline/SessionActivityPipeline.cs
Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
Docs/Reports/RESET-ARCH-3-Demote-Actor-ResetGroup-Technical-Detail.md
Docs/Reports/RESET-ARCH-3-Demote-Actor-ResetGroup-Technical-Detail.md.meta
```

## Fora do corte

- Remover `ActorResetGroup` do contrato.
- Remover `ActivityStateResetGroup` de object reset.
- Alterar receitas reais de estado.
- Criar target groups.
- Migrar object reset para handlers por intent.
- Remover fallback genérico do adapter.

## Smoke esperado

O smoke deve preservar:

```text
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
ActivityObjectReset activity_01 = PassedApplied
ActivityObjectReset activity_02 = PassedNoCommands
```

Os logs principais de actor reset devem mostrar:

```text
resetIntent='EntryInitialize'
resetStateProfile='InitialState'
resetHandler='IActorEntryInitializeResetEndpoint'
technicalResetGroup='Placement'
technicalGroupMode='legacy_capability_group'
```

Não deve reaparecer como campo principal de actor reset:

```text
resetGroups=
supportedGroups=
appliedGroups=
skippedGroups=
group=
```

Exceção permitida: mensagens internas de erro técnico ainda podem mencionar `required_reset_group_failed`, porque a validação antiga ainda não foi removida.

## Critério de aceite

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
handlers específicos preservados
sem fallback genérico para actor endpoints principais
ActorResetGroup aparece apenas como detalhe técnico nos logs de actor reset
ResetGroup não volta a ser eixo principal de policy/observabilidade
```
