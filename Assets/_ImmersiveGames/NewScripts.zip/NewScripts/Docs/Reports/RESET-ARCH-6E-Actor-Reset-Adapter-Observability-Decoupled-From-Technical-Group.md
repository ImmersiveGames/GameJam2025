# RESET-ARCH-6E — Actor Reset Adapter Observability Decoupled From Technical Group

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActorResetGroup` da superfície de observabilidade do `ActorResetAdapter` e do QA de actor reset.

Depois do `RESET-ARCH-6D`, o stage/command já observa actor reset por:

```text
resetDescriptor='endpoint_inventory'
descriptorMode='endpoint_inventory'
appliedReferenceCount
skippedReferenceCount
```

O adapter ainda emitia:

```text
technicalResetGroup
technicalResetGroups
technicalGroupMode='legacy_capability_group_metadata_only'
```

Esse shape mantinha o grupo técnico como eixo visível de execução, mesmo depois de command/stage/result deixarem de depender dele.

## Alteração

### `ActorResetAdapter`

Antes:

```text
ActorResetInventoryReferencesResolved
-> technicalResetGroups
-> technicalGroupMode='legacy_capability_group_metadata_only'

ActorResetEndpointAppliedFromInventory
-> technicalResetGroup
-> technicalResetGroups
-> technicalGroupMode='legacy_capability_group_metadata_only'
```

Agora:

```text
ActorResetInventoryReferencesResolved
-> resetDescriptor='endpoint_inventory'
-> descriptorMode='endpoint_inventory'
-> runtimeBoundaryEligibility
-> executionMode='intent_handler_per_reference'

ActorResetEndpointAppliedFromInventory
-> resetDescriptor='endpoint_inventory'
-> descriptorMode='endpoint_inventory'
-> resetHandler
-> executionMode='intent_handler_per_reference'
```

### `SessionActivityPipeline` QA actor reset

Antes:

```text
ActorResetQaAppliedFromInventory
-> technicalGroupMode='legacy_capability_group_metadata_only'
```

Agora:

```text
ActorResetQaAppliedFromInventory
-> resetDescriptor='endpoint_inventory'
-> descriptorMode='endpoint_inventory'
```

## Não alterado

Este corte não remove ainda:

```text
ActorResetGroup
IActorResetContribution.SupportedGroups
ActorCapabilityResetEndpointReference.SupportedGroups
branch interno de placement no ActorResetAdapter
```

Esses pontos seguem como débito técnico transitório da frente de actor reset.

## Critério de smoke

```text
sem FATAL
sem Exception
sem route_transition_failed
sem error CS
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActorResetAdapter com:
resetDescriptor='endpoint_inventory'
descriptorMode='endpoint_inventory'
executionMode='intent_handler_per_reference'

ActorResetAdapter sem:
technicalResetGroup
technicalResetGroups
technicalGroupMode='legacy_capability_group_metadata_only'

ActivityParticipantResetAppliedFromInventory com:
resetDescriptor='endpoint_inventory'
descriptorMode='endpoint_inventory'

IActorResetEndpoint.ApplyReset = 0
IActorResetEndpoint.Supports = 0
actor_reset_intent_handler_missing = 0
required_reset_reference_failed = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
