# RESET-ARCH-5I — Required Object Reset Contributor Decoupled From Technical Group

Status: Applied / pending compile + smoke.

## Objetivo

Remover a dependência residual de `ActivityStateResetGroup` no predicado usado pelo QA/object reset para decidir se há contributor required na entry corrente.

## Perguntas obrigatórias

- Owner da decisão: `SessionActivityPipeline` continua validando o ciclo ativo e chamando o `ActivityResetStage`; `ActivityResetStage` decide falha/skip de inventory e endpoint conforme command/context.
- Tipo: predicado de stage/pipeline para validação de inventory; não é endpoint, adapter ou authoring data.
- Comportamento final ou bridge: avanço para comportamento final; `SupportedResetGroups` continua bridge apenas como metadado técnico.
- Compat necessária: não. O gate por `SupportedResetGroups.Count > 0` era compat transitória e foi removido.
- Sintoma ou fronteira: fronteira. O erro era deixar `ActivityStateResetGroup` influenciar requiredness/inventory.
- Owner duplicado: não. Requiredness fica no report; endpoint material fica no inventory; execução fica no handler de intent.

## Alteração

Antes:

```text
Required contributor só exigia inventory válido se SupportedResetGroups.Count > 0.
```

Agora:

```text
Required contributor exige inventory válido por Requiredness.
ActivityStateResetGroup não participa da decisão.
```

## Arquivos alterados

```text
NewScripts/SessionActivity/Pipeline/SessionActivityPipeline.cs
NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
NewScripts/Docs/Reports/RESET-ARCH-5I-Required-Object-Reset-Contributor-Decoupled-From-Technical-Group.md
```

## Critério de smoke

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActivityObjectStateProfileApplied
resetHandler='IActivityObjectEntryInitializeResetEndpoint'
resetHandler='IActivityObjectRuntimeLocalResetEndpoint'

IActivityObjectResetEndpoint.ApplyReset = 0
object_reset_intent_handler_missing = 0
required_reset_inventory_missing_or_invalid = 0
required_reset_endpoint_missing = 0
reset_endpoint_missing = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
