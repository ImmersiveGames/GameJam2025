# RESET-ARCH-5K — Remove StateResetRequirement ResetGroups

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActivityStateResetGroup` do authoring e do contrato de `StateResetRequirement`, porque object reset já não usa grupos técnicos como gate, descriptor, command ou eixo de execução.

## Alterações

- `ActivityStateResetGroup` removido de `ActivitySetupInventoryContracts.cs`.
- `StateResetRequirement` agora carrega apenas `Requirement` e `TargetId`.
- `ActivityStateResetRequirementAuthoring` não expõe nem valida `resetGroups`.
- `ActivitySetupInventoryBuilder` constrói `StateResetRequirement` sem `ResetGroups`.

## Decisão de ownership

- Pipeline/stage continua dono de ordem e lifecycle.
- `ActivityResetBoundaryPolicy` continua dona de intent/profile/scope.
- Endpoint inventory continua fonte técnica para resolver handler.
- Authoring data não decide grupo técnico de reset.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActivityObjectStateProfileApplied
resetDescriptor='endpoint_inventory'
descriptorMode='endpoint_inventory'

ActivityStateResetGroup = 0 no código ativo
StateResetRequirement.ResetGroups = 0 no código ativo

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
