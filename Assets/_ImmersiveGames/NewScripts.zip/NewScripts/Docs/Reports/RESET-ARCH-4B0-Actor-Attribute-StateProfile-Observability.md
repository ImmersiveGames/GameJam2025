# RESET-ARCH-4B0 — Actor Attribute StateProfile Observability

Status: Applied / pending compile + smoke.

## Objetivo

Auditar o caminho atual de `ActorAttribute` antes de criar qualquer reset endpoint novo e tornar visível nos logs qual `ActivityResetIntent` / `ActivityResetStateProfileKind` está dirigindo o setup de atributos na entry.

Este corte é deliberadamente de observabilidade e fronteira. Não altera valor de atributo, não cria novo reset group e não adiciona endpoint de reset para atributos.

## Diagnóstico

`ActorAttribute` ainda não participa do rail canônico de actor reset.

Hoje o fluxo é:

```text
ActivityEntryActorAttributeStage
-> ActorAttributeEndpoint.TryInitialize(...)
-> ActorAttributeState criado a partir de ActorAttributeProfileAsset
```

Na saída/restart:

```text
ActivityExitActorTeardownStage
-> ActorAttributeEndpoint.TryRelease(...)
```

QA de atributo ainda usa comandos diretos:

```text
QaSubtractActorAttribute
QaAddActorAttribute
QaSetActorAttribute
QaResetActorAttributeToInitial
QaRestoreActorAttributeToMax
```

Esses comandos são úteis para QA, mas ainda são um rail paralelo ao reset por intent/profile. Devem ser migrados ou reclassificados antes do fechamento final do ADR-0006.

## Decisão deste corte

Não criar `IActorResetContributionProvider` em `ActorAttributeEndpoint` ainda.

Motivo:

```text
ActivityEntryParticipantResetStage roda antes de ActivityEntryActorAttributeStage.
```

Se `ActorAttributeEndpoint` entrasse agora como reset endpoint, `EntryInitialize` e `RuntimeActivityReset` chamariam o endpoint antes do setup de atributos. Isso geraria skip/falso applied ou exigiria mudar a ordem do pipeline sem auditoria própria.

## Alteração aplicada

`ActivityEntryActorAttributeSetupCommand` agora carrega:

```text
resetIntent
resetStateProfile
```

A origem vem do `ActivityResetScopePlan` já resolvido no `ActivityEntryPipeline`.

Logs de `ActivityEntryActorAttributeStage` passam a incluir:

```text
resetIntent='...'
resetStateProfile='...'
stateProfileSource='attribute_setup_lifecycle_bridge'
```

Eventos cobertos:

```text
ActorAttributeSetupStarted
ActorAttributeProfileResolved
ActorAttributeReady
ActorAttributeSetupCompleted
```

## O que este corte prova

Este corte prova que o lifecycle de atributo já pode ser observado sob o novo eixo de reset:

```text
EntryInitialize -> InitialState
RuntimeActivityReset -> RuntimeActivityState
RuntimeActivityTransitionReset -> RuntimeActivityTransitionState
```

Mas ainda não transforma atributo em reset endpoint real.

## O que este corte não faz

```text
- Não altera valores de vida/atributo.
- Não cria ActorResetGroup.Attribute.
- Não adiciona ActorAttributeEndpoint ao inventory de reset.
- Não remove QA attribute commands.
- Não muda ordem do pipeline.
- Não cria target groups.
```

## Próxima ação recomendada

`RESET-ARCH-4B1 — Actor Attribute RuntimeLocal Reset Routing`

Escopo sugerido:

```text
- decidir se RuntimeLocalReset de atributo deve usar reset endpoint por intent ou comando canônico reaproveitado;
- remover/alinhar QA attribute reset direto para passar por reset intent/profile;
- evitar adicionar ActorResetGroup novo;
- não mover setup/release sem corte próprio.
```

## Smoke esperado

Procurar:

```text
ActorAttributeSetupStarted resetIntent='EntryInitialize' resetStateProfile='InitialState'
ActorAttributeReady resetIntent='EntryInitialize' resetStateProfile='InitialState'
ActorAttributeSetupStarted resetIntent='RuntimeActivityReset' resetStateProfile='RuntimeActivityState'
ActorAttributeReady resetIntent='RuntimeActivityReset' resetStateProfile='RuntimeActivityState'
```

Critério geral:

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
