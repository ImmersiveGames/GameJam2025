# RESET-ARCH-6A — Actor ResetEndpoint Supports Removal

Status: Applied / pending compile + smoke.

## Objetivo

Remover `Supports(ActorResetGroup)` de `IActorResetEndpoint` e dos endpoints concretos, porque o suporte por grupo não é mais gate de execução desde `RESET-ARCH-5E`.

## Alterações

- `IActorResetEndpoint` virou interface base/marcador de discovery.
- Removidas implementações `Supports(ActorResetGroup)` de:
  - `PlayerActor`;
  - `PlayerMovementController`;
  - `PlayerActorParticipationState`;
  - `ActorProjectileSpawnRuntimeTracker`.

## Decisão de ownership

- `ActivityResetBoundaryPolicy` decide intent/profile/scope.
- `ActivityEntryParticipantResetStage` resolve referências elegíveis do inventory.
- `ActorResetAdapter` despacha por handler explícito de intent/profile.
- Endpoint não decide se um grupo técnico é executável.

## Fora do corte

`ActorResetGroup` ainda existe como metadado técnico transitório em contribution/reference/context/result. A remoção desse metadado fica para cortes posteriores.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

resetHandler='IActorEntryInitializeResetEndpoint'
resetHandler='IActorRuntimeLocalResetEndpoint'
IActorResetEndpoint.ApplyReset = 0
IActorResetEndpoint.Supports = 0
actor_reset_intent_handler_missing = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
