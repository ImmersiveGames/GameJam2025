# RESET-ARCH-4D — Actor SpawnedRuntimeObjects StateProfile Split

Status: Applied / pending compile + smoke.

## Objetivo

Migrar o reset de `SpawnedRuntimeObjects` do `ActorProjectileSpawnRuntimeTracker` para receita explícita por `ActivityResetIntent` + `ActivityResetStateProfileKind`, sem remover ainda `ActorResetGroup`.

## Owner

- `SessionActivityPipeline` classifica QA/lifecycle macro.
- `ActivityEntryPipeline` resolve o `ActivityResetScopePlan`.
- `ActivityEntryParticipantResetStage` executa participant reset na ordem canônica.
- `ActorResetAdapter` despacha o handler por intent.
- `ActorProjectileSpawnRuntimeTracker` aplica somente a receita de retorno/prune dos objetos spawnados.

## Alteração

`ActorProjectileSpawnRuntimeTracker` agora aplica `ApplySpawnedRuntimeObjectsStateProfile(...)` para:

```text
EntryInitialize -> InitialState
RuntimeLocalReset -> RuntimeLocalState
RuntimeActivityReset -> RuntimeActivityState
RuntimeActivityTransitionReset -> RuntimeActivityTransitionState
RuntimeRouteTransitionReset -> RuntimeRouteTransitionState
```

A receita atual é comum e intencionalmente limitada:

```text
- podar tracked spawns obsoletos;
- retornar runtime spawned objects rastreados ao pool canônico;
- limpar tracking local após a tentativa de retorno;
- não decidir lifecycle/policy;
- não criar trilho paralelo de pooling.
```

## Observabilidade esperada

```text
ActorProjectileSpawnedRuntimeObjectsStateProfileApplied
resetIntent='RuntimeLocalReset'
resetStateProfile='RuntimeLocalState'
runtimeObjectsProfileKind='RuntimeLocalState'
runtimeObjectsProfileSource='runtime_local_spawned_runtime_objects_return'
returnedCount='...'
```

Quando não houver objetos rastreados:

```text
ActorProjectileSpawnedRuntimeObjectsStateProfileSkipped
reason='no_tracked_runtime_objects'
```

## Fora do corte

- Remover `ActorResetGroup`.
- Migrar object reset.
- Migrar QA attribute commands.
- Criar target groups.
- Alterar pooling canônico.

## Critério de smoke

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
resetHandler='IActorResetEndpoint.ApplyReset' = 0
```
