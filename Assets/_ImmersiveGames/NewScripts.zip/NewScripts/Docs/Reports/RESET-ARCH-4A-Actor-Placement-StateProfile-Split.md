# RESET-ARCH-4A — Actor Placement StateProfile Split

Status: Applied / pending compile + smoke.

## Objetivo

Separar o comportamento real de `Placement` do `PlayerActor` por `ActivityResetStateProfileKind`, sem migrar ainda movement, projectile, participation ou object reset.

## Decisão aplicada

`PlayerActor` continua sendo descoberto pelo scanner via reset endpoint comum, mas o handler de placement passa a interpretar o intent/profile:

```text
EntryInitialize -> aplica command context e congela InitialState placement profile.
RuntimeActivityReset -> aplica command context quando disponível e congela RuntimeActivityState placement profile; se faltar, reutiliza profile congelado.
RuntimeLocalReset -> não usa mais posição atual como falso reset; reutiliza InitialState placement profile congelado.
RuntimeActivityTransitionReset -> não reposiciona PlayerActor neste corte.
RuntimeRouteTransitionReset -> não reposiciona PlayerActor neste corte.
```

## Arquivos alterados

```text
NewScripts/Actors/Capabilities/Reset/ActorResetContracts.cs
NewScripts/Actors/Capabilities/Reset/ActorResetAdapter.cs
NewScripts/GameplayRuntime/Authoring/Actors/Player/PlayerActor.cs
NewScripts/Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md
NewScripts/Docs/Reports/RESET-ARCH-4A-Actor-Placement-StateProfile-Split.md
```

## Observabilidade esperada

Novo log do `PlayerActor`:

```text
PlayerActorPlacementStateProfileApplied
PlayerActorPlacementStateProfileSkipped
placementProfileKind='InitialState'
placementProfileKind='RuntimeLocalState'
placementProfileKind='RuntimeActivityState'
placementProfileKind='RuntimeActivityTransitionState'
placementProfileSource='InitialState'
placementProfileSource='command_context'
placementProfileSource='transition_profile_no_placement'
```

## Critério de smoke

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
resetHandler='IActorResetEndpoint.ApplyReset' = 0 para actor endpoints principais
RuntimeLocalReset usa PlayerActorPlacementStateProfileApplied com placementProfileSource='InitialState'
RuntimeActivityTransitionReset usa PlayerActorPlacementStateProfileSkipped com reason='runtime_activity_transition_does_not_apply_player_placement'
```

## Fora do escopo

```text
Não remover ActorResetGroup.
Não migrar object reset.
Não criar asset de reset recipe.
Não criar target groups.
Não alterar movement/projectile/participation.
```
