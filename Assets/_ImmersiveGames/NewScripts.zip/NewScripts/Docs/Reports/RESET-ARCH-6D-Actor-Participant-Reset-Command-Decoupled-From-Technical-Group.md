# RESET-ARCH-6D — Actor Participant Reset Command Decoupled From Technical Group

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActorResetGroup` da superfície de command/stage do participant actor reset.

## Classificação arquitetural

- Pipeline dono da decisão: `ActivityEntryPipeline`, via `ActivityEntryParticipantResetStage`.
- Tipo: command + stage observability.
- Comportamento: remoção de bridge transitória.
- Compatibilidade: não necessária; `ActorResetGroup` não deve voltar a ser eixo de sucesso/falha do participant reset.
- Fronteira: o erro estava no command/stage ainda expondo metadado técnico de inventory como decisão de reset.
- Owner duplicado: reduzido; stage passa a observar referência de endpoint, não grupo técnico.

## Alterações

- `ActivityParticipantResetCommand.ResetGroups` removido.
- `ActivityParticipantResetCommand.HasResetGroups` removido.
- `DeriveResetGroups(...)` removido.
- `FormatResetGroups(...)` removido.
- `ToString()` do command passa a expor:
  - `resetDescriptor='endpoint_inventory'`
  - `descriptorMode='endpoint_inventory'`
  - `resetReferenceCount`.
- `ActivityEntryParticipantResetStage` deixa de emitir `technicalResetGroups` no fact/log de applied/skip.
- Stage passa a emitir `resetDescriptor`/`descriptorMode`.

## Mantido

`ActorResetGroup` ainda existe em contribution/reference e na observabilidade baixa do `ActorResetAdapter` como metadado técnico transitório. A remoção final deve ser outro corte.

## Smoke esperado

- sem `FATAL`;
- sem `Exception`;
- sem `route_transition_failed`;
- sem `error CS`;
- sem `checkpointStatus='Failed'`;
- `appliedReferenceCount` presente;
- `skippedReferenceCount` presente;
- `ActivityParticipantResetAppliedFromInventory` com `resetDescriptor='endpoint_inventory'`;
- `ActivityParticipantResetAppliedFromInventory` sem `technicalResetGroups`;
- checkpoints `RestartCurrentActivity`, `Activity01ToActivity02`, `RouteExitBackToMenu` passando.
