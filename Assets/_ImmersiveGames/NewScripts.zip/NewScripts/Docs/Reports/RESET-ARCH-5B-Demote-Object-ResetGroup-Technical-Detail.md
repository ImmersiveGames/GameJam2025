# RESET-ARCH-5B — Demote Object ResetGroup to Technical Detail

Status: Applied / pending compile + smoke.

## Objetivo

Rebaixar `ActivityStateResetGroup` na observabilidade do object reset, alinhando object reset ao shape já aplicado no actor reset.

O eixo principal do reset passa a ser:

```text
resetIntent
resetStateProfile
resetHandler
objectProfileKind
```

`ActivityStateResetGroup` permanece apenas como detalhe técnico transitório:

```text
technicalResetGroup
technicalGroupMode='legacy_activity_state_reset_group'
```

## Owner

- `SessionActivityPipeline` / `ActivityEntryPipeline`: lifecycle, intent, policy e handoff.
- `ActivityResetBoundaryPolicy`: resolução do plano `ActivityResetScopePlan`.
- `ActivityResetStage` e `ActivityEntryObjectSetupStages`: emissão determinística de commands/facts.
- `ActivityObjectDefaultResetEndpoint`: aplicação da receita por intent/profile.

## Alterações

- `ActivityResetStage` passa a emitir `technicalResetGroup` em vez de `resetGroup` nos facts principais.
- `ActivityEntryObjectSetupStages` passa a emitir `technicalResetGroup` em vez de `resetGroup` nos facts principais.
- `ActivityObjectResetCommand.ToString()` passa a expor o group como detalhe técnico.
- `SessionActivityDebugPanel` passa a agregar `technicalResetGroup` e emitir `technicalResetGroups` no checkpoint de object reset.
- Observabilidade de discovery passa a registrar `technicalResetGroups`/`technicalGroupMode`.

## Não feito

- Não remove `ActivityStateResetGroup`.
- Não muda seleção de reset por grupos.
- Não muda receita material do object reset.
- Não altera snapshot/restore.
- Não cria target groups.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido

ActivityObjectStateProfileApplied
technicalResetGroup='TransformState'
technicalGroupMode='legacy_activity_state_reset_group'

ObjectResetCommandIssued / ObjectResetApplied com technicalResetGroup
ActivityObjectReset checkpoint com technicalResetGroups

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
```
