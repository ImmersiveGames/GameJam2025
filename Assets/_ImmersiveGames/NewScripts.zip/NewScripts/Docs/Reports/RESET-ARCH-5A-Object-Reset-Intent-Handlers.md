# RESET-ARCH-5A — Object Reset Intent Handlers

Status: Applied / pending compile + smoke.

## Objetivo

Migrar o endpoint padrão de object reset para handlers explícitos por `ActivityResetIntent`, mantendo `ActivityStateResetGroup` apenas como detalhe técnico transitório.

## Perguntas obrigatórias

- **Qual pipeline é dono desta decisão?** `SessionActivityPipeline` classifica QA/macro lifecycle; `ActivityEntryPipeline` resolve `ActivityResetScopePlan`; `ActivityResetStage`/`ActivityEntryObjectSetupStages` executam object reset; `ActivityObjectDefaultResetEndpoint` só aplica a receita recebida.
- **Isso é stage, policy, command, fact, adapter, endpoint, snapshot ou authoring data?** É endpoint + observabilidade. `resetIntent`/`resetStateProfile` continuam payload de command/policy resolvido.
- **Isso é comportamento final ou bridge transitória?** Bridge transitória. O handler por intent é direção final; o uso de `ActivityStateResetGroup` ainda é legado técnico.
- **Essa compatibilidade ainda é necessária?** Sim, temporariamente, porque object reset ainda depende dos groups para discovery/checkpoints.
- **O erro está no sintoma ou na fronteira arquitetural errada?** Na fronteira antiga: object reset ainda tratava `resetGroup` como eixo principal.
- **Existe owner duplicado para o mesmo lifecycle?** Não. Endpoint não decide quando resetar.

## Alterações

- `ActivityObjectDefaultResetEndpoint` agora implementa:
  - `IActivityObjectEntryInitializeResetEndpoint`
  - `IActivityObjectRuntimeLocalResetEndpoint`
  - `IActivityObjectRuntimeActivityResetEndpoint`
  - `IActivityObjectRuntimeActivityTransitionResetEndpoint`
  - `IActivityObjectRuntimeRouteTransitionResetEndpoint`
- Cada handler valida `resetIntent` + `resetStateProfile` esperados.
- Novo log:

```text
ActivityObjectStateProfileApplied
```

com:

```text
resetIntent
resetStateProfile
objectProfileKind
objectProfileSource
resetHandler
technicalResetGroup
technicalGroupMode='legacy_activity_state_reset_group'
```

## Fora do corte

- Não remover `ActivityStateResetGroup`.
- Não alterar snapshot/restore.
- Não implementar receita real de transform/interaction/objective.
- Não alterar QA rail além de passar pelo handler canônico já existente.

## Smoke esperado

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
resetHandler='IActorResetEndpoint.ApplyReset' = 0

RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed

ActivityObjectStateProfileApplied
resetHandler='IActivityObjectRuntimeLocalResetEndpoint'
objectProfileKind='RuntimeLocalState'
technicalGroupMode='legacy_activity_state_reset_group'
```
