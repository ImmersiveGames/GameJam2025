﻿# Scene Flow Smoke Result
- Timestamp: 2025-12-26T21:19:23.0211438Z
- Defines: NEWSCRIPTS_SCENEFLOW_NATIVE, UNITY_EDITOR, UNITY_INCLUDE_TESTS
- Result: PASS
- RunnerPasses: 1
- RunnerFails: 0
- NativePassMarkerFound: True
- TotalMarkedLogsCaptured: 7

## Logs (até 30 entradas)
- [INFO] [NewScriptsInfraSmokeRunner] [SceneFlowTest][Runner] Iniciando execução exclusiva de Scene Flow (nativo).
- [INFO] [SceneTransitionServiceSmokeQaTester] [SceneFlowTest][Native] Started
- [INFO] [SceneTransitionServiceSmokeQaTester] [SceneFlowTest][Native] Started
- [INFO] [SceneTransitionServiceSmokeQaTester] [SceneFlowTest][Native] ScenesReady
- [INFO] [SceneTransitionServiceSmokeQaTester] [SceneFlowTest][Native] Completed
- [INFO] [SceneTransitionServiceSmokeQaTester] [SceneFlowTest][Native] PASS
- [INFO] [NewScriptsInfraSmokeRunner] [SceneFlowTest][Runner] PASS (Passes=1 Fails=0)
- [SceneFlowTest][Smoke] PASS
