# RESET-ARCH-2 — Actor Reset Intent Handlers

Status: Applied / pending compile + smoke

## Objetivo

Migrar os principais endpoints de actor reset para handlers explícitos por `ActivityResetIntent`, mantendo `ActorResetGroup` como detalhe técnico transitório.

Este corte não altera a receita real de reset. A intenção é retirar o adapter do fallback genérico quando o endpoint já sabe declarar um handler específico por intent.

## Decisões aplicadas

- `ActorResetAdapter` passa a registrar qual handler executou cada reset.
- `PlayerActor` implementa handlers específicos por intent para `Placement`.
- `PlayerMovementController` implementa handlers específicos por intent para `MovementTransient`.
- `ActorProjectileSpawnRuntimeTracker` implementa handlers específicos por intent para `SpawnedRuntimeObjects`.
- `PlayerActorParticipationState` implementa handlers específicos por intent para `ActivityParticipation`.
- `ApplyReset(...)` permanece como fallback transitório e compat técnico interno.
- `ActorResetGroup` permanece temporário para preservar scanner, inventory e smoke.

## Handlers adicionados aos endpoints principais

Cada endpoint principal de actor agora implementa:

- `IActorEntryInitializeResetEndpoint`
- `IActorRuntimeLocalResetEndpoint`
- `IActorRuntimeActivityResetEndpoint`
- `IActorRuntimeActivityTransitionResetEndpoint`
- `IActorRuntimeRouteTransitionResetEndpoint`

No corte atual, cada handler delega para a lógica existente de `ApplyReset(...)`.

## Observabilidade nova

`ActorResetAdapter` passa a emitir:

```text
resetHandler='IActorEntryInitializeResetEndpoint'
resetHandler='IActorRuntimeLocalResetEndpoint'
resetHandler='IActorRuntimeActivityResetEndpoint'
resetHandler='IActorRuntimeActivityTransitionResetEndpoint'
resetHandler='IActorRuntimeRouteTransitionResetEndpoint'
```

Quando algum endpoint ainda não tiver handler específico, o log mostra fallback:

```text
resetHandler='IActorResetEndpoint.ApplyReset'
```

## Fora do corte

- Remover `ActorResetGroup`.
- Alterar comportamento real de placement.
- Criar `ResetStateProfile` autoral.
- Criar target groups.
- Migrar object reset.
- Remover fallback genérico do adapter.

## Smoke esperado

O smoke deve preservar:

```text
RestartCurrentActivity = Passed
Activity01ToActivity02 = Passed
RouteExitBackToMenu = Passed
ActivityObjectReset activity_01 = PassedApplied
ActivityObjectReset activity_02 = PassedNoCommands
```

E deve mostrar handlers específicos nos actor resets:

```text
resetIntent='EntryInitialize' resetHandler='IActorEntryInitializeResetEndpoint'
resetIntent='RuntimeLocalReset' resetHandler='IActorRuntimeLocalResetEndpoint'
resetIntent='RuntimeActivityReset' resetHandler='IActorRuntimeActivityResetEndpoint'
resetIntent='RuntimeActivityTransitionReset' resetHandler='IActorRuntimeActivityTransitionResetEndpoint'
```

Não deve aparecer para os endpoints principais:

```text
resetHandler='IActorResetEndpoint.ApplyReset'
```

## Critério de aceite

```text
sem FATAL
sem Exception
sem route_transition_failed
sem checkpointStatus='Failed'
sem foreign/stale indevido
handlers específicos observados
sem fallback genérico para actor endpoints principais
ResetGroup ainda presente apenas como detalhe técnico transitório
```
