# RESET-ARCH-5F — Object Reset Intent Per Report Execution

Status: Applied / pending compile + smoke.

## Objetivo

Remover `ActivityStateResetGroup` do loop de execução do object reset. O object reset deve executar uma vez por report/contributor elegível e sempre por handler explícito de `ActivityResetIntent`.

## Perguntas obrigatórias

- Owner da decisão: `SessionActivityPipeline` classifica QA/lifecycle, `ActivityEntryPipeline` resolve o `ActivityResetScopePlan`, `ActivityResetStage`/`ActivityEntryObjectSetupStages` ordenam object reset e o endpoint executa side-effect comandado.
- Tipo: stage + observabilidade. `ActivityStateResetGroup` permanece metadado técnico transitório; não é mais multiplicador de execução.
- Comportamento final ou bridge: redução de bridge. O final é reset por `Intent + StateProfile`; o grupo técnico ainda existe para inventory/diagnóstico.
- Compatibilidade necessária: apenas para metadado técnico temporário. Não há fallback genérico nem loop de execução por grupo.
- Sintoma ou fronteira: fronteira. O erro era deixar grupo técnico decidir execução material.
- Owner duplicado: não. O stage ordena; endpoint aplica; policy/intent já vêm resolvidos.

## Alterações

- `ActivityResetStage` executa object reset uma vez por `ActivityObjectContributionReport` elegível.
- `ActivityEntryObjectSetupStages` aplica a mesma regra no caminho de setup.
- O loop interno por `SupportedResetGroups` foi removido.
- `ActivityStateResetGroup` agora é resolvido como metadado técnico primário por report.
- Se um report vier sem grupo técnico, com `Unknown` ou misturando múltiplos grupos técnicos distintos, o stage falha explicitamente.
- `ExecuteObjectResetCommand` deixou de usar `endpoint.Supports(command.ResetGroup)` como gate de execução; o endpoint já é resolvido por target no inventory e o handler de intent é obrigatório.
- Logs passam a expor:
  - `technicalGroupMode='legacy_activity_state_reset_group_metadata_only'`
  - `executionMode='intent_handler_per_report'`

## Falhas explícitas novas

```text
object_reset_report_missing_technical_group
object_reset_report_unknown_technical_group
object_reset_report_mixes_technical_groups
```

## Arquivos alterados

- `SessionActivity/Pipeline/Stages/ActivityResetStage.cs`
- `SessionActivity/Pipeline/Stages/ActivityEntryObjectSetupStages.cs`
- `SessionActivity/Contracts/ActivityObjectResetContracts.cs`
- `SessionActivity/Authoring/ActivityObjectDefaultResetEndpoint.cs`
- `Docs/ADRs/ADR-2.0-0006-ActivityReset-Intent-StateProfile-TargetGroups.md`

## Smoke esperado

- Sem `FATAL`.
- Sem `Exception`.
- Sem `route_transition_failed`.
- Sem `checkpointStatus='Failed'`.
- Sem foreign/stale indevido.
- `ActivityObjectStateProfileApplied` presente.
- `resetHandler='IActivityObjectEntryInitializeResetEndpoint'` presente.
- `resetHandler='IActivityObjectRuntimeLocalResetEndpoint'` presente.
- `IActivityObjectResetEndpoint.ApplyReset = 0`.
- `object_reset_intent_handler_missing = 0`.
- `object_reset_report_mixes_technical_groups = 0`.
- `technicalGroupMode='legacy_activity_state_reset_group_metadata_only'`.
- `executionMode='intent_handler_per_report'`.
- `RestartCurrentActivity = Passed`.
- `Activity01ToActivity02 = Passed`.
- `RouteExitBackToMenu = Passed`.
