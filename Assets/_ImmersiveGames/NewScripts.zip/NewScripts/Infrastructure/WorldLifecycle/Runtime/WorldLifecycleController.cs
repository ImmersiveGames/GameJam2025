using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using _ImmersiveGames.NewScripts.Infrastructure.Actors;
using _ImmersiveGames.NewScripts.Infrastructure.DebugLog;
using _ImmersiveGames.NewScripts.Infrastructure.DI;
using _ImmersiveGames.NewScripts.Infrastructure.Execution.Gate;
using _ImmersiveGames.NewScripts.Infrastructure.WorldLifecycle.Hooks;
using _ImmersiveGames.NewScripts.Infrastructure.WorldLifecycle.Reset;
using _ImmersiveGames.NewScripts.Infrastructure.WorldLifecycle.Spawn;
using UnityEngine;

namespace _ImmersiveGames.NewScripts.Infrastructure.WorldLifecycle.Runtime
{
    [DisallowMultipleComponent]
    public sealed class WorldLifecycleController : MonoBehaviour
    {
        [Header("Lifecycle")]
        [Tooltip("Quando true, o controller executa ResetWorldAsync automaticamente no Start(). " +
                 "Para testes automatizados, um runner deve desligar isto antes do Start().")]
        [SerializeField] private bool autoInitializeOnStart = true;

        [Header("Debug")]
        [SerializeField] private bool verboseLogs = true;

        [Inject] private ISimulationGateService _gateService;
        [Inject] private IWorldSpawnServiceRegistry _spawnRegistry;
        [Inject] private IActorRegistry _actorRegistry;

        // Guardrail: este controller apenas consome o WorldLifecycleHookRegistry criado no bootstrapper.
        [Inject] private WorldLifecycleHookRegistry _hookRegistry;

        private readonly List<IWorldSpawnService> _spawnServices = new();
        private WorldLifecycleOrchestrator _orchestrator;
        private bool _dependenciesInjected;

        private string _sceneName = string.Empty;

        // ===== Queue / non-concurrency =====
        private readonly object _queueLock = new();
        private readonly Queue<ResetRequest> _queue = new();
        private Task _queueRunnerTask;

        private bool _isResetting;

        public bool AutoInitializeOnStart
        {
            get => autoInitializeOnStart;
            set => autoInitializeOnStart = value;
        }

        private void Awake()
        {
            _sceneName = gameObject.scene.name;
            // IMPORTANT: Do NOT inject here. Scene services may not be registered yet.
        }

        private void Start()
        {
            EnsureDependenciesInjected();
            if (!HasCriticalDependencies())
            {
                return;
            }

            if (!autoInitializeOnStart)
            {
                if (verboseLogs)
                {
                    DebugUtility.Log(typeof(WorldLifecycleController),
                        $"AutoInitializeOnStart desabilitado — aguardando acionamento externo (scene='{_sceneName}').");
                }
                return;
            }

            _ = InitializeWorldAsync();
        }

        /// <summary>
        /// API pública. Enfileira um reset completo (hard reset).
        /// Se já houver reset em andamento, este pedido aguarda sua vez (não é descartado).
        /// </summary>
        public Task ResetWorldAsync(string reason)
        {
            return EnqueueRequest(ResetRequest.World(reason));
        }

        /// <summary>
        /// Soft reset focado apenas no escopo de jogadores (Players).
        /// Se já houver reset em andamento, este pedido aguarda sua vez (não é descartado).
        /// </summary>
        public Task ResetPlayersAsync(string reason = "PlayersSoftReset")
        {
            return EnqueueRequest(ResetRequest.Players(reason));
        }

        private async Task InitializeWorldAsync()
        {
            try
            {
                await ResetWorldAsync("AutoInitialize/Start");
            }
            catch (Exception ex)
            {
                // Não travar o jogo no Start. Apenas logar.
                DebugUtility.LogError(typeof(WorldLifecycleController),
                    $"AutoInitialize reset falhou na cena '{_sceneName}': {ex}",
                    this);
            }
        }

        private Task EnqueueRequest(ResetRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            EnsureDependenciesInjected();

            lock (_queueLock)
            {
                _queue.Enqueue(request);

                // Se não existe runner ativo, inicia um.
                if (_queueRunnerTask == null || _queueRunnerTask.IsCompleted)
                {
                    _queueRunnerTask = RunQueueAsync();
                }
            }

            return request.Promise.Task;
        }

        private async Task RunQueueAsync()
        {
            while (true)
            {
                ResetRequest request;

                lock (_queueLock)
                {
                    if (_queue.Count == 0)
                    {
                        // Fim do processamento.
                        _queueRunnerTask = null;
                        return;
                    }

                    request = _queue.Dequeue();
                }

                _isResetting = true;

                try
                {
                    if (!HasCriticalDependencies())
                    {
                        // Falha crítica: não dá para processar o pedido.
                        var ex = new InvalidOperationException(
                            $"Dependências críticas ausentes para reset na cena '{_sceneName}'.");
                        request.Promise.TrySetException(ex);
                        continue;
                    }

                    if (verboseLogs)
                    {
                        DebugUtility.Log(typeof(WorldLifecycleController),
                            $"Reset enfileirado iniciado. kind='{request.KindLabel}', reason='{request.Reason}', scene='{_sceneName}', pending={GetPendingCountSafe()}.");
                    }

                    BuildSpawnServices();
                    _orchestrator = CreateOrchestrator();

                    // Executa o pedido.
                    await request.ExecuteAsync(_orchestrator);

                    if (verboseLogs)
                    {
                        DebugUtility.Log(typeof(WorldLifecycleController),
                            $"Reset enfileirado concluído. kind='{request.KindLabel}', reason='{request.Reason}', scene='{_sceneName}'.");
                    }

                    request.Promise.TrySetResult(true);
                }
                catch (Exception ex)
                {
                    // Caso B: logar erro + propagar falha para o caller (SceneFlow/Coordinator etc.).
                    DebugUtility.LogError(typeof(WorldLifecycleController),
                        $"Reset falhou. kind='{request?.KindLabel ?? "<null>"}', reason='{request?.Reason ?? "<null>"}', scene='{_sceneName}': {ex}",
                        this);

                    request?.Promise.TrySetException(ex);
                }
                finally
                {
                    _isResetting = false;
                }
            }
        }

        private int GetPendingCountSafe()
        {
            lock (_queueLock)
            {
                return _queue.Count;
            }
        }

        private void EnsureDependenciesInjected()
        {
            if (_dependenciesInjected)
            {
                return;
            }

            DependencyManager.Provider.InjectDependencies(this);
            _dependenciesInjected = true;

            if (_hookRegistry == null)
            {
                DebugUtility.LogWarning(typeof(WorldLifecycleController),
                    $"WorldLifecycleHookRegistry não encontrado para a cena '{_sceneName}'. Hooks via registry ficarão desativados.");
            }

            if (_gateService == null)
            {
                DebugUtility.LogWarning(typeof(WorldLifecycleController),
                    $"ISimulationGateService não injetado para a cena '{_sceneName}'. Reset seguirá sem gate.");
            }

            if (_spawnRegistry == null)
            {
                DebugUtility.LogError(typeof(WorldLifecycleController),
                    $"IWorldSpawnServiceRegistry não encontrado para a cena '{_sceneName}'.");
            }

            if (_actorRegistry == null)
            {
                DebugUtility.LogError(typeof(WorldLifecycleController),
                    $"IActorRegistry não encontrado para a cena '{_sceneName}'.");
            }
        }

        private void BuildSpawnServices()
        {
            _spawnServices.Clear();

            if (_spawnRegistry == null)
            {
                DebugUtility.LogError(typeof(WorldLifecycleController),
                    $"Nenhum IWorldSpawnServiceRegistry encontrado para a cena '{_sceneName}'. Lista ficará vazia.",
                    this);
                return;
            }

            foreach (var service in _spawnRegistry.Services)
            {
                if (service != null)
                {
                    _spawnServices.Add(service);
                }
                else
                {
                    DebugUtility.LogWarning(typeof(WorldLifecycleController),
                        $"Serviço de spawn nulo detectado na cena '{_sceneName}'. Ignorado.");
                }
            }

            DebugUtility.Log(typeof(WorldLifecycleController),
                $"Spawn services coletados para a cena '{_sceneName}': {_spawnServices.Count} (registry total: {_spawnRegistry.Services.Count}).");

            if (_actorRegistry != null)
            {
                DebugUtility.Log(typeof(WorldLifecycleController),
                    $"ActorRegistry count antes de orquestrar: {_actorRegistry.Count}");
            }
        }

        private WorldLifecycleOrchestrator CreateOrchestrator()
        {
            EnsureDependenciesInjected();

            return new WorldLifecycleOrchestrator(
                _gateService,
                _spawnServices,
                _actorRegistry,
                provider: DependencyManager.Provider,
                sceneName: _sceneName,
                hookRegistry: _hookRegistry);
        }

        private bool HasCriticalDependencies()
        {
            var valid = true;

            if (_spawnRegistry == null)
            {
                DebugUtility.LogError(typeof(WorldLifecycleController),
                    $"Sem IWorldSpawnServiceRegistry para a cena '{_sceneName}'. Ciclo de vida não pode continuar.");
                valid = false;
            }

            if (_actorRegistry == null)
            {
                DebugUtility.LogError(typeof(WorldLifecycleController),
                    $"Sem IActorRegistry para a cena '{_sceneName}'. Ciclo de vida não pode continuar.");
                valid = false;
            }

            return valid;
        }

        // ===== Internal request model =====

        private sealed class ResetRequest
        {
            private ResetRequest(
                string kindLabel,
                string reason,
                Func<WorldLifecycleOrchestrator, Task> execute)
            {
                KindLabel = string.IsNullOrWhiteSpace(kindLabel) ? "<unknown>" : kindLabel;
                Reason = reason ?? string.Empty;
                _execute = execute ?? throw new ArgumentNullException(nameof(execute));

                Promise = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            }

            public string KindLabel { get; }
            public string Reason { get; }
            public TaskCompletionSource<bool> Promise { get; }

            private readonly Func<WorldLifecycleOrchestrator, Task> _execute;

            public Task ExecuteAsync(WorldLifecycleOrchestrator orchestrator)
            {
                if (orchestrator == null)
                {
                    throw new ArgumentNullException(nameof(orchestrator));
                }

                return _execute(orchestrator);
            }

            public static ResetRequest World(string reason)
            {
                return new ResetRequest(
                    kindLabel: "World",
                    reason: reason,
                    execute: orchestrator => orchestrator.ResetWorldAsync());
            }

            public static ResetRequest Players(string reason)
            {
                return new ResetRequest(
                    kindLabel: "Players",
                    reason: reason,
                    execute: orchestrator => orchestrator.ResetScopesAsync(
                        new List<ResetScope> { ResetScope.Players },
                        reason));
            }
        }
    }
}
