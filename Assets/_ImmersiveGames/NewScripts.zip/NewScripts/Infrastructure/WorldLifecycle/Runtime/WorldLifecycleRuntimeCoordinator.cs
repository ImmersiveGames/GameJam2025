using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using _ImmersiveGames.NewScripts.Infrastructure.DebugLog;
using _ImmersiveGames.NewScripts.Infrastructure.Events;
using _ImmersiveGames.NewScripts.Infrastructure.Scene;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace _ImmersiveGames.NewScripts.Infrastructure.WorldLifecycle.Runtime
{
    /// <summary>
    /// Driver runtime que reage a SceneTransitionScenesReadyEvent e, quando aplicável,
    /// dispara hard reset do WorldLifecycle.
    ///
    /// Regra recomendada:
    /// - Profile "startup" (Frontend/Ready) NÃO roda reset de world/spawn.
    /// - Para gameplay profiles, executa ResetWorldAsync no controller da cena alvo.
    /// </summary>
    [DebugLevel(DebugLevel.Verbose)]
    public sealed class WorldLifecycleRuntimeCoordinator : IDisposable
    {
        private const string StartupProfileName = "startup";

        // Observação: mantemos MenuScene como "cena frontend" por regra atual do projeto,
        // mas evitamos usar "menu" na nomenclatura (conceito é NonGameplay/Frontend).
        private const string FrontendSceneName = "MenuScene";

        private const string CompletedReasonSkipped = WorldLifecycleResetReason.SkippedStartupOrFrontend;
        private const string CompletedReasonNoController = WorldLifecycleResetReason.FailedNoController;

        private readonly EventBinding<SceneTransitionScenesReadyEvent> _onScenesReady;
        private int _resetInFlight; // 0/1

        public WorldLifecycleRuntimeCoordinator()
        {
            _onScenesReady = new EventBinding<SceneTransitionScenesReadyEvent>(OnScenesReady);
            EventBus<SceneTransitionScenesReadyEvent>.Register(_onScenesReady);

            DebugUtility.LogVerbose(typeof(WorldLifecycleRuntimeCoordinator),
                "[WorldLifecycle] Runtime driver registrado para SceneTransitionScenesReadyEvent.",
                DebugUtility.Colors.Info);
        }

        public void Dispose()
        {
            EventBus<SceneTransitionScenesReadyEvent>.Unregister(_onScenesReady);
        }

        private void OnScenesReady(SceneTransitionScenesReadyEvent evt)
        {
            if (Interlocked.CompareExchange(ref _resetInFlight, 1, 0) == 1)
            {
                DebugUtility.LogWarning(typeof(WorldLifecycleRuntimeCoordinator),
                    "[WorldLifecycle] Reset já está em execução. Ignorando novo ScenesReady.");
                return;
            }

            DebugUtility.Log(typeof(WorldLifecycleRuntimeCoordinator),
                $"[WorldLifecycle] SceneTransitionScenesReady recebido. Context={evt.Context}");

            _ = HandleScenesReadyAsync(evt);
        }

        private async Task HandleScenesReadyAsync(SceneTransitionScenesReadyEvent evt)
        {
            string profile = evt.Context.TransitionProfileName ?? string.Empty;

            string activeSceneName =
                !string.IsNullOrWhiteSpace(evt.Context.TargetActiveScene)
                    ? evt.Context.TargetActiveScene
                    : SceneManager.GetActiveScene().name;

            string reason = WorldLifecycleResetReason.ScenesReadyFor(activeSceneName);

            try
            {
                // Mantém comportamento atual:
                // - Startup profile não executa reset
                // - Frontend scene (MenuScene) também não executa reset
                bool skip =
                    string.Equals(profile, StartupProfileName, StringComparison.Ordinal) ||
                    string.Equals(activeSceneName, FrontendSceneName, StringComparison.Ordinal);

                if (skip)
                {
                    DebugUtility.LogVerbose(typeof(WorldLifecycleRuntimeCoordinator),
                        $"[WorldLifecycle] Reset SKIPPED (startup/frontend). profile='{profile}', activeScene='{activeSceneName}'.",
                        DebugUtility.Colors.Info);

                    RaiseCompleted(evt.Context, CompletedReasonSkipped);
                    return;
                }

                DebugUtility.Log(typeof(WorldLifecycleRuntimeCoordinator),
                    $"[WorldLifecycle] Disparando hard reset após ScenesReady. reason='{reason}', profile='{profile}'",
                    DebugUtility.Colors.Info);

                var controller = FindControllerInScene(activeSceneName);

                // Para gameplay scenes, controller é esperado.
                if (controller == null)
                {
                    DebugUtility.LogError(typeof(WorldLifecycleRuntimeCoordinator),
                        $"[WorldLifecycle] WorldLifecycleController não encontrado na cena '{activeSceneName}'. Reset abortado.");

                    RaiseCompleted(evt.Context, CompletedReasonNoController);
                    return;
                }

                await controller.ResetWorldAsync(reason);

                RaiseCompleted(evt.Context, reason);
            }
            catch (Exception ex)
            {
                DebugUtility.LogError(typeof(WorldLifecycleRuntimeCoordinator),
                    $"[WorldLifecycle] Falha ao executar reset após ScenesReady. reason='{reason}', profile='{profile}', ex={ex}");

                RaiseCompleted(evt.Context, WorldLifecycleResetReason.FailedReset(ex.GetType().Name));
            }
            finally
            {
                Interlocked.Exchange(ref _resetInFlight, 0);
            }
        }

        private static WorldLifecycleController FindControllerInScene(string sceneName)
        {
            WorldLifecycleController[] controllers =
                Object.FindObjectsByType<WorldLifecycleController>(FindObjectsSortMode.None);

            return (from c in controllers
                    where c != null
                    let s = c.gameObject.scene.name
                    where string.Equals(s, sceneName, StringComparison.Ordinal)
                    select c).FirstOrDefault();
        }

        private static void RaiseCompleted(SceneTransitionContext context, string reason)
        {
            string signature = SceneTransitionSignatureUtil.Compute(context);
            string profile = context.TransitionProfileName ?? string.Empty;

            DebugUtility.LogVerbose(typeof(WorldLifecycleRuntimeCoordinator),
                $"[WorldLifecycle] Emitting WorldLifecycleResetCompletedEvent. profile='{profile}', signature='{signature}', reason='{reason}'.",
                DebugUtility.Colors.Info);

            EventBus<WorldLifecycleResetCompletedEvent>.Raise(
                new WorldLifecycleResetCompletedEvent(signature, reason));
        }
    }
}
