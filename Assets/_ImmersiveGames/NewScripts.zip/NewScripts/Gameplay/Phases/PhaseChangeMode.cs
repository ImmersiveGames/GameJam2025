#nullable enable
namespace _ImmersiveGames.NewScripts.Gameplay.Phases
{
    /// <summary>
    /// Modos canônicos de troca de fase.
    /// </summary>
    public enum PhaseChangeMode
    {
        InPlace = 0,
        SceneTransition = 1
    }
}
