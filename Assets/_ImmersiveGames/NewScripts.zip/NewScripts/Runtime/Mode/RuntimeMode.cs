namespace _ImmersiveGames.NewScripts.Runtime.Mode
{
    public enum RuntimeMode
    {
        Strict = 0,
        Release = 1
    }
}
