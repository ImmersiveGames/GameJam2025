using System;
using _ImmersiveGames.NewScripts.Actors.Foundation;
using _ImmersiveGames.NewScripts.SessionActivity.Contracts;
using _ImmersiveGames.NewScripts.UnityUtils;

namespace _ImmersiveGames.NewScripts.Actors.Capabilities.Contracts
{
    public readonly struct ActorCapabilityId : IEquatable<ActorCapabilityId>
    {
        public ActorCapabilityId(string value)
        {
            Value = value.TrimToEmpty();
        }

        public string Value { get; }
        public bool IsValid => !string.IsNullOrWhiteSpace(Value);

        public bool Equals(ActorCapabilityId other)
        {
            return string.Equals(Value, other.Value, StringComparison.Ordinal);
        }
        public override bool Equals(object obj)
        {
            return obj is ActorCapabilityId other && Equals(other);
        }
        public override int GetHashCode()
        {
            return Value == null ? 0 : StringComparer.Ordinal.GetHashCode(Value);
        }
        public override string ToString()
        {
            return Value;
        }

        public static bool operator ==(ActorCapabilityId left, ActorCapabilityId right)
        {
            return left.Equals(right);
        }
        public static bool operator !=(ActorCapabilityId left, ActorCapabilityId right)
        {
            return !left.Equals(right);
        }
    }

    public enum ActorCapabilityContributionPhase
    {
        Unknown = 0,
        Setup = 1,
        Binding = 2,
        PermissionReceiver = 3,
        Reset = 4,
        Snapshot = 5,
        Restore = 6,
        Release = 7
    }

    public enum ActorCapabilityContributionRequirement
    {
        Unknown = 0,
        Optional = 1,
        Required = 2
    }

    public enum ActorCapabilitySnapshotPayloadFormat
    {
        Unknown = 0,
        Json = 1,
        Text = 2,
        BinaryBase64 = 3
    }

    public enum ActorCapabilityRestoreCompatibility
    {
        Unknown = 0,
        Compatible = 1,
        IncompatibleActor = 2,
        IncompatibleCapability = 3,
        IncompatibleSchema = 4,
        IncompatibleVersion = 5,
        Unsupported = 6
    }

    public readonly struct ActorCapabilityContributionContext
    {
        public ActorCapabilityContributionContext(
            SessionActivityIdentity identity,
            ActorId actorId,
            ActorInstanceRuntimeId actorInstanceRuntimeId,
            ActorKind actorKind,
            ActorRole actorRole,
            ActorScope actorScope,
            string componentPath,
            string source,
            string reason)
        {
            Identity = identity;
            ActorId = actorId;
            ActorInstanceRuntimeId = actorInstanceRuntimeId;
            ActorKind = actorKind;
            ActorRole = actorRole;
            ActorScope = actorScope;
            ComponentPath = componentPath.TrimToEmpty();
            Source = source.TrimToEmpty();
            Reason = reason.TrimToEmpty();
        }

        public SessionActivityIdentity Identity { get; }
        public ActorId ActorId { get; }
        public ActorInstanceRuntimeId ActorInstanceRuntimeId { get; }
        public ActorKind ActorKind { get; }
        public ActorRole ActorRole { get; }
        public ActorScope ActorScope { get; }
        public string ComponentPath { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            ActorId.IsValid &&
            ActorInstanceRuntimeId.IsValid &&
            ActorKind != ActorKind.Unknown &&
            ActorRole != ActorRole.Unknown &&
            ActorScope != ActorScope.Unknown &&
            !string.IsNullOrWhiteSpace(ComponentPath) &&
            !string.IsNullOrWhiteSpace(Source);
    }

    public readonly struct ActorCapabilityContributionDescriptor
    {
        public ActorCapabilityContributionDescriptor(
            ActorCapabilityId capabilityId,
            ActorCapabilityContributionPhase phase,
            ActorCapabilityContributionRequirement requirement,
            ActorId actorId,
            ActorInstanceRuntimeId actorInstanceRuntimeId,
            ActorKind actorKind,
            ActorRole actorRole,
            ActorScope actorScope,
            string componentPath,
            string source,
            string reason)
        {
            CapabilityId = capabilityId;
            Phase = phase;
            Requirement = requirement;
            ActorId = actorId;
            ActorInstanceRuntimeId = actorInstanceRuntimeId;
            ActorKind = actorKind;
            ActorRole = actorRole;
            ActorScope = actorScope;
            ComponentPath = componentPath.TrimToEmpty();
            Source = source.TrimToEmpty();
            Reason = reason.TrimToEmpty();
        }

        public ActorCapabilityId CapabilityId { get; }
        public ActorCapabilityContributionPhase Phase { get; }
        public ActorCapabilityContributionRequirement Requirement { get; }
        public ActorId ActorId { get; }
        public ActorInstanceRuntimeId ActorInstanceRuntimeId { get; }
        public ActorKind ActorKind { get; }
        public ActorRole ActorRole { get; }
        public ActorScope ActorScope { get; }
        public string ComponentPath { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            CapabilityId.IsValid &&
            Phase != ActorCapabilityContributionPhase.Unknown &&
            Requirement != ActorCapabilityContributionRequirement.Unknown &&
            ActorId.IsValid &&
            ActorInstanceRuntimeId.IsValid &&
            ActorKind != ActorKind.Unknown &&
            ActorRole != ActorRole.Unknown &&
            ActorScope != ActorScope.Unknown &&
            !string.IsNullOrWhiteSpace(ComponentPath) &&
            !string.IsNullOrWhiteSpace(Source);
    }

    public readonly struct ActorCapabilitySnapshotPayload
    {
        public ActorCapabilitySnapshotPayload(
            SessionActivityIdentity identity,
            ActorId actorId,
            ActorInstanceRuntimeId actorInstanceRuntimeId,
            ActorKind actorKind,
            ActorRole actorRole,
            ActorScope actorScope,
            ActorCapabilityId capabilityId,
            string schemaId,
            int schemaVersion,
            ActorCapabilitySnapshotPayloadFormat payloadFormat,
            string payload,
            string source,
            string reason)
        {
            Identity = identity;
            ActorId = actorId;
            ActorInstanceRuntimeId = actorInstanceRuntimeId;
            ActorKind = actorKind;
            ActorRole = actorRole;
            ActorScope = actorScope;
            CapabilityId = capabilityId;
            SchemaId = schemaId.TrimToEmpty();
            SchemaVersion = schemaVersion;
            PayloadFormat = payloadFormat;
            Payload = payload ?? string.Empty;
            Source = source.TrimToEmpty();
            Reason = reason.TrimToEmpty();
        }

        public SessionActivityIdentity Identity { get; }
        public ActorId ActorId { get; }
        public ActorInstanceRuntimeId ActorInstanceRuntimeId { get; }
        public ActorKind ActorKind { get; }
        public ActorRole ActorRole { get; }
        public ActorScope ActorScope { get; }
        public ActorCapabilityId CapabilityId { get; }
        public string SchemaId { get; }
        public int SchemaVersion { get; }
        public ActorCapabilitySnapshotPayloadFormat PayloadFormat { get; }
        public string Payload { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            ActorId.IsValid &&
            ActorInstanceRuntimeId.IsValid &&
            ActorKind != ActorKind.Unknown &&
            ActorRole != ActorRole.Unknown &&
            ActorScope != ActorScope.Unknown &&
            CapabilityId.IsValid &&
            !string.IsNullOrWhiteSpace(SchemaId) &&
            SchemaVersion > 0 &&
            PayloadFormat != ActorCapabilitySnapshotPayloadFormat.Unknown &&
            !string.IsNullOrWhiteSpace(Source);
    }

    public readonly struct ActorCapabilitySnapshotCaptureResult
    {
        public ActorCapabilitySnapshotCaptureResult(
            bool captured,
            ActorCapabilitySnapshotPayload payload,
            string outcomeReason,
            string source,
            string reason)
        {
            Captured = captured;
            Payload = payload;
            OutcomeReason = outcomeReason.TrimToEmpty();
            Source = source.TrimToEmpty();
            Reason = reason.TrimToEmpty();
        }

        public bool Captured { get; }
        public ActorCapabilitySnapshotPayload Payload { get; }
        public string OutcomeReason { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid => Captured ? Payload.IsValid : !string.IsNullOrWhiteSpace(OutcomeReason);
    }

    public readonly struct ActorCapabilityRestoreResult
    {
        public ActorCapabilityRestoreResult(
            bool restored,
            ActorCapabilityRestoreCompatibility compatibility,
            string outcomeReason,
            string source,
            string reason)
        {
            Restored = restored;
            Compatibility = compatibility;
            OutcomeReason = outcomeReason.TrimToEmpty();
            Source = source.TrimToEmpty();
            Reason = reason.TrimToEmpty();
        }

        public bool Restored { get; }
        public ActorCapabilityRestoreCompatibility Compatibility { get; }
        public string OutcomeReason { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Compatibility != ActorCapabilityRestoreCompatibility.Unknown &&
            !string.IsNullOrWhiteSpace(OutcomeReason) &&
            !string.IsNullOrWhiteSpace(Source);
    }

    public readonly struct ActorCapabilityReleaseResult
    {
        public ActorCapabilityReleaseResult(
            bool released,
            string outcomeReason,
            string source,
            string reason)
        {
            Released = released;
            OutcomeReason = outcomeReason.TrimToEmpty();
            Source = source.TrimToEmpty();
            Reason = reason.TrimToEmpty();
        }

        public bool Released { get; }
        public string OutcomeReason { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid => !string.IsNullOrWhiteSpace(OutcomeReason) && !string.IsNullOrWhiteSpace(Source);
    }

    public interface IActorCapabilityContribution
    {
        ActorCapabilityContributionDescriptor Descriptor { get; }
        bool IsValid { get; }
    }

    public interface IActorSetupContribution : IActorCapabilityContribution { }

    public interface IActorBindingContribution : IActorCapabilityContribution { }

    public interface IActorPermissionReceiverContribution : IActorCapabilityContribution { }

    public interface IActorResetContribution : IActorCapabilityContribution
    {
        ActivityResetBoundaryEligibility ResetBoundaryEligibility { get; }
    }

    public interface IActorSnapshotContribution : IActorCapabilityContribution
    {
        string SchemaId { get; }
        int SchemaVersion { get; }
        IActorCapabilitySnapshotEndpoint SnapshotEndpoint { get; }
    }

    public interface IActorRestoreContribution : IActorCapabilityContribution
    {
        string SchemaId { get; }
        int SchemaVersion { get; }
        IActorCapabilityRestoreEndpoint RestoreEndpoint { get; }
    }

    public interface IActorReleaseContribution : IActorCapabilityContribution
    {
        IActorCapabilityReleaseEndpoint ReleaseEndpoint { get; }
    }

    public interface IActorCapabilitySnapshotEndpoint
    {
        bool TryCaptureSnapshot(
            ActorCapabilityContributionContext context,
            out ActorCapabilitySnapshotCaptureResult result);
    }

    public interface IActorCapabilityRestoreEndpoint
    {
        bool TryEvaluateRestoreCompatibility(
            ActorCapabilityContributionContext context,
            ActorCapabilitySnapshotPayload payload,
            out ActorCapabilityRestoreCompatibility compatibility);

        bool TryRestoreSnapshot(
            ActorCapabilityContributionContext context,
            ActorCapabilitySnapshotPayload payload,
            out ActorCapabilityRestoreResult result);
    }

    public interface IActorCapabilityReleaseEndpoint
    {
        bool TryRelease(
            ActorCapabilityContributionContext context,
            out ActorCapabilityReleaseResult result);
    }

    public interface IActorSetupContributionProvider
    {
        bool TryCreateSetupContribution(
            ActorCapabilityContributionContext context,
            out IActorSetupContribution contribution);
    }

    public interface IActorBindingContributionProvider
    {
        bool TryCreateBindingContribution(
            ActorCapabilityContributionContext context,
            out IActorBindingContribution contribution);
    }

    public interface IActorPermissionReceiverContributionProvider
    {
        bool TryCreatePermissionReceiverContribution(
            ActorCapabilityContributionContext context,
            out IActorPermissionReceiverContribution contribution);
    }

    public interface IActorResetContributionProvider
    {
        bool TryCreateResetContribution(
            ActorCapabilityContributionContext context,
            out IActorResetContribution contribution);
    }

    public interface IActorSnapshotContributionProvider
    {
        bool TryCreateSnapshotContribution(
            ActorCapabilityContributionContext context,
            out IActorSnapshotContribution contribution);
    }

    public interface IActorRestoreContributionProvider
    {
        bool TryCreateRestoreContribution(
            ActorCapabilityContributionContext context,
            out IActorRestoreContribution contribution);
    }

    public interface IActorReleaseContributionProvider
    {
        bool TryCreateReleaseContribution(
            ActorCapabilityContributionContext context,
            out IActorReleaseContribution contribution);
    }
}
