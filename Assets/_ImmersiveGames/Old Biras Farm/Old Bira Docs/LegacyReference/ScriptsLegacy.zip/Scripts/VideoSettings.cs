using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VideoSettings : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;

    [SerializeField] Dropdown qualityDropDown;
    [SerializeField] Dropdown resolutionDropdown;
    [SerializeField] Toggle fullScreenToggle;
    [SerializeField] Toggle vSyncToggle;


    Resolution[] resolutions;    

    void Awake()
    {        
        SetInitialVideoOptions();
    }

    private void SetInitialVideoOptions()
    {
        fullScreenToggle.isOn = Screen.fullScreen;

        SetQuality(myPlayerData.GetVideoQualityIndex());
        qualityDropDown.value = QualitySettings.GetQualityLevel();

        SetResolutionOptions();
        SetResolution(myPlayerData.GetVideoResIndex());

        QualitySettings.vSyncCount = myPlayerData.GetVSync();
        if (QualitySettings.vSyncCount == 0) vSyncToggle.isOn = false;
        if (QualitySettings.vSyncCount == 1) vSyncToggle.isOn = true;
    }


    private void SetResolutionOptions()
    {
        resolutions = Screen.resolutions;

        resolutionDropdown.ClearOptions();

        List<string> options = new List<string>();

        int currentResolutionIndex = 0;

        for (int i = 0; i < resolutions.Length; i++) 
        {
            string option = resolutions[i].width + " x " + resolutions[i].height + " - " + resolutions[i].refreshRate + "hz";
            options.Add(option);

            if (resolutions[i].width == Screen.currentResolution.width &&
                resolutions[i].height == Screen.currentResolution.height) 
            {
                currentResolutionIndex = i;
            }
        }

        resolutionDropdown.AddOptions(options);
        resolutionDropdown.value = myPlayerData.GetVideoResIndex();
        resolutionDropdown.RefreshShownValue();
    }

    public void SetResolution(int resolutionIndex) 
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
        myPlayerData.SetVideoResIndex(resolutionIndex);
        Application.targetFrameRate = Screen.currentResolution.refreshRate;
    }

    public void SetFullScreen() 
        {
            Screen.fullScreen = !Screen.fullScreen;
            myPlayerData.SetFullScreenON(Screen.fullScreen);
        }

    public void SetQuality(int qualityIndex) 
    {
        QualitySettings.SetQualityLevel(qualityIndex);
        myPlayerData.SetVideoQualityIndex(qualityIndex);
    }

    public void SetVSync() 
    {
        if (vSyncToggle == true) 
        {
            QualitySettings.vSyncCount = 1;
            myPlayerData.SetVSync(1);
        }
        if (vSyncToggle == false) 

        {
            QualitySettings.vSyncCount = 0;
            myPlayerData.SetVSync(0);
        }
    }
}
