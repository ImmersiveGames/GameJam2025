using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityManager : MonoBehaviour
{
    [SerializeField] Vector3 gravityVector;

    void Awake()
    {
        Physics.gravity = gravityVector;
    }
}
