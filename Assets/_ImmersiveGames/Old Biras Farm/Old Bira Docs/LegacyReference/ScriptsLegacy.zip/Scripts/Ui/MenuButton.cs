using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Playables;

public class MenuButton : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;

    [Header("Intro References")]
    [SerializeField] Animator cameraAnimator;
    [SerializeField] Animator doorAnimator;

    [Header("Buttons References")]
    [SerializeField] Button myStartButton;
    [SerializeField] GameObject firstMenuButton, firstOptionsButton, resetMenuFirstButton, htpCloseButton;
    [SerializeField] GameObject menu, skinMenu, buttonsMenu;

    [Header("Loading Screen References")]
    [SerializeField] GameObject loadingScreen;
    [SerializeField] Slider loadingBar;
    [SerializeField] Text loadingText;

    int gameModeIndex;

    void OnEnable()
    {
        LoadGame();
    }

    private void ApplyVideoSettingsSaved()
    {
        Application.targetFrameRate = Screen.currentResolution.refreshRate;
        QualitySettings.SetQualityLevel(myPlayerData.GetVideoQualityIndex());
        QualitySettings.vSyncCount = myPlayerData.GetVSync();
    }

    void Start()
    {
        gameModeIndex = myPlayerData.actualGameModeIndex;
        ApplyVideoSettingsSaved();
    }

    public void PressStart() 
    {
        doorAnimator.SetTrigger("outside");
        cameraAnimator.SetTrigger("Move");
    }

    public void StartGameMode(int gameModeIndex)
    {
        myPlayerData.actualGameModeIndex = gameModeIndex;

        myPlayerData.GameMode[gameModeIndex].ResetTime();
        myPlayerData.GameMode[gameModeIndex].ResetActualFails();
        myPlayerData.GameMode[gameModeIndex].ResetTotalFails();
        myPlayerData.GameMode[gameModeIndex].SetCurrentLevelIndex(myPlayerData.GameMode[gameModeIndex].GetFirstLevelIndex());
        myPlayerData.GameMode[gameModeIndex].SetNoFailGame(false);

        StartCoroutine(LoadAsynchronously(myPlayerData.GameMode[gameModeIndex].GetFirstLevelIndex()));
    }

    public void StartNoFailGame(int index) 
    {
        myPlayerData.actualGameModeIndex = index;
        
        myPlayerData.GameMode[gameModeIndex].ResetTime();
        myPlayerData.GameMode[gameModeIndex].ResetActualFails();
        myPlayerData.GameMode[gameModeIndex].ResetTotalFails();
        myPlayerData.GameMode[gameModeIndex].SetNoFailGame(true);
        myPlayerData.GameMode[gameModeIndex].SetCurrentLevelIndex(myPlayerData.GameMode[gameModeIndex].GetFirstLevelIndex());
        StartCoroutine(LoadAsynchronously(myPlayerData.GameMode[gameModeIndex].GetFirstLevelIndex()));
    }

    public void ResumeGameRun(int gameModeIndex)
    {
        myPlayerData.actualGameModeIndex = gameModeIndex;

        StartCoroutine(LoadAsynchronously(myPlayerData.GameMode[gameModeIndex].GetCurrentLevelIndex()));
    }

    IEnumerator LoadAsynchronously(int sceneIndex)
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneIndex);

        loadingScreen.SetActive(true);

        while (!operation.isDone)
        {
            float progress = Mathf.Clamp01(operation.progress / 0.9f);
            loadingBar.value = progress;
            loadingText.text = progress * 100f + "%";

            yield return null;
        }
    }

    public void QuitButton() 
    {
        Application.Quit();
    }

    void Update()
    {        
        if (myPlayerData.playerPrefab == null)
        {
            myStartButton.interactable = false;
        }

        else if (myPlayerData.playerPrefab != null && myStartButton.interactable == false) 
        {
            myStartButton.interactable = true;
        }

        //if (Input.GetKeyDown(KeyCode.L)) ResetSkins();
    }

    public void ResetRecordButton(int gameIndex) 
    {
        myPlayerData.GameMode[gameIndex].ResetMyRecordTime();
        SaveSystem.SavePlayerInfo(myPlayerData);
    }

    public void LoadGame()
    {
        PlayerDataToSave data = SaveSystem.LoadPlayerInfo();

        if (data == null) return;

        myPlayerData.SetMusicVolume(data.myVolume);
        myPlayerData.SetSfxVolume(data.mySFXVolume);

        myPlayerData.SetVideoQualityIndex(data.myQualityIndex);
        myPlayerData.SetVideoResIndex(data.myResIndex);
        myPlayerData.SetFullScreenON(data.isfullScreenON);
        myPlayerData.SetVSync(data.vSyncIndex);

        // Apple Rush Load Data
        myPlayerData.GameMode[0].SetCurrentLevelIndex(data.currentLevel);

        myPlayerData.GameMode[0].SetActualFails(data.actualFails);
        myPlayerData.GameMode[0].SetTotalFails(data.totalFails);

        myPlayerData.GameMode[0].LoadActualLevelTime(data.actualLevelTime);
        myPlayerData.GameMode[0].LoadActuatRunTotalTime(data.actualRunTotalTime);

        myPlayerData.GameMode[0].LoadMyBestRunTime(data.myBestTime);
        myPlayerData.GameMode[0].LoadMyBestRunFails(data.myBestTimeFails);

        myPlayerData.GameMode[0].SetHasBeatenGame(data.hasBeatenGame);
        //------------------------------------------------------------

        myPlayerData.SetFailCount(data.failCount);
        myPlayerData.SetAppleCollectCount(data.appleCollectCount);
        myPlayerData.SetCompleteRunCount(data.completeRunCount);
        myPlayerData.SetStandCount(data.standCount);
        myPlayerData.SetBadLandingCount(data.badLandingCount);

        myPlayerData.isDogUnlocked = data.isDogUnlocked;
        myPlayerData.isDuckUnlocked = data.isDuckUnlocked;
        myPlayerData.isOwlUnlocked = data.isOwlUnlocked;
        myPlayerData.isParrotUnlocked = data.isParrotUnlocked;
        myPlayerData.isChickenUnlocked = data.isChickenUnlocked;
        myPlayerData.isFrogUnlocked = data.isFrogUnlocked;
        myPlayerData.isCatUnlocked = data.isCatUnlocked;
        myPlayerData.isGoatUnlocked = data.isGoatUnlocked;
        myPlayerData.isTurtleUnlocked = data.isTurtleUnlocked;
        myPlayerData.isSheepUnlocked = data.isSheepUnlocked;
        myPlayerData.isBunnyUnlocked = data.isBunnyUnlocked;
    }

    public void SetMenu(GameObject button) 
    {
        menu.SetActive(true);
        EventSystem.current.SetSelectedGameObject(button);
    }

    public void OptionsMenuOn() { SetMenu(firstOptionsButton); }
    public void OptionsMenuOff() 
    { 
        SaveSystem.SavePlayerInfo(myPlayerData); 
        SetMenu(firstMenuButton);
    }
    public void ResetMenuOn() { SetMenu(resetMenuFirstButton); }
    public void ResetMenuOff() { SetMenu(firstOptionsButton); }
    public void HTPPanelON() { SetMenu(htpCloseButton); }

    void ResetSkins() 
    {
        myPlayerData.isDogUnlocked = false;
        myPlayerData.isDuckUnlocked = false;
        myPlayerData.isOwlUnlocked = false;
        myPlayerData.isParrotUnlocked = false;
        myPlayerData.isChickenUnlocked = false;
        myPlayerData.isFrogUnlocked = false;
        myPlayerData.isCatUnlocked = false;
        myPlayerData.isGoatUnlocked = false;
        myPlayerData.isTurtleUnlocked = false;
        myPlayerData.isSheepUnlocked = false;
        myPlayerData.isBunnyUnlocked = false;

        SaveSystem.SavePlayerInfo(myPlayerData);
    }

    public void SetFirstButton(GameObject button) 
    {
        EventSystem.current.SetSelectedGameObject(button);
    }
}
