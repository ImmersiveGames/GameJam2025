using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Level_Display : MonoBehaviour
{
    Text myText;    
    
    // Start is called before the first frame update
    void Start()
    {
        myText = GetComponent<Text>();
        myText.text = ("Level: " + SceneManager.GetActiveScene().buildIndex.ToString());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
