using UnityEngine;
using UnityEngine.UI;

public class GoalDisplayManager : MonoBehaviour
{
    [SerializeField] Image goalFillImage;
    [SerializeField] Text goalText;

    GameObject myLandingPad;
    float currentVelocity = 0f;

    // Start is called before the first frame update
    void Start()
    {
        myLandingPad = GameObject.Find("LandingPad");
    }

    // Update is called once per frame
    void Update()
    {
        goalText.text = myLandingPad.GetComponent<LandingPadActivation>().GetGoalProgressionText();
        
        float myProgretionValue = myLandingPad.GetComponent<LandingPadActivation>().GetGoalProgression();
        float currentValue = Mathf.SmoothDamp(goalFillImage.fillAmount, myProgretionValue, ref currentVelocity, 100 * Time.deltaTime);
        goalFillImage.fillAmount = currentValue;        
    }
}
