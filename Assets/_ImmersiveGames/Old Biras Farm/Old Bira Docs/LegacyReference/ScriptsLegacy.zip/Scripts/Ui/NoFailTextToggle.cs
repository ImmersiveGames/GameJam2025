using UnityEngine;

public class NoFailTextToggle : MonoBehaviour
{
    [SerializeField] GameObject noFailModeText;
    [SerializeField] PlayerData myPlayerData;

    // Start is called before the first frame update
    void Start()
    {
        SetNoFailModeText();
    }

    void SetNoFailModeText()
    {
        noFailModeText.SetActive(myPlayerData.GameMode[myPlayerData.actualGameModeIndex].GetNoFailGame());        
    }
}
