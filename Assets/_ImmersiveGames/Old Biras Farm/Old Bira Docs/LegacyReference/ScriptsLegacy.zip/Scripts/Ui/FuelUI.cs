using UnityEngine;
using UnityEngine.UI;

public class FuelUI : MonoBehaviour
{
    [SerializeField] Movement myMovement;
    [SerializeField] Image fuelFillUI;
    Slider fuelBarUI;

    // Start is called before the first frame update
    void Start()
    {
        fuelBarUI = GetComponent<Slider>();
        myMovement = FindObjectOfType<Movement>();
    }

    // Update is called once per frame
    void Update()
    {
        if (myMovement == null) Start();
        FuelBarUI();
    }

    void FuelBarUI()
    {
        fuelBarUI.value = myMovement.CurrentFuelValue();

        if (fuelBarUI.value <= Mathf.Epsilon) fuelFillUI.color = Color.black;
        else if (fuelBarUI.value <= 33f) fuelFillUI.color = Color.red;
        else if (fuelBarUI.value <= 66f) fuelFillUI.color = Color.yellow;
        else fuelFillUI.color = Color.green;
    }
}
