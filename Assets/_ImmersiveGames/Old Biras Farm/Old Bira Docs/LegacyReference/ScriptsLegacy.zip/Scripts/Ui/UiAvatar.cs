using UnityEngine;
using UnityEngine.UI;

public class UiAvatar : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] Image myImage;
    [SerializeField] Sprite avatarDefault;

    Sprite avatar;

    // Start is called before the first frame update
    void Start()
    {
        SetMyAvatar();
    }

    void SetMyAvatar() 
    {
        avatar = myPlayerData.myCurrentSkinData.myAvatar;
        if (avatar != null) myImage.sprite = avatar;
        else myImage.sprite = avatarDefault;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
