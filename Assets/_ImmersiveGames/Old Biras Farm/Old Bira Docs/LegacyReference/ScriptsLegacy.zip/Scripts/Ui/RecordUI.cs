using UnityEngine;
using UnityEngine.UI;

public class RecordUI : MonoBehaviour
{
    [Header("Player Info")]
    [SerializeField] PlayerData myPlayerData;
    
    [Header("Actual Run UI")]
    [SerializeField] Text myAcutualRunTime;
    [SerializeField] Text myAcutualRunTime_Shadow;
    [SerializeField] Text myActualRunFails;
    [SerializeField] Text myActualRunFails_Shadow;

    [Header("Record Run UI")]
    [SerializeField] Text myBestTimeText;
    [SerializeField] Text myBestTimeTextBG;

    [SerializeField] Text myBestTimeFailsText;
    [SerializeField] Text myBestTimeFailsTextBG;

    [SerializeField] GameObject newRecordAlertText;

    bool isRecord = false;
    [SerializeField] bool isFinishScreen = false;
    [SerializeField] Text finishScreenTitleText;
    [SerializeField] Text finishScreenTitleTextShadow;

    int gameModeIndex;

    // Start is called before the first frame update
    void Start()
    {
        gameModeIndex = myPlayerData.actualGameModeIndex;
    }

    // Update is called once per frame
    void Update()
    {
        SetRecordUI();
    }
    void SetRecordUI() 
    {
        if (isFinishScreen == true)
        {
            finishScreenTitleText.text = (myPlayerData.GameMode[myPlayerData.actualGameModeIndex].GetGameModeName() + " Completed!");
            finishScreenTitleTextShadow.text = finishScreenTitleText.text;

            myAcutualRunTime.text = (DisplayTime(myPlayerData.GameMode[gameModeIndex].GetActualGameTotalTime()));
            myAcutualRunTime_Shadow.text = myAcutualRunTime.text;
            myActualRunFails.text = (myPlayerData.GameMode[gameModeIndex].GetTotalFails().ToString());
            myActualRunFails_Shadow.text = myActualRunFails.text;
            isRecord = myPlayerData.GameMode[gameModeIndex].GetIsNewRecord();
            newRecordAlertText.SetActive(isRecord);
        }

        myBestTimeText.text = (DisplayTime(myPlayerData.GameMode[gameModeIndex].GetMyBestTime()));
        myBestTimeFailsText.text = (myPlayerData.GameMode[gameModeIndex].GetMyBestTimeFails().ToString());
        myBestTimeTextBG.text = myBestTimeText.text;
        myBestTimeFailsTextBG.text = myBestTimeFailsText.text;  

    }

    string DisplayTime(float timeToDisplay)
    {
        int hour = Mathf.FloorToInt((timeToDisplay / 60f) / 60f);
        int minutes = Mathf.FloorToInt(((timeToDisplay / 60f / 60) - hour) * 60f);
        int seconds = Mathf.FloorToInt(((((timeToDisplay / 60f / 60) - hour) * 60f)- minutes) * 60f);

        string timeConverted = string.Format("{0:00}:{1:00}:{2:00}", hour, minutes, seconds);

        return timeConverted;
    }
}
