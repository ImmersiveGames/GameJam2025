using UnityEngine;
using UnityEngine.UI;

public class SkinSelection : MonoBehaviour
{    
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] Text characterNameText;
    
    GameObject playerPrefab;
    GameObject myPlayer;

    public int colorIndex;

    void Start()
    {        
        SpawnSelection();
    }

    void Update()
    {
        if (myPlayer.GetComponent<Movement>().canMove == true)
        {
            KillMovement();
        }
    }

    private void KillMovement()
    {
        myPlayer.GetComponent<Movement>().canMove = false;       
    }

     public void SkinDataSet(SkinData skinData, int color) 
    {
        myPlayerData.myCurrentSkinData = skinData;
        myPlayerData.myCurrentSkinData.selectedSkin = color;
        myPlayerData.SetMySkin();
        
        SpawnSelection();
    }

    public void SpawnSelection() 
    {
        if (myPlayer != null) Destroy(myPlayer);

        playerPrefab = myPlayerData.playerPrefab;
        myPlayer = Instantiate(playerPrefab, transform.position, Quaternion.identity);
        myPlayer.GetComponent<Rigidbody>().isKinematic = true;
        myPlayer.GetComponent<Movement>().enabled = false;
        myPlayer.GetComponent<CollisionHandler>().enabled = false;

        if (characterNameText != null) characterNameText.text = myPlayerData.myCurrentSkinData.skinName;
    }

    public void ColorSelectRight() 
    {
        colorIndex++;  
        if (colorIndex > myPlayerData.myCurrentSkinData.skinColorPrefab.Length - 1) colorIndex = 0;
        SkinDataSet(myPlayerData.myCurrentSkinData, colorIndex);
    }

    public void ColorSelectLeft() 
    {
        colorIndex--;
        if (colorIndex < 0) colorIndex = myPlayerData.myCurrentSkinData.skinColorPrefab.Length - 1;
        SkinDataSet(myPlayerData.myCurrentSkinData, colorIndex);
    }
}
