using UnityEngine;
using UnityEngine.UI;

public class SkinButtom : MonoBehaviour
{
    [SerializeField] SkinData mySkinData;
    [SerializeField] SkinSelection skinSelection;
    [SerializeField] GameObject myAvatar;

    void Start()
    {
       CheckIfIsUnlocked();
    }

    public void SetSkin() 
    {
        if (mySkinData.isUnlocked) 
        {
            skinSelection.SkinDataSet(mySkinData, 0);
            skinSelection.colorIndex = 0;            
        }
    }

    void CheckIfIsUnlocked() 
    {
        if (mySkinData.isUnlocked)
        {
            myAvatar.GetComponent<Image>().sprite = mySkinData.myAvatar;            
        }

        else if (!mySkinData.isUnlocked) 
        {
            myAvatar.GetComponent<Image>().sprite = mySkinData.myLockedAvatar;
        }
    }
}
