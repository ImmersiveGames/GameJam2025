using UnityEngine;
using UnityEngine.UI;

public class TryAgainTogle : MonoBehaviour
{
    Button myButton;
    [SerializeField] PlayerData myPlayerData;

    // Start is called before the first frame update
    void Start()
    {
        myButton = GetComponent<Button>();
        if (myPlayerData.GameMode[myPlayerData.actualGameModeIndex].GetNoFailGame()) myButton.interactable = false;
    }
}
