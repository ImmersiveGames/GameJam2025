using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class StatisticsUI : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] GameObject backButton;
    [SerializeField] Text completedRunsText, bestRunText, failCountText, appleCountText, goodLandingText, badLandingText;

    // Start is called before the first frame update

    void OnEnable()
    {
        HighlightBackButton();
        //SetStatisticsTexts();
    }

    void Start()
    {
        //HighlightBackButton();
        //SetStatisticsTexts();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void HighlightBackButton() 
    {
        EventSystem.current.SetSelectedGameObject(backButton);
    }

    //void SetStatisticsTexts() 
    //{
    //    completedRunsText.text = myPlayerData.GetCompleteRunCount().ToString();

    //    bestRunText.text = (DisplayTime(myPlayerData.GetMyBestRunTime()) +
    //                        " with " +
    //                        myPlayerData.GetMyBestRunFails().ToString() +
    //                        " Fails");

    //    failCountText.text = myPlayerData.GetFailCount().ToString();

    //    appleCountText.text = myPlayerData.GetAppleCollectCount().ToString();

    //    goodLandingText.text = myPlayerData.GetStandCount().ToString();

    //    badLandingText.text = myPlayerData.GetBadLandingCount().ToString();
    //}

    string DisplayTime(float timeToDisplay)
    {
        int hour = Mathf.FloorToInt((timeToDisplay / 60f) / 60f);
        int minutes = Mathf.FloorToInt(((timeToDisplay / 60f / 60) - hour) * 60f);
        int seconds = Mathf.FloorToInt(((((timeToDisplay / 60f / 60) - hour) * 60f) - minutes) * 60f);

        string timeConverted = string.Format("{0:00}:{1:00}:{2:00}", hour, minutes, seconds);

        return timeConverted;
    }
}
