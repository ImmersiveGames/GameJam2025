using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveSystem
{
    public static void SavePlayerInfo(PlayerData playerData) 
    {
        BinaryFormatter formatter = new BinaryFormatter();

        string path = Application.persistentDataPath + "/player.fun";
        FileStream stream = new FileStream(path, FileMode.Create);

        PlayerDataToSave data = new PlayerDataToSave(playerData);

        formatter.Serialize(stream, data);
        stream.Close();
    }

    public static PlayerDataToSave LoadPlayerInfo() 
    {
        string path = Application.persistentDataPath + "/player.fun";
        if (File.Exists(path)) 
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);

            PlayerDataToSave data = formatter.Deserialize(stream) as PlayerDataToSave;
            stream.Close();

            return data;
        }

        else 
        {
            //Debug.LogError("Save file not found in " + path);
            return null;
        }
    }
}
