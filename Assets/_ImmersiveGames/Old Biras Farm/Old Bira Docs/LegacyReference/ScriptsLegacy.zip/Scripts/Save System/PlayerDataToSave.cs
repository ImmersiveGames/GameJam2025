using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerDataToSave
{
    // Options

    // Audio Values
    public float myVolume;
    public float mySFXVolume;
    
    //Video Values
    public int myQualityIndex;
    public int myResIndex;
    public bool isfullScreenON;
    public int vSyncIndex;

    // Actual Run Info
    public int currentLevel;   
    
    // -> Fails info
    public int actualFails;    
    public int totalFails;

    // -> Time info
    public float actualLevelTime;
    public float actualRunTotalTime;

    //Record Info
    public float myBestTime;
    public int myBestTimeFails;

    public bool hasBeatenGame;

    // Achievments Counts
    public int failCount;
    public int appleCollectCount;
    public int completeRunCount;
    public int standCount;
    public int badLandingCount;

    // Skins Unlocked
    public bool isDogUnlocked;
    public bool isDuckUnlocked;
    public bool isOwlUnlocked;
    public bool isParrotUnlocked;
    public bool isChickenUnlocked;
    public bool isFrogUnlocked;
    public bool isCatUnlocked;
    public bool isGoatUnlocked;
    public bool isTurtleUnlocked;
    public bool isSheepUnlocked;
    public bool isBunnyUnlocked;
    public bool isBiraUnlocked;

    public PlayerDataToSave(PlayerData myPlayerData) 
    {
        myVolume = myPlayerData.GetMusicVolume();
        mySFXVolume = myPlayerData.GetSfxVolume();

        myQualityIndex = myPlayerData.GetVideoQualityIndex();
        myResIndex = myPlayerData.GetVideoResIndex();
        isfullScreenON = myPlayerData.GetFullScreenON();
        vSyncIndex = myPlayerData.GetVSync();

        // Apple Rush Data
        currentLevel = myPlayerData.GameMode[0].GetCurrentLevelIndex();

        actualFails = myPlayerData.GameMode[0].GetActualFails();
        totalFails = myPlayerData.GameMode[0].GetTotalFails();

        actualLevelTime = myPlayerData.GameMode[0].GetActualLevelTime();
        actualRunTotalTime = myPlayerData.GameMode[0].GetActualGameTotalTime();

        myBestTime = myPlayerData.GameMode[0].GetMyBestTime();
        myBestTimeFails = myPlayerData.GameMode[0].GetMyBestTimeFails();

        hasBeatenGame = myPlayerData.GameMode[0].GetHasBeatenGame();
        // ---------------------------------------------------------------------

        failCount = myPlayerData.GetFailCount();
        appleCollectCount = myPlayerData.GetAppleCollectCount();
        completeRunCount = myPlayerData.GetCompleteRunCount();
        standCount = myPlayerData.GetStandCount();
        badLandingCount = myPlayerData.GetBadLandingCount();

        isDogUnlocked = myPlayerData.isDogUnlocked;
        isDuckUnlocked = myPlayerData.isDuckUnlocked;
        isOwlUnlocked = myPlayerData.isOwlUnlocked;
        isParrotUnlocked = myPlayerData.isParrotUnlocked;
        isChickenUnlocked = myPlayerData.isChickenUnlocked;
        isFrogUnlocked = myPlayerData.isFrogUnlocked;
        isCatUnlocked = myPlayerData.isCatUnlocked;
        isGoatUnlocked = myPlayerData.isGoatUnlocked;
        isTurtleUnlocked = myPlayerData.isTurtleUnlocked;
        isSheepUnlocked = myPlayerData.isSheepUnlocked;
        isBunnyUnlocked = myPlayerData.isBunnyUnlocked;        
    }
}
