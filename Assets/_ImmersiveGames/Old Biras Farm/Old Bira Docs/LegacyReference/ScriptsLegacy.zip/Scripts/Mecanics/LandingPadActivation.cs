using UnityEngine;
using UnityEngine.UI;

public class LandingPadActivation : MonoBehaviour
{
    [Header("Materials")]
    [SerializeField] GameObject activeLandingPad;
    [SerializeField] GameObject inactiveLandingPad;

    [SerializeField] bool isActive = false;

    [Header("SetButtons")]
    [SerializeField] SwitchButton[] myButtons;

    float buttonsActivated = 0;

    // Start is called before the first frame update
    void Start()
    {        
        if (myButtons.Length == 0) 
        {
            isActive = true;
            ActivateSequence();
        }
        else DeActivateSequence();      
    }

    // Update is called once per frame
    void Update()
    {
        if (isActive) return;

        CheckActivationButtons();        
    }

    private void CheckActivationButtons()
    {
        buttonsActivated = 0;

        foreach (SwitchButton button in myButtons)
        {
            if (button.CheckActivationButton()) buttonsActivated++;
        }

        if (myButtons.Length == buttonsActivated)
        {
            ActivateSequence();
        }   
    }

    void ActivateSequence() 
    {
        activeLandingPad.SetActive(true);
        inactiveLandingPad.SetActive(false);
        gameObject.tag = "Finish";
        isActive = true;
    }

    void DeActivateSequence() 
    {
        activeLandingPad.SetActive(false);
        inactiveLandingPad.SetActive(true);
        gameObject.tag = "Untagged";
    }

    public float GetGoalProgression() { return (buttonsActivated / myButtons.Length); }
    public string GetGoalProgressionText() { return (buttonsActivated + "/" + myButtons.Length); }

    public bool GetActivationStatus() { return isActive; }
}
