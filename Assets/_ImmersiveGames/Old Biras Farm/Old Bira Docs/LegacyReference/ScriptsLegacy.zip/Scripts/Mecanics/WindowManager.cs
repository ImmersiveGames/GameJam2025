using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindowManager : MonoBehaviour
{
    enum MyDirection { outside, inside };
    
    [Header("Window Direction")]
    [SerializeField] MyDirection myDirection;


    [Header("Timer Settings")]
    [SerializeField] bool hasTimer;
    [SerializeField] float timeToOpen = 5f;
    [SerializeField] float timeToClose = 5f;

    [Header("Switch Buttons Settings")]
    [SerializeField] SwitchButton[] myButtons;

    Animator myAnimator;

    float currentTimeToOpen = 0f;
    float currentTimeToClose = 0f;

    bool isWindowOpen = false;

    // Start is called before the first frame update
    void Start()
    {
        myAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (hasTimer) OpenAndClose();
        
        else if (!hasTimer && !isWindowOpen)
        {
            CheckSwitchButtons();
        }
    }

    void CheckSwitchButtons()
    {
        int buttonsActivated = 0;

        foreach (SwitchButton button in myButtons)
        {
            if (button.CheckActivationButton()) buttonsActivated++;
        }

        if (myButtons.Length == buttonsActivated)
        {
            OpenWindow();
        }
    }

    private void OpenAndClose()
    {
        if (isWindowOpen)
        {
            currentTimeToClose += Time.deltaTime;

            if (currentTimeToClose > timeToClose)
            {
                CloseWindow();
                return;
            }            
        }

        if (!isWindowOpen)
        {
            currentTimeToOpen += Time.deltaTime;

            if (currentTimeToOpen > timeToOpen)
            {
                OpenWindow();
                return;
            }
        }
    }

    private void OpenWindow()
    {
        currentTimeToOpen = 0;
        isWindowOpen = true;
        myAnimator.SetBool(myDirection.ToString(), true);
        print("Abre a janela!");
    }

    private void CloseWindow()
    {
        currentTimeToClose = 0;
        isWindowOpen = false;
        myAnimator.SetBool(myDirection.ToString(), false);
    }
}
