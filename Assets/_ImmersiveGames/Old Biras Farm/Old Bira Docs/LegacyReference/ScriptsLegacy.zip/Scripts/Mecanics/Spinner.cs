using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spinner : MonoBehaviour
{
    [SerializeField] Vector3 rotationSpeed;

    // Update is called once per frame
    void Update()
    {
        Vector3 spinValue = rotationSpeed * Time.deltaTime;
        transform.Rotate(spinValue.x, spinValue.y, spinValue.z);
    }
}
