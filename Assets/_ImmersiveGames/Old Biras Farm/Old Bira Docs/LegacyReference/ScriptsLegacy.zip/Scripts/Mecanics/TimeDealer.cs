using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TimeDealer : MonoBehaviour
{
    [Header("Player References")]
    [SerializeField] PlayerData myPlayerData;
    
    [Header("Timer UI References")]
    [SerializeField] TMP_Text timerText;
    [SerializeField] Text finishLevelTime_Text;
    [SerializeField] Text finishLevelTime_Text_Shadow;
    [SerializeField] Text levelTime_Text;
    [SerializeField] Text levelTime_Text_Shadow;
    [SerializeField] Text totalTime_Text;
    [SerializeField] Text totalTime_Text_Shadow;

    [Header("Fails UI References")]
    [SerializeField] Text actualFailsCount_Text;
    [SerializeField] Text actualFailsCount_Text_Shadow;
    [SerializeField] Text totalFailsCount_Text;
    [SerializeField] Text totalFailsCount_Text_Shadow;

    float myTime = 0.0f;

    bool isTimerOn = false;

    int gameModeIndex;

    void Start()
    {
        gameModeIndex = myPlayerData.actualGameModeIndex;
    }

    // Update is called once per frame
    void Update()
    {
        if (isTimerOn) 
        {
            myTime += Time.deltaTime;            
            timerText.text = DisplayTime(myTime);
        }        
    }

    public void StartTimer() 
    {
        isTimerOn = true;
    }

    public void StopTimer() 
    {
        isTimerOn = false;
        myPlayerData.GameMode[gameModeIndex].AddTimeToScore(myTime);        
    }

    public void ResetTimer() 
    {
        myTime = 0.0f;
        myPlayerData.GameMode[gameModeIndex].ResetActualTryTime();
    }

    public void FinishLevelTime() 
    {
        finishLevelTime_Text.text = ("Finish Time: " + DisplayTime(myPlayerData.GameMode[gameModeIndex].GetActualTryTime()));
        finishLevelTime_Text_Shadow.text = finishLevelTime_Text.text;
        levelTime_Text.text = ("Level Time: " + DisplayTime(myPlayerData.GameMode[gameModeIndex].GetActualLevelTime()));
        levelTime_Text_Shadow.text = levelTime_Text.text;
        totalTime_Text.text = ("Total Time: " + DisplayTime(myPlayerData.GameMode[gameModeIndex].GetActualGameTotalTime()));
        totalTime_Text_Shadow.text = totalTime_Text.text;

        actualFailsCount_Text.text = ("Level Fails: " + myPlayerData.GameMode[gameModeIndex].GetActualFails());
        actualFailsCount_Text_Shadow.text = actualFailsCount_Text.text;
        totalFailsCount_Text.text = ("Total Fails: " + myPlayerData.GameMode[gameModeIndex].GetTotalFails());
        totalFailsCount_Text_Shadow.text = totalFailsCount_Text.text;
    }

    string DisplayTime(float timeToDisplay) 
    {
        int hour = Mathf.FloorToInt((timeToDisplay / 60f) / 60f);
        int minutes = Mathf.FloorToInt(((timeToDisplay / 60f / 60) - hour) * 60f);
        int seconds = Mathf.FloorToInt(((((timeToDisplay / 60f / 60) - hour) * 60f) - minutes) * 60f);

        string timeConverted = string.Format("{0:00}:{1:00}:{2:00}", hour, minutes, seconds);

        return timeConverted;
    }
}
