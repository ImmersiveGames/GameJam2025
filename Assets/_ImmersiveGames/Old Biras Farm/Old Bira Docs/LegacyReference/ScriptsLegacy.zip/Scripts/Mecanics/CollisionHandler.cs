using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionHandler : MonoBehaviour
{
    [Header("Cache References")]
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] GameObject crashVFX;
    [SerializeField] LevelLoader myLevelLoader;
    [SerializeField] GameObject eyelids;

    [Header("SFX")]
    [SerializeField] AudioClip crashSound;
    [SerializeField] [Range(0f, 10f)] float crashSfxVolume;

    AudioSource myAudioSource;
    Movement myMovement;

    bool isTransitioning = false;
    bool winState = false;
    bool loseState = false;

    void Start()
    {
        myAudioSource = GetComponent<AudioSource>();
        myMovement = GetComponent<Movement>();
        myLevelLoader = FindObjectOfType<LevelLoader>();

        if (eyelids != null) eyelids.SetActive(false);
    }

    void Update()
    {
        //Cheats();
    }

    void Cheats()
    {
        // Load Next Level
        if (Input.GetKeyDown(KeyCode.L)) 
        {
            myLevelLoader.LoadNextLevel();
        }

        // Disable Collisions - God Mode
        if (Input.GetKeyDown(KeyCode.C)) 
        {
            // toogle collisions
            isTransitioning = !isTransitioning;
            //Debug.Log("Colisions Enable = " + isTransitioning);
        }
    }

    void OnCollisionEnter(Collision other)
    {
        if (isTransitioning) { return; }

        switch (other.gameObject.tag)
        {
            case "Friendly":
                if (myMovement.HasFuel() == false)
                {
                    StartCrashSequence();
                }
                //Debug.Log("Colidiu com amigo");
                break;
            case "Finish":
                StartFinishSequence();
                //Debug.Log("Colidiu com final");
                break;
            default:
                StartCrashSequence();
                //Debug.Log("Colidiu com inimigo");
                break;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Fuel") 
        {
            ProcessFuel(other.gameObject.GetComponent<Fuel>().fuelValue);
        }
    }

    private void ProcessFuel(float fuelToAdd)
    {
        myMovement.AddFuel(fuelToAdd);
    }

    public void StartCrashSequence()
    {
        StopRocket();
        myPlayerData.FailCount();
        myAudioSource.PlayOneShot(crashSound, crashSfxVolume * myPlayerData.GetSfxVolume());
        Instantiate(crashVFX, this.transform.position, Quaternion.identity);
        if (eyelids != null) eyelids.SetActive(true);
        myLevelLoader.ToogleGameOverPanel(true);
        loseState = true;
    }

    void StartFinishSequence() 
    {
        StopRocket();
        winState = true;
        isTransitioning = true;
        myLevelLoader.ToogleFinishPanel(true);        
    }

    private void StopRocket()
    {
        isTransitioning = true;
        myMovement.StopThrusting();
        myMovement.StopRotating();
        myMovement.enabled = false;
        myAudioSource.Stop();
    }

    public bool WinState() { return winState; }
    public bool LoseState() { return loseState; }
    public void SetWinStateAtEndGame() { winState = true; }

}