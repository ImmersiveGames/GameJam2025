using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RainManager : MonoBehaviour
{
    [SerializeField][Range(0f, 0.5f)] float rainLightItensity;
    [SerializeField] GameObject myLight;
    [SerializeField] [Range(0f, 1f)] float rainChance;
    ParticleSystem myRain;

    [SerializeField] Transform target;
    [SerializeField] float cloudAltitude = 50f;
    [SerializeField] float cloudMinDist = 30f;

    // Start is called before the first frame update
    void Start()
    {
        myRain = GetComponent<ParticleSystem>();        
        RandomStartRaining();        
    }

    // Update is called once per frame
    void Update()
    {
        if (target == null) LookforTarget();
        if (target != null) CloudMovement();
    }

    void RandomStartRaining() 
    {
        if (myLight == null) myLight = GameObject.FindGameObjectWithTag("Sun");
                
        float rainValue = Random.Range(0f, 1f);

        if (rainValue <= rainChance)
        {
            myRain.Play();
            myLight.GetComponent<Light>().intensity = rainLightItensity;
        }
    }

    void LookforTarget()
    {
        var player = GameObject.FindGameObjectWithTag("Player");

        if (player != null) target = player.transform;
    }

    void CloudMovement() 
    {
        float currentAltitude = transform.position.y;
        float altitudeDist = currentAltitude - target.position.y;

        if (altitudeDist <= cloudMinDist) currentAltitude = target.position.y + cloudMinDist;
        else if (altitudeDist > cloudMinDist) currentAltitude = cloudAltitude;

        Vector3 movement = new Vector3(target.position.x, currentAltitude, 0f);
        
        transform.position = movement;
    }
}
