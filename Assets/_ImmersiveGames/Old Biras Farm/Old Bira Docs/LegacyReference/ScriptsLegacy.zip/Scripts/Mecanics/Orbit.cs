using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orbit : MonoBehaviour
{
    [SerializeField] Transform rotationCenter;

    [SerializeField] float angularSpeed;
    [SerializeField] float rotationRadius;
    [SerializeField] float angle = 0;
    float posx, posy;

    // Update is called once per frame
    void Update()
    {
        if (rotationCenter != null) { OrbitalMovement(); }
    }

    void OrbitalMovement()
    {
        posx = rotationCenter.position.x + Mathf.Cos(angle) * rotationRadius;
        posy = rotationCenter.position.y + Mathf.Sin(angle) * rotationRadius;
        transform.position = new Vector2(posx, posy);
        angle = angle + Time.deltaTime * angularSpeed;

        if (angle >= 360) { angle = 0; }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            this.GetComponent<Orbit>().enabled = false;
        }
    }
}
