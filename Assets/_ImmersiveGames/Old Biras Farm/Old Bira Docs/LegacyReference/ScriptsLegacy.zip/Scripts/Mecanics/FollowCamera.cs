using UnityEngine;

    public class FollowCamera : MonoBehaviour
    {
        [SerializeField] Transform target;
        [SerializeField] Vector3 distance;


        void Update()
        {
            if (target == null) LookforTarget();
        }


        // Update is called once per frame
        void LateUpdate()
        {
            transform.position = target.position + distance;
        }

        void LookforTarget()
        {
            var player = GameObject.FindGameObjectWithTag("Player");

            if(player != null) target = player.transform;           
        }
    }

