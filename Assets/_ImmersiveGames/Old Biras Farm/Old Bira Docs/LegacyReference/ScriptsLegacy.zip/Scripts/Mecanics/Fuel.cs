using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fuel : MonoBehaviour
{
    public float fuelValue;
    AudioSource myAudioSource;

    [SerializeField] PlayerData myPlayerData;
    [SerializeField] AudioClip fuelSound;
    [SerializeField] [Range(0f, 10f)] float fuelSoundVolume = 10f;

    void Start()
    {
        myAudioSource = GetComponent<AudioSource>();
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player") 
        {
            myAudioSource.PlayOneShot(fuelSound, fuelSoundVolume * myPlayerData.GetSfxVolume());
            gameObject.GetComponent<MeshRenderer>().enabled = false;
            gameObject.GetComponent<BoxCollider>().enabled = false;
            Destroy(gameObject, 5f);
        }        
    }    
}
