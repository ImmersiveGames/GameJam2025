using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchButton : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;

    [SerializeField] bool isActive = false;

    [SerializeField] AudioClip collectSFX;
    [SerializeField] [Range(0f, 5f)] float sfxVolume;
    [SerializeField] Color activeColor;
    [SerializeField] Color inactiveColor;
    AudioSource myAudioSource;
    MeshRenderer mr;

    // Start is called before the first frame update
    void Start()
    {
        mr = GetComponent<MeshRenderer>();
        myAudioSource = GetComponent<AudioSource>();
        ButtonCheck();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == "Player") 
        {
            if (isActive) return;

            isActive = !isActive;
            myPlayerData.AppleCollectCount();
            myAudioSource.PlayOneShot(collectSFX, sfxVolume * myPlayerData.GetSfxVolume());
            ButtonCheck();

            if(GetComponent<OrbitFollower>() != null) 
            {
                GetComponent<OrbitFollower>().enabled = false;
            }
        }
    }

    private void ButtonCheck()
    {
        if (isActive) mr.material.color = activeColor;
        if (!isActive) mr.material.color = inactiveColor;
    }

    public bool CheckActivationButton() 
    {
        return isActive;
    }    
}
