using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

public class LevelLoader : MonoBehaviour
{
    [Header("Player Data")]
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] AchievmentManager achievmentManager;

    [Header("UI References")]
    [SerializeField] bool isFinishScreen;
    [SerializeField] Text menuTitleText;
    [SerializeField] Text menuTitleText_Shadow;
    [SerializeField] GameObject nextLevel_BTN;
    [SerializeField] GameObject tryAgain_Btn;
    [SerializeField] GameObject mainMenu_Btn;
    [SerializeField] GameObject finishPanel;    
    [SerializeField] TimeDealer myTimeDealer;
    [SerializeField] float gameOverSecondsToWait;

    [Header("Pause Menu References")]
    [SerializeField] GameObject pauseMenuPanel;
    [SerializeField] GameObject pauseMenuFirstButton;
    [SerializeField] GameObject howToPlayPanel;
    [SerializeField] GameObject htpCloseButon;

    [Header("Loading References")]
    [SerializeField] int finishLevelIndex = 31;
    [SerializeField] GameObject loadingScreen;
    [SerializeField] Slider loadingBar;
    [SerializeField] Text loadingText;

    int gameModeIndex;
    bool isPaused = false;
    bool isGameOver = false;
    bool isHTP = false;

    PlayerInputSystem myInputSystem;

    void Start()
    {
        myInputSystem = new PlayerInputSystem();
        myInputSystem.PlayerControls.Enable();
        myInputSystem.PlayerControls.Start.performed += CheckInputPause;

        gameModeIndex = myPlayerData.actualGameModeIndex;

        if (achievmentManager == null) achievmentManager = GameObject.FindObjectOfType<AchievmentManager>();

        if (isFinishScreen)
        {
            GameBeaten();
        }
    }

    void Update()
    {
        //CheckInputPause();
    }

    public void LoadNextLevel()
    {
        myPlayerData.GameMode[gameModeIndex].AddTimeToScore(0f);
        myPlayerData.GameMode[gameModeIndex].ResetActualLevelTime();
        myPlayerData.GameMode[gameModeIndex].ResetActualFails();

        CheckLanding();
        SaveGame();

        StartCoroutine(LoadAsynchronously(GetNextLevelIndex()));
    }

    private int GetNextLevelIndex()
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int nextSceneIndex = currentSceneIndex + 1;

        int lastLevelIndex = myPlayerData.GameMode[gameModeIndex].GetLastLevelIndex();

        if (currentSceneIndex <= lastLevelIndex)
        {
            myPlayerData.GameMode[gameModeIndex].SetCurrentLevelIndex(nextSceneIndex);
        }

        else if (currentSceneIndex > lastLevelIndex)
        {
            nextSceneIndex = finishLevelIndex;
            myPlayerData.GameMode[gameModeIndex].SetCurrentLevelIndex(finishLevelIndex);
        }

        return nextSceneIndex;
    }

    public void ReloadLevel()
    {
        TooglePauseMenu(false);

        SaveGame();

        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        StartCoroutine(LoadAsynchronously(currentSceneIndex));
    }

    void GameBeaten() 
    {
        myPlayerData.GameMode[gameModeIndex].SetHasBeatenGame(true);
        myPlayerData.GameMode[gameModeIndex].CompleteRunCount();
        RegisterRecord();
        SaveGame();

        if (achievmentManager != null)
        {
            achievmentManager.CheckCompletedGameWithFails(myPlayerData.GameMode[gameModeIndex].GetTotalFails());
            achievmentManager.CheckCompletedGameWithTime(myPlayerData.GameMode[gameModeIndex].GetActualGameTotalTime());
            achievmentManager.CheckCompletedTimes();
        }            
    }

    public void BackToMainMenu() 
    {
        if (isFinishScreen)
        {
            myPlayerData.GameMode[gameModeIndex].SetCurrentLevelIndex(0);
        }

        TooglePauseMenu(false);

        StartCoroutine(LoadAsynchronously(0));    
    }

    IEnumerator LoadAsynchronously(int sceneIndex) 
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneIndex);

        loadingScreen.SetActive(true);

        while (!operation.isDone) 
        {
            float progress = Mathf.Clamp01(operation.progress / 0.9f);
            loadingBar.value = progress;
            loadingText.text = progress * 100f + "%";
            
            yield return null;
        }
    }

    public void ToogleFinishPanel(bool isActive)
    {        
        StopClock();
        isGameOver = true;
        GetNextLevelIndex();
        SaveGame();

        finishPanel.SetActive(isActive);
        menuTitleText.text = "Level Finished!";
        menuTitleText_Shadow.text = "Level Finished!";
        myTimeDealer.FinishLevelTime();
        CheckForAchievment();

        StartCoroutine(FinishPanel());
    }

    IEnumerator FinishPanel()
    {
        yield return new WaitForSeconds(gameOverSecondsToWait);
        
        nextLevel_BTN.SetActive(true);
        mainMenu_Btn.SetActive(true);
        SetFirstMenuButton(nextLevel_BTN);
    }

    void CheckForAchievment()
    {
        if (achievmentManager != null)
        {
            achievmentManager.CheckLevelCompleted();
        }
    }

    public void ToogleGameOverPanel(bool isActive) 
    {
        StopClock();
        isGameOver = true;
        myPlayerData.GameMode[gameModeIndex].CountFails();        
        
        finishPanel.SetActive(isActive);
        menuTitleText.text = "You Fail!";
        menuTitleText_Shadow.text = "You Fail!";
        myTimeDealer.FinishLevelTime();

        StartCoroutine(GameOverPanel());
    }

    IEnumerator GameOverPanel() 
    {
        yield return new WaitForSeconds(gameOverSecondsToWait);

        if (myPlayerData.GameMode[gameModeIndex].GetNoFailGame()) 
        {
            myPlayerData.GameMode[gameModeIndex].ResetTime();
            myPlayerData.GameMode[gameModeIndex].ResetActualFails();
            myPlayerData.GameMode[gameModeIndex].ResetTotalFails();
            myPlayerData.GameMode[gameModeIndex].SetCurrentLevelIndex(0);
            myPlayerData.GameMode[gameModeIndex].SetNoFailGame(false);

            

            mainMenu_Btn.SetActive(true);
            SetFirstMenuButton(mainMenu_Btn);
        }
        else if (myPlayerData.GameMode[gameModeIndex].GetNoFailGame() == false) 
        {
            tryAgain_Btn.SetActive(true);
            mainMenu_Btn.SetActive(true);
            SetFirstMenuButton(tryAgain_Btn);
        }

        SaveGame();
    }

    private void CheckInputPause(InputAction.CallbackContext context)
    {
        if (isGameOver || isFinishScreen) return;
        
        if (context.performed)
        {
            if (isHTP) { HowToPlayOFF(); }
            else 
            {
                isPaused = !isPaused;
                TooglePauseMenu(isPaused);                
            }
        }
    }

    void OnApplicationPause(bool pause)
    {
        if (pause == true) { TooglePauseMenu(true); }
        //Debug.Log("OnApplicationPause: " + pause);
    }

    void OnApplicationFocus(bool focus)
    {
        if (isGameOver) { return; }
        
        if (focus == false && !isFinishScreen) 
        {
            TooglePauseMenu(true);

        } 

        if (focus == true && !isFinishScreen) 
        {
            SetFirstMenuButton(pauseMenuFirstButton);
        }

        //Debug.Log("OnApplicationFocus: " + focus);
    }

    public void TooglePauseMenu(bool value) 
    {
        isPaused = value;      

        if (isPaused) 
        {
            Time.timeScale = 0f;
            pauseMenuPanel.SetActive(isPaused);
            SetFirstMenuButton(pauseMenuFirstButton);
        }
        if (!isPaused) 
        {
            pauseMenuPanel.SetActive(isPaused);          
            Time.timeScale = 1f;
        }        
    }

    public bool IsPaused() { return isPaused; }

    private void StopClock()
    {
        if (myTimeDealer == null) myTimeDealer = FindObjectOfType<TimeDealer>();
        myTimeDealer.StopTimer();        
    }

    public void RegisterRecord() 
    {
        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int lastLevel = myPlayerData.GameMode[gameModeIndex].GetLastLevelIndex();

        if (currentSceneIndex == lastLevel)
        {
            myPlayerData.GameMode[gameModeIndex].RegisterMyBestPlayTime();
        }
    }

    public void SaveGame() 
    {
        SaveSystem.SavePlayerInfo(myPlayerData);
    }

    void SetFirstMenuButton(GameObject button)
    {
        //EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(button);
    }

    public void HowToPlayON() 
    {
        isHTP = true;
        howToPlayPanel.SetActive(true);
        SetFirstMenuButton(htpCloseButon);
    }

    public void HowToPlayOFF()
    {        
        howToPlayPanel.SetActive(false);
        SetFirstMenuButton(pauseMenuFirstButton);
        isHTP = false;
    }

    void CheckLanding() 
    {
        Transform player = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
        float tolerance = 10;
        float value = player.rotation.z * 100;

        if (value <= -tolerance || value >= tolerance) 
        {
            myPlayerData.BadLandingCountCount();
        }
        else 
        {
            myPlayerData.StandCount();            
        }   
    }
}