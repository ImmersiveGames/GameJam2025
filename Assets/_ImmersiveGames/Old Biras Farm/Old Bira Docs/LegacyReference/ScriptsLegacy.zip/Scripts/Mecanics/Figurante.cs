using UnityEngine;

public class Figurante : MonoBehaviour
{
    [SerializeField] GameObject myHeadBone;
    [SerializeField] SkinData mySkinData;
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] bool isFather = false;

    GameObject myPlayer;    
    CollisionHandler myCollisionHandler;
    Animator myAnimator;

    bool isWin = false;
    bool isLoose = false;
    bool isFatherActive = false;
    

    // Start is called before the first frame update
    void Start()
    {
        myCollisionHandler = FindObjectOfType<CollisionHandler>();
        myPlayer = GameObject.FindGameObjectWithTag("Player");
        myAnimator = GetComponent<Animator>();
        DisableExtra();
    }

    // Update is called once per frame
    void Update()
    {       
        if (isFather && !isFatherActive) { FatherFinishScreen(); }
        if (isFather && isFatherActive) return;

        if (myCollisionHandler == null) myCollisionHandler = FindObjectOfType<CollisionHandler>();

        if (myAnimator != null) 
        {
            if (isLoose == false) LoseCheck();
            if (isWin == false) WinCheck();
        }
    }

    void LateUpdate()
    {
        if (isLoose == false && isWin == false && isFather == false) LookAtPlayer();
    }

    void LookAtPlayer() 
    {
        if (myPlayer == null) myPlayer = GameObject.FindGameObjectWithTag("Player");

        Transform target = myPlayer.transform;
        myHeadBone.transform.LookAt(target, Vector3.up);

    }

    private void WinCheck()
    {
        if (myCollisionHandler.WinState())
        {
            myAnimator.SetTrigger("Win");
            isWin = true;
        }
    }

    private void LoseCheck()
    {
        if (myCollisionHandler.LoseState())
        {
            myAnimator.SetTrigger("Lose");
            isLoose = true;
        }
    }

    // Checa se o figurante � a mesma skin do player e desabilita
    void DisableExtra() 
    {
        if (mySkinData == null) return;

        if (mySkinData.name == myPlayerData.myCurrentSkinData.name) 
        {
            gameObject.SetActive(false);
        } 
    }

    void FatherFinishScreen() 
    {
        myAnimator.SetTrigger("Father");
        isFatherActive = true;
    }
}
