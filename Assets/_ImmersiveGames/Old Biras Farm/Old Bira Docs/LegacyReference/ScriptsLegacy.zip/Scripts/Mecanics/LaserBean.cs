using System;
using UnityEngine;

public class LaserBean : MonoBehaviour
{
    [Header("Laser Settings")]
    LineRenderer lr;
    [SerializeField] int laserMaxDistance = 500;
    [SerializeField] Transform startPosition;
    
    [Header("Timer Settings")]
    [SerializeField] bool isTimerLaser;
    [SerializeField] float laserStartTime = 5f;
    [SerializeField] float laserDuration = 5f;

    [Header("Switch Buttons Settings")]
    [SerializeField] SwitchButton[] myButtons;
    
    float timeToStartLaser = 0f;
    float timeToStopLaser = 0f;

    bool hitPlayer = false;
    bool isLaserOn = true;
    

    // Start is called before the first frame update
    void Start()
    {
        lr = GetComponent<LineRenderer>();
        if (myButtons.Length == 0) 
        {
            isTimerLaser = true;
        } 
    }

    // Update is called once per frame
    void Update()
    {        
        if (isTimerLaser) StartStopLaser();
        else if (!isTimerLaser) 
        {
            if (isLaserOn) FireLaserBean();
            CheckSwitchButtons();
        }        
    }

    void CheckSwitchButtons()
    {
        int buttonsActivated = 0;

        foreach (SwitchButton button in myButtons)
        {
            if (button.CheckActivationButton()) buttonsActivated++;
        }

        if (myButtons.Length == buttonsActivated)
        {
            TurnLaserOff();
        }
    }

    private void StartStopLaser()
    {
        if (isLaserOn)
        {
            timeToStopLaser += Time.deltaTime;

            if (timeToStopLaser > laserDuration)
            {
                TurnLaserOff();
                return;
            }

            FireLaserBean();
        }

        if (!isLaserOn)
        {
            timeToStartLaser += Time.deltaTime;

            if (timeToStartLaser > laserStartTime)
            {
                TurnLaserOn();
                return;
            }
        }
    }

    private void TurnLaserOn()
    {
        timeToStartLaser = 0;
        isLaserOn = true;
        lr.enabled = true;
    }

    private void TurnLaserOff()
    {
        timeToStopLaser = 0;
        isLaserOn = false;
        lr.enabled = false;
    }

    private void FireLaserBean()
    {
        RaycastHit hit;
        lr.SetPosition(0, startPosition.position);
        if (Physics.Raycast(transform.position, -transform.up, out hit))
        {
            if (hit.collider)
            {
                lr.SetPosition(1, hit.point);
            }

            if (!hitPlayer && hit.transform.GetComponent<CollisionHandler>())
            {
                hit.transform.GetComponent<CollisionHandler>().StartCrashSequence();
                hitPlayer = true;
            }
        }
        else
        {
            lr.SetPosition(1, -transform.up * laserMaxDistance);
        }
       
    }
}
