using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ocillator : MonoBehaviour
{
    Vector3 startPosition;
    [SerializeField] Vector3 movementVector;
    float movementFactor = 0f;
    [SerializeField] float period = 2f;

    // Start is called before the first frame update
    void Start()
    {
        SetInitialReferences();
    }

    void SetInitialReferences()
    {
        startPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        Ocillation();
    }

    private void Ocillation()
    {
        if (period <= Mathf.Epsilon) { return; }

        float cycles = Time.time / period; // Continually growing over time

        const float tau = Mathf.PI * 2; // constant value of 6.283
        float rawSinWave = Mathf.Sin(cycles * tau); // going from -1 to 1

        movementFactor = (rawSinWave + 1f) / 2f; // recalculated to go from 0 to 1 so its clear

        Vector3 offset = movementVector * movementFactor;
        transform.position = startPosition + offset;
    }
}
