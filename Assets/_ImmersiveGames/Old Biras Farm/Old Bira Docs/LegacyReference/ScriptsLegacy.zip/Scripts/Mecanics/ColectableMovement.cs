using UnityEngine;

public class ColectableMovement : MonoBehaviour
{
    [SerializeField] int mySpeed;
    [SerializeField] Transform myDestination;
    [SerializeField] bool isSmallBox = false;
    [SerializeField] Animator avatarAnimator;

    SwitchButton mySwitchButton;
    Spinner mySpinner;
    Rigidbody myRigidbody;
    Collider myCollider;
    Ocillator myOcillator;
    
    bool canMove = true;


    // Start is called before the first frame update
    void Start()
    {
        if (myDestination == null) myDestination = GameObject.FindGameObjectWithTag("Box").transform;
        myRigidbody = GetComponent<Rigidbody>();
        myCollider = GetComponent<BoxCollider>();
        mySwitchButton = GetComponent<SwitchButton>();
        mySpinner = GetComponent<Spinner>();
        myOcillator = GetComponent<Ocillator>();
    }

    // Update is called once per frame
    void Update()
    {        
        if (mySwitchButton.CheckActivationButton() && canMove) 
        {          
            Move();
        }
    }

    void Move() 
    {
        Vector3 moveVector = myDestination.position - transform.position;                
        transform.position += moveVector * mySpeed * Time.deltaTime;

        if (isSmallBox)
        {
            this.transform.localScale = myDestination.localScale;
            
        }

        myOcillator.enabled = false;

    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Box")
        {
            canMove = false;
            mySpinner.enabled = false;
            myCollider.isTrigger = false;
            myRigidbody.isKinematic = false;
            avatarAnimator.SetTrigger("Colected");
        }
    }
}
