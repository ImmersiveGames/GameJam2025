using UnityEngine;

public class PlayerSpawner : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;
    GameObject playerPrefab;

    // Start is called before the first frame update
    void Start()
    {
        PlayerSpawn();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void PlayerSpawn() 
    {
        playerPrefab = myPlayerData.playerPrefab;
        Instantiate(playerPrefab, transform.position, Quaternion.identity);
    }
}
