using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class Movement : MonoBehaviour
{
    // Parameters - variaveis para ajustes
    [Header("Parameters")]
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] float mainThrust = 100f;
    [SerializeField] float rotationThrust = 100f;
    [SerializeField] float timeToStart = 2f;

    [Header("Sound Effects")]
    [SerializeField] AudioClip mainEngine;
    [SerializeField] [Range(0f, 10f)] float engineVolume = 10f;

    [Header("Fuel Settings")]
    [SerializeField] float maxFuel = 100f;
    [SerializeField] float thrustConsumption = 2f;
    [SerializeField] float rotationConsumption = 0.5f;
    [SerializeField] float currentFuel = 15f;

    [Header("VFX")]
    [SerializeField] ParticleSystem mainEngineVFX;
    [SerializeField] ParticleSystem rightEngineVFX;
    [SerializeField] ParticleSystem leftEngineVFX;

    // State
    bool canStart = false;
    bool hasFuel;
    bool isMoving = false;
    public bool canMove = true;

    // Cache - para componentes
    [SerializeField] Animator myFlayingPadAnimator;
    Rigidbody myRigidbody;
    AudioSource myAudioSorce;

    // Input System
    PlayerInputSystem myInputSystem;

    private void Awake()
    {
        SetInitialReferences();

        myInputSystem = new PlayerInputSystem();
        myInputSystem.PlayerControls.Enable();
    }

    private void Start()
    {
        StartCoroutine(ToggleCanStart());
    }

    void SetInitialReferences() 
    {
        myRigidbody = GetComponent<Rigidbody>();
        myAudioSorce = GetComponent<AudioSource>();
        hasFuel = true;
        canMove = true;
    }

    // Update is called once per frame
    void Update()
    {
        //CheckMovement();
    }

    void FixedUpdate()
    {
        if (!canStart) { return; }
        Thrust();
        Rotation();
    }

    IEnumerator ToggleCanStart() 
    {        
        yield return new WaitForSeconds(timeToStart);
        canStart = !canStart;
    }

    private void CheckMovement()
    {
        if (Time.timeScale == 0) { return; }

        if (hasFuel && canMove)
        {            
            ProcessRotation();
            CheckFuel();
        }
        else if (!hasFuel)
        {
            StopThrusting();
            StopRotating();
        }
    }

    void StartTimer() 
    {
        if (isMoving) return;

        TimeDealer timerDisplayUI = FindObjectOfType<TimeDealer>();
        timerDisplayUI.StartTimer();
        isMoving = true;
    }

    void Thrust() 
    {
        bool inputVector = myInputSystem.PlayerControls.Thrust.ReadValue<float>() > 0f;
        
        if (inputVector)
        {
            if (hasFuel && canMove)
            {
                StartTimer();
                StartThrusting();
                CheckFuel();
            }
        }
        else StopThrusting();
    }

    private void CheckFuel()
    {
        if (currentFuel <= 0f)
        {
            hasFuel = false;
        }
    }

    void StartThrusting()
    {
        myRigidbody.AddRelativeForce(Vector3.up * mainThrust * Time.deltaTime);
        currentFuel -= thrustConsumption * Time.deltaTime;

        Gamepad gamePad = Gamepad.current;
        if (gamePad != null) Gamepad.current.SetMotorSpeeds(0.25f, 0.25f);

        if (!myAudioSorce.isPlaying)
        {
            myAudioSorce.PlayOneShot(mainEngine, myPlayerData.GetSfxVolume() * engineVolume);
            if (myFlayingPadAnimator == null) return;
            myFlayingPadAnimator.SetFloat("RotationSpeed", 1f);
        }
        
        if (!mainEngineVFX.isPlaying)
        {
            if (mainEngineVFX == null) return;
            mainEngineVFX.Play();
        }        
    }

    public void StopThrusting()
    {
        Gamepad gamePad = Gamepad.current;
        if (gamePad != null) Gamepad.current.SetMotorSpeeds(0f, 0f);
        myAudioSorce.Stop();
        mainEngineVFX.Stop();
        if (myFlayingPadAnimator == null) return;
        myFlayingPadAnimator.SetFloat("RotationSpeed", 0f);
        
    }

    void Rotation() 
    {
        float leftRotation = myInputSystem.PlayerControls.RotateLeft.ReadValue<float>();
        float rightRotation = myInputSystem.PlayerControls.RotateRight.ReadValue<float>();

        //Debug.Log("Left Rotation" + leftRotation);
        //Debug.Log("Right Rotation" + rightRotation);

        if (leftRotation > 0.15f)
        {
            StartTimer();
            RotateLeft();
            currentFuel -= rotationConsumption * Time.deltaTime;
        }

        else if (rightRotation > 0.15f)
        {
            StartTimer();
            RotateRight();
            currentFuel -= rotationConsumption * Time.deltaTime;
        }

        else
        {
            StopRotating();
        }
    }

    void ProcessRotation() 
    {
        float getRotation = Input.GetAxis("Rotation");

        if (Input.GetKey(KeyCode.A) ||
            Input.GetKey(KeyCode.LeftArrow) ||
            getRotation < 0f)
        {
            StartTimer();
            RotateLeft();
            currentFuel -= rotationConsumption * Time.deltaTime;
        }

        else if (Input.GetKey(KeyCode.D) ||
                 Input.GetKey(KeyCode.RightArrow) ||
                 getRotation > 0f)
        {
            StartTimer();
            RotateRight();
            currentFuel -= rotationConsumption * Time.deltaTime;
        }

        else
        {                                
            StopRotating();
        }
     
    }

    void RotateLeft()
    {
        ApplyRotation(rotationThrust);
       
        if (!rightEngineVFX.isPlaying)
        {
            if (rightEngineVFX == null) return;
            rightEngineVFX.Play();
        }
    } 

    void RotateRight()
    {
        ApplyRotation(-rotationThrust);
     
        if (!leftEngineVFX.isPlaying)
        {
            if (leftEngineVFX == null) return;
            leftEngineVFX.Play();
        }
    }

    void ApplyRotation(float rotationThisFrame)
    {
        myRigidbody.freezeRotation = true; // freeze rotation for manual rotation
        transform.Rotate(Vector3.forward * rotationThisFrame * Time.deltaTime);
        myRigidbody.freezeRotation = false; //unfreeze rotation
    }

    public void StopRotating()
    {
        rightEngineVFX.Stop();
        leftEngineVFX.Stop();
    }

    public bool HasFuel() 
    {
        return hasFuel;
    }

    public void AddFuel(float fuelToAdd) 
    {
        currentFuel += fuelToAdd;        

        if (currentFuel > maxFuel) 
        {
            currentFuel = maxFuel;
        }       
    }    

    public float CurrentFuelValue() { return currentFuel; }

}