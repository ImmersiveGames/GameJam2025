using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MilkSpawner : MonoBehaviour
{
    [SerializeField] GameObject milkBottlePrefab;
    [SerializeField] int maxSpawn;
    [SerializeField] Transform spawnPosition;
    [SerializeField] float timeToSpawn;
    [SerializeField] Animator myAnimator;
    [SerializeField] LayerMask milkLayer;
    [SerializeField] float checkDistance = 0.2f;
    [SerializeField] GameObject bottleGPX;
    [SerializeField] GameObject availbleSign;
    [SerializeField] Material canSpawnMat;
    [SerializeField] Material cantSpawnMat;

    bool isSpawning;
    bool toogleBottle = false;
    bool canSpawn = true;
    int spawnedBottles = 0;


    // Start is called before the first frame update
    void Start()
    {
        myAnimator = GetComponent<Animator>();
        CheckIfCanSpawn();
    }

    // Update is called once per frame
    void Update()
    {        
        ISMilkCollected();        
    }

    public void SpawnMilkBottle() 
    {
        GameObject milk = Instantiate(milkBottlePrefab, spawnPosition.position, Quaternion.identity);
        spawnedBottles++;
        CheckIfCanSpawn();
        isSpawning = false;
        Debug.Log("Garrafa #: " + spawnedBottles + " Pode spawnar: " + canSpawn);        
    }

    void CheckIfCanSpawn() 
    {
        if (spawnedBottles < maxSpawn) 
        { 
            canSpawn = true;
            availbleSign.GetComponent<MeshRenderer>().material = canSpawnMat;
        }
        if (spawnedBottles >= maxSpawn) 
        {
            availbleSign.GetComponent<MeshRenderer>().material = cantSpawnMat;
            canSpawn = false;
        }        
    }

    void ISMilkCollected() 
    {
        if (canSpawn == false) { return; }

        Collider[] milk = Physics.OverlapSphere(spawnPosition.position, checkDistance, milkLayer);

        if (!isSpawning && milk.Length == 0)
        {
            isSpawning = true;
            StartCoroutine(StartSpawnProcess());
        }

        else if (isSpawning && milk.Length > 0)
        {
            StopAllCoroutines();
            isSpawning = false;
        }
    }

    IEnumerator StartSpawnProcess() 
    {
        myAnimator.SetTrigger("Start");
        yield return new WaitForSeconds(timeToSpawn);
        myAnimator.SetTrigger("End");
    }

    public void ToggleMilkBottle() 
    {
        toogleBottle = !toogleBottle;
        bottleGPX.gameObject.SetActive(toogleBottle);
    }
}
