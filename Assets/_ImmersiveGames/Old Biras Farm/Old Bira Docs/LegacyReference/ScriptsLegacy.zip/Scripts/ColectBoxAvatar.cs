using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColectBoxAvatar : MonoBehaviour
{
    [SerializeField] CollisionHandler myPlayer;
    [SerializeField] Animator avatarAnim;
    [SerializeField] GameObject myFlag;
    [SerializeField] Material allCollected;
    [SerializeField] Material notCollected;
    [SerializeField] LandingPadActivation landingPad;

    bool isWin = false;
    bool isLoose = false;

    // Start is called before the first frame update
    void Start()
    {
        myPlayer = FindObjectOfType<CollisionHandler>();
        myFlag.GetComponent<MeshRenderer>().material = notCollected;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        if (isLoose == true || isWin == true) return;
        CheckState();
    }

    void CheckState() 
    {
        if (landingPad.GetActivationStatus())
        {
            //Debug.Log(landingPad.GetActivationStatus());
            myFlag.GetComponent<MeshRenderer>().material = allCollected;
        }

        if (myPlayer == null) myPlayer = FindObjectOfType<CollisionHandler>(); 
        if (myPlayer == null) return;
        
        if (myPlayer.WinState()) 
        {
            isWin = true;
            avatarAnim.SetTrigger("Win");
        }

        if (myPlayer.LoseState()) 
        {
            isLoose = true;
            avatarAnim.SetTrigger("Loose");
        }
    }
}
