using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VolumeSlider : MonoBehaviour
{
    [SerializeField] Slider musicSlider;
    [SerializeField] Slider sfxSlider;
    AudioManager myAudioManager;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (myAudioManager == null)
        {
            myAudioManager = FindObjectOfType<AudioManager>();
            musicSlider.value = myAudioManager.MyActualMusicVolume();
            sfxSlider.value = myAudioManager.MyActualSfxVolume();
        }
    }

    public void SetMusicVolume() 
    {
        float myVolume = musicSlider.value;
        myAudioManager.SetMusicVolume(myVolume);
    }

    public void SetSfxVolume()
    {
        float myVolume = sfxSlider.value;
        myAudioManager.SetSfxVolume(myVolume);
    }
}
