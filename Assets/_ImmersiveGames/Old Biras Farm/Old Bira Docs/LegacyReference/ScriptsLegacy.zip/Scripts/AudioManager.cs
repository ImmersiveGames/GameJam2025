using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [Header("Player Info")]
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] bool isFinishScreen = false;

    [Header("Music")]
    [SerializeField] AudioClip[] myMusics;    

    [Header("State Musics")]
    [SerializeField] AudioClip[] winMusic;
    [SerializeField] AudioClip[] looseMusic;
    
    [Header("SFX")]
    [SerializeField] AudioClip menuSound;
    [SerializeField] [Range(0f, 10f)] float menuSoundVolume;

    AudioSource myAudioSource;
    CollisionHandler myCollisionHandler;

    int musicIndex;
    bool isWinOrLoose = false;
    

    // Start is called before the first frame update
    void Start()
    {
        myAudioSource = GetComponent<AudioSource>();       

        musicIndex = Random.Range(0, myMusics.Length);
    }

    // Update is called once per frame
    void Update()
    {
        if (myCollisionHandler == null) 
        {
            myCollisionHandler = GameObject.FindGameObjectWithTag("Player").GetComponent<CollisionHandler>();
        }

        SetVolumeAtStart();
        ChooseMusicToPlay();        
    }

    void ChooseMusicToPlay() 
    {
        if (isFinishScreen) 
        {
            return;
        }

        if (myCollisionHandler.WinState() && !isWinOrLoose)
        {
            PlayMusic(winMusic[musicIndex], false);
            SetVolumeAtStart();
            isWinOrLoose = true;
        }

        if (myCollisionHandler.LoseState() && !isWinOrLoose)
        {
            PlayMusic(looseMusic[musicIndex], false);
            SetVolumeAtStart();
            isWinOrLoose = true;
        }

        if (myAudioSource.isPlaying == false && !isWinOrLoose) 
        {
            PlayMusic(myMusics[musicIndex], true);
            SetVolumeAtStart();
        }
    }

    void SetVolumeAtStart()
    {        
        myAudioSource.volume = myPlayerData.GetMusicVolume();        
    }

    void PlayMusic(AudioClip audioClipToPlay, bool hasLoop) 
    {
        myAudioSource.clip = audioClipToPlay;
        myAudioSource.loop = hasLoop;
        myAudioSource.Play();
    }

    void StopMusic() 
    {
        myAudioSource.Stop();
    }

    void PlaySFX(AudioClip sfx, float volume) 
    {
        AudioSource.PlayClipAtPoint(sfx, gameObject.transform.position, volume);
        //myAudioSource.PlayOneShot(sfx, volume);
    }

    public void SetMusicVolume(float volume) 
    {
        myAudioSource.volume = volume;
        myPlayerData.SetMusicVolume(volume);
    }

    public float MyActualMusicVolume() { return myPlayerData.GetMusicVolume(); }

    public void SetSfxVolume(float volume) { myPlayerData.SetSfxVolume(volume); }

    public float MyActualSfxVolume() { return myPlayerData.GetSfxVolume(); }

    public void PlayMenuSFX() { PlaySFX(menuSound, menuSoundVolume * myPlayerData.GetSfxVolume()); }
}
