using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkinManager : MonoBehaviour
{
    [SerializeField] PlayerData playerData;
    [SerializeField] SkinData dog, duck, owl, parrot, chicken, frog, cat, goat, turtle, sheep, bunny;

    [SerializeField] GameObject unlockedPanel;
    [SerializeField] Image avatarImage;

    [SerializeField] bool isFinishScreen = false;

    // Start is called before the first frame update
    void Start()
    {
        if (!isFinishScreen) CheckSkinsUnlocker();
        
        if (isFinishScreen) 
        { 
            UnlockASkin();  
        }
    }

    void CheckSkinsUnlocker() 
    {
        dog.isUnlocked = playerData.isDogUnlocked;
        duck.isUnlocked = playerData.isDuckUnlocked;
        owl.isUnlocked = playerData.isOwlUnlocked;
        parrot.isUnlocked = playerData.isParrotUnlocked;
        chicken.isUnlocked = playerData.isChickenUnlocked;
        frog.isUnlocked = playerData.isFrogUnlocked;
        cat.isUnlocked = playerData.isCatUnlocked;
        goat.isUnlocked = playerData.isGoatUnlocked;
        turtle.isUnlocked = playerData.isTurtleUnlocked;
        sheep.isUnlocked = playerData.isSheepUnlocked;
        bunny.isUnlocked = playerData.isBunnyUnlocked;
    }

    void UnlockASkin() 
    {
        if (dog.isUnlocked == false) 
        {
            unlockedPanel.SetActive(true);
            dog.isUnlocked = true;
            playerData.isDogUnlocked = true;
            avatarImage.sprite = dog.myAvatar;
        }

        else if(duck.isUnlocked == false) 
        {
            unlockedPanel.SetActive(true);
            duck.isUnlocked = true;
            playerData.isDuckUnlocked = true;
            avatarImage.sprite = duck.myAvatar;
        }

        else if (owl.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            owl.isUnlocked = true;
            playerData.isOwlUnlocked = true;
            avatarImage.sprite = owl.myAvatar;
        }

        else if (parrot.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            parrot.isUnlocked = true;
            playerData.isParrotUnlocked = true;
            avatarImage.sprite = parrot.myAvatar;
        }

        else if (chicken.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            chicken.isUnlocked = true;
            playerData.isChickenUnlocked = true;
            avatarImage.sprite = chicken.myAvatar;
        }

        else if (frog.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            frog.isUnlocked = true;
            playerData.isFrogUnlocked = true;
            avatarImage.sprite = frog.myAvatar;            
        }

        else if (cat.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            cat.isUnlocked = true;
            playerData.isCatUnlocked = true;
            avatarImage.sprite = cat.myAvatar;            
        }

        else if (goat.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            goat.isUnlocked = true;
            playerData.isGoatUnlocked = true;
            avatarImage.sprite = goat.myAvatar;
        }

        else if (turtle.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            turtle.isUnlocked = true;
            playerData.isTurtleUnlocked = true;
            avatarImage.sprite = turtle.myAvatar;
        }

        else if (sheep.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            sheep.isUnlocked = true;
            playerData.isSheepUnlocked = true;
            avatarImage.sprite = sheep.myAvatar;
        }

        else if (bunny.isUnlocked == false)
        {
            unlockedPanel.SetActive(true);
            bunny.isUnlocked = true;
            playerData.isBunnyUnlocked = true;
            avatarImage.sprite = bunny.myAvatar;
        }

        else
        {
            unlockedPanel.SetActive(false);
        }

        SaveSystem.SavePlayerInfo(playerData);
    }
}
