using UnityEngine;
using UnityEngine.UI;

public class ResumeButton : MonoBehaviour
{
    [SerializeField] GameModeLevels gameModeData;    

    // Start is called before the first frame update
    void Start()
    {
        int actualLevel = gameModeData.GetCurrentLevelIndex();

        if (actualLevel >= gameModeData.GetFirstLevelIndex() &&
            actualLevel <= gameModeData.GetLastLevelIndex()) 
        {
            gameObject.GetComponent<Button>().interactable = true;
        }
    }
}
