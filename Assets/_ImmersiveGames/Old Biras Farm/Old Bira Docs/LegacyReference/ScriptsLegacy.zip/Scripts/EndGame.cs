using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGame : MonoBehaviour
{
    CollisionHandler myCollisionHandler;
    // Start is called before the first frame update
    void Start()
    {
        SetCollisionHandler();
    }

    private void SetCollisionHandler()
    {
        myCollisionHandler = FindObjectOfType<CollisionHandler>();
    }

    // Update is called once per frame
    void Update()
    {
        if (myCollisionHandler == null) SetCollisionHandler();
        myCollisionHandler.SetWinStateAtEndGame();

    }
}
