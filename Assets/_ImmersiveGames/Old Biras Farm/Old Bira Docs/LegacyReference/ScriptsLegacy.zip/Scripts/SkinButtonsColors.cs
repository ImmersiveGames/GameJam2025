using UnityEngine;
using UnityEngine.UI;

public class SkinButtonsColors : MonoBehaviour
{
    [SerializeField] PlayerData playerData;
    [SerializeField] Button[] skinButtons;
    [SerializeField] Color selectedColor;
    [SerializeField] Color normalColor;

    Button selectedButton;

    // Start is called before the first frame update
    void Start()
    {
        SetInicialSelectedButton();
    }

    void SetInicialSelectedButton() 
    {
        int index = playerData.myCurrentSkinData.buttonIndex;
        selectedButton = skinButtons[index];
        ColorBlock cb = selectedButton.colors;
        cb.normalColor = selectedColor;
        selectedButton.colors = cb;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetButtonColors(int index) 
    {
        ColorBlock cb = selectedButton.colors;

        if (selectedButton != null) 
        {            
            cb.normalColor = normalColor;
            selectedButton.colors = cb;
        }

        selectedButton = skinButtons[index];

        cb.normalColor = selectedColor;
        selectedButton.colors = cb;
    }
}
