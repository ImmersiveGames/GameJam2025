
using UnityEngine;

[CreateAssetMenu(fileName = "New PlayerData", menuName = "PlayerData")]
public class PlayerData : ScriptableObject
{    
    [SerializeField] public SkinData myCurrentSkinData;
    public GameObject playerPrefab;

    [SerializeField] public GameModeLevels[] GameMode;
    [SerializeField] public int actualGameModeIndex;
    int currentLevel;

    //Options Settings
    [SerializeField] float musicVolume;
    [SerializeField] float sfxVolume;
    int vQualityIndex;
    int vResIndex;
    bool isFullScreenON;
    int vSyncIndex = 0;

    // Achievments
    int failCount;
    int appleCollectCount;
    int completeRunCount;
    int standCount;
    int badLandingCount;

    // Skins Unlocked
    public bool isDogUnlocked = false;
    public bool isDuckUnlocked = false;
    public bool isOwlUnlocked = false;
    public bool isParrotUnlocked = false;
    public bool isChickenUnlocked = false;
    public bool isFrogUnlocked = false;
    public bool isCatUnlocked = false;
    public bool isGoatUnlocked = false;
    public bool isTurtleUnlocked = false;
    public bool isSheepUnlocked = false;
    public bool isBunnyUnlocked = false;

    //Skin
    public void SetMySkin() 
    {
        playerPrefab = myCurrentSkinData.skinColorPrefab[myCurrentSkinData.selectedSkin];
    }

    // Volume
    public float GetMusicVolume() { return musicVolume; }
    public void SetMusicVolume(float volume) { musicVolume = volume; }
    public float GetSfxVolume() { return sfxVolume; }
    public void SetSfxVolume(float volume) { sfxVolume = volume; }

    // Video
    public void SetVideoQualityIndex(int index) { vQualityIndex = index; }
    public int GetVideoQualityIndex() { return vQualityIndex; }
    public void SetVideoResIndex(int index) { vResIndex = index; }
    public int GetVideoResIndex() { return vResIndex; }
    public void SetFullScreenON(bool value) { isFullScreenON = value; }
    public bool GetFullScreenON() { return isFullScreenON; }
    public void SetVSync(int value) { vSyncIndex = value; }
    public int GetVSync() { return vSyncIndex; }

    // Achievements Counts
    public void FailCount() 
    { 
        foreach (GameModeLevels gm in GameMode) 
        {
            failCount += gm.GetTotalFails();
        } 
    }
    public int GetFailCount() { FailCount(); return failCount; }
    public void SetFailCount(int value) { failCount = value; }

    public void AppleCollectCount() { appleCollectCount++; }
    public int GetAppleCollectCount() { return appleCollectCount; }
    public void SetAppleCollectCount(int value) { appleCollectCount = value; }

    public void CompleteRunCount() { completeRunCount++; }
    public int GetCompleteRunCount() { return completeRunCount; }
    public void SetCompleteRunCount(int value) { completeRunCount = value; }

    public void StandCount() { standCount++; }
    public int GetStandCount() { return standCount; }
    public void SetStandCount(int value) { standCount = value; }

    public void BadLandingCountCount() { badLandingCount++; }
    public int GetBadLandingCount() { return badLandingCount; }
    public void SetBadLandingCount(int value) { badLandingCount = value; }
}
