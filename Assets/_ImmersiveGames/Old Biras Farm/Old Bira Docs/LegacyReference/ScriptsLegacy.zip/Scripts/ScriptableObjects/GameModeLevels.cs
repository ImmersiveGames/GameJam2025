using UnityEngine;
using UnityEngine.SceneManagement;

[CreateAssetMenu(fileName = "New GameModeLevels", menuName = "Game Mode Levels")]
public class GameModeLevels : ScriptableObject
{
    [SerializeField] string gameModeName;
    [SerializeField] int firstLevelIndex;
    [SerializeField] int lastLevelIndex;
    
    int currentLevelIndex;
    int actualFails;
    int totalFails;
    int myBestTimeFails;
    int completeRunCount;

    float actualTryTime;        // Tempo da tentativa atual
    float actualLevelTime;      // Tempo total no level
    float actualGameTotalTime;  // Tempo total no jogo
    float myBestTime;

    bool isNewRecord = false;
    bool isNoFailGame = false;
    bool isGameBeaten = false;

    public string GetGameModeName() { return gameModeName; }
    public int GetFirstLevelIndex() { return firstLevelIndex; }
    public int GetLastLevelIndex() { return lastLevelIndex; }
    
    public int GetCurrentLevelIndex() { return currentLevelIndex; }
    public void SetCurrentLevelIndex(int value) { currentLevelIndex = value; }

    // Fail Functions
    public int GetActualFails() { return actualFails; }
    public void SetActualFails(int value) { actualFails = value; }
    public int GetTotalFails() { return totalFails; }
    public void SetTotalFails(int value) { totalFails = value; }
    public void CountFails() { actualFails++; totalFails++; }
    public void ResetActualFails() { actualFails = 0; }
    public void ResetTotalFails() { totalFails = 0; }
    //---------------------------------------------------------------------------------------

    // Time Functions
    public void AddTimeToScore(float time)
    {
        actualTryTime = time;
        actualLevelTime += time;
        actualGameTotalTime += time;
    }

    public float GetActualTryTime() { return actualTryTime; }
    public void ResetActualTryTime() { actualTryTime = 0f; }

    public float GetActualLevelTime() { return actualLevelTime; }
    public void LoadActualLevelTime(float time) { actualLevelTime = time; }
    public void ResetActualLevelTime() { actualLevelTime = 0f; }

    public float GetActualGameTotalTime() { return actualGameTotalTime; }
    public void LoadActuatRunTotalTime(float time) { actualGameTotalTime = time; }
    public void ResetActuatRunTotalTime() { actualGameTotalTime = 0f; isNewRecord = false; }

    public void ResetTime() 
    { 
        actualTryTime = 0f; 
        actualLevelTime = 0f;
        actualGameTotalTime = 0;
        isNewRecord = false;
    }
    //---------------------------------------------------------------------------------------

    // Record Functions
    public float GetMyBestTime() { return myBestTime; }
    public int GetMyBestTimeFails() { return myBestTimeFails; }

    public void RegisterMyBestPlayTime()
    {
        if (GetMyBestTime() == 0 || GetActualGameTotalTime() < GetMyBestTime())
        {
            myBestTime = GetActualGameTotalTime();
            myBestTimeFails = GetTotalFails();
            isNewRecord = true;
        }
        else isNewRecord = false;
    }

    public void LoadMyBestRunTime(float time) { myBestTime = time; }
    public void LoadMyBestRunFails(int fails) { myBestTimeFails = fails; }
    public bool GetIsNewRecord() { return isNewRecord; }
    public void ResetMyRecordTime() { myBestTime = 0f; myBestTimeFails = 0; }
    //---------------------------------------------------------------------------------------

    // No Fail Game
    public void SetNoFailGame(bool value) { isNoFailGame = value; }
    public bool GetNoFailGame() { return isNoFailGame; }
    //---------------------------------------------------------------------------------------

    // Game has been beaten?
    public void SetHasBeatenGame(bool value) { isGameBeaten = value; }
    public bool GetHasBeatenGame() { return isGameBeaten; }
    //---------------------------------------------------------------------------------------

    public void CompleteRunCount() { completeRunCount++; }
    public int GetCompleteRunCount() { return completeRunCount; }
}
