using UnityEngine;

[CreateAssetMenu(fileName = "New SkinData", menuName = "Skin Data")]
public class SkinData : ScriptableObject
{
    [SerializeField] public string skinName;
    [SerializeField] public Sprite myAvatar;
    [SerializeField] public Sprite myLockedAvatar;
    [SerializeField] public GameObject[] skinColorPrefab;
    [SerializeField] public GameObject skinPlataformPrefab;
    [SerializeField] public int selectedSkin;
    [SerializeField] public bool isUnlocked;
    [SerializeField] public int buttonIndex;
}
