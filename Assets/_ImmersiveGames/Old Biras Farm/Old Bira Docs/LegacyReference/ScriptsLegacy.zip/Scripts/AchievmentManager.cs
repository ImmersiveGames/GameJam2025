using Steamworks;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AchievmentManager : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;

    bool isApple10 = false;
    bool isApple100 = false;
    bool isApple1000 = false;

    bool isFail10 = false;
    bool isFail100 = false;
    bool isFail1000 = false;    

    // Start is called before the first frame update
    void Start()
    {
        CheckCompletedTimes();
    }

    // Update is called once per frame
    void Update()
    {
        if (SteamManager.Initialized) 
        {
            CheckAppleCounts();
            CheckFailCounts();
            CheckLandingCounts();
        }        
    }

    void CheckAppleCounts() 
    {
        if (myPlayerData.GetAppleCollectCount() >= 10 && isApple10 == false) 
        {
            SteamUserStats.GetAchievement("APPLE_COLLECT_10", out bool isCompleted);
            
            if (!isCompleted) 
            {
                SteamUserStats.SetAchievement("APPLE_COLLECT_10");
                SteamUserStats.StoreStats();                
            }

            isApple10 = true;
        }

        if (myPlayerData.GetAppleCollectCount() >= 100 && isApple100 == false)
        {
            SteamUserStats.GetAchievement("APPLE_COLLECT_100", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("APPLE_COLLECT_100");
                SteamUserStats.StoreStats();
            }

            isApple100 = true;
        }

        if (myPlayerData.GetAppleCollectCount() >= 1000 && isApple1000 == false)
        {
            SteamUserStats.GetAchievement("APPLE_COLLECT_1000", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("APPLE_COLLECT_1000");
                SteamUserStats.StoreStats();
            }

            isApple1000 = true;
        }
    }

    void CheckFailCounts() 
    {
        if (myPlayerData.GetFailCount() >= 10 && isFail10 == false)
        {
            SteamUserStats.GetAchievement("FAIL_COUNT_10", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("FAIL_COUNT_10");
                SteamUserStats.StoreStats();
            }

            isFail10 = true;
        }

        if (myPlayerData.GetFailCount() >= 100 && isFail100 == false)
        {
            SteamUserStats.GetAchievement("FAIL_COUNT_100", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("FAIL_COUNT_100");
                SteamUserStats.StoreStats();
            }

            isFail100 = true;
        }

        if (myPlayerData.GetFailCount() >= 1000 && isFail1000 == false)
        {
            SteamUserStats.GetAchievement("FAIL_COUNT_1000", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("FAIL_COUNT_1000");
                SteamUserStats.StoreStats();
            }

            isFail1000 = true;
        }
    }

    void CheckLandingCounts() 
    {
        if (myPlayerData.GetStandCount() >= 50)
        {
            SteamUserStats.GetAchievement("LANDING_STAND", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("LANDING_STAND");
                SteamUserStats.StoreStats();
            }
        }

        if (myPlayerData.GetBadLandingCount() >= 50)
        {
            SteamUserStats.GetAchievement("LANDING_BAD", out bool isCompleted);

            if (!isCompleted)
            {
                SteamUserStats.SetAchievement("LANDING_BAD");
                SteamUserStats.StoreStats();
            }
        }
    }

    public void CheckLevelCompleted() 
    {
        if (SteamManager.Initialized) 
        {
            int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;

            if (currentSceneIndex == 10)
            {
                SteamUserStats.GetAchievement("LEVEL_10_COMPLETED", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("LEVEL_10_COMPLETED");
                    SteamUserStats.StoreStats();
                }
            }

            else if (currentSceneIndex == 20)
            {
                SteamUserStats.GetAchievement("LEVEL_20_COMPLETED", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("LEVEL_20_COMPLETED");
                    SteamUserStats.StoreStats();
                }
            }

            else if (currentSceneIndex == 30)
            {
                SteamUserStats.GetAchievement("LEVEL_30_COMPLETED", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("LEVEL_30_COMPLETED");
                    SteamUserStats.StoreStats();
                }
            }
        }
    }

    public void CheckCompletedGameWithFails(int fails) 
    {
        if (SteamManager.Initialized) 
        {
            if (fails <= 10)
            {
                SteamUserStats.GetAchievement("COMPLETED_10_FAILS", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_10_FAILS");
                    SteamUserStats.StoreStats();
                }
            }

            if (fails <= 5)
            {
                SteamUserStats.GetAchievement("COMPLETED_5_FAILS", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_5_FAILS");
                    SteamUserStats.StoreStats();
                }
            }

            if (fails == 0)
            {
                SteamUserStats.GetAchievement("COMPLETED_0_FAILS", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_0_FAILS");
                    SteamUserStats.StoreStats();
                }
            }
        }       
    }

    public void CheckCompletedGameWithTime(float time) 
    {
        if (SteamManager.Initialized)
        {
            if (time <= 900f)
            {
                SteamUserStats.GetAchievement("COMPLETED_15_TIME", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_15_TIME");
                    SteamUserStats.StoreStats();
                }
            }

            if (time <= 1200f)
            {
                SteamUserStats.GetAchievement("COMPLETED_20_TIME", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_20_TIME");
                    SteamUserStats.StoreStats();
                }
            }

            if (time <= 1800f)
            {
                SteamUserStats.GetAchievement("COMPLETED_30_TIME", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_30_TIME");
                    SteamUserStats.StoreStats();
                }
            }
        }
    }

    public void CheckCompletedTimes()
    {
        if (SteamManager.Initialized)
        {
            if (myPlayerData.GetCompleteRunCount() >= 10)
            {
                SteamUserStats.GetAchievement("COMPLETED_10_GAME", out bool isCompleted);

                if (!isCompleted)
                {
                    SteamUserStats.SetAchievement("COMPLETED_10_GAME");
                    SteamUserStats.StoreStats();
                }
            }
        }
    }
}
