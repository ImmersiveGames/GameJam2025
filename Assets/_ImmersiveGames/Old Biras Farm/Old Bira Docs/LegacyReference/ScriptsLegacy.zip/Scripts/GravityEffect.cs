using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityEffect : MonoBehaviour
{
    Rigidbody myRB;
    [SerializeField] float fallMultiplier;
    [SerializeField] float jumpMultiplier;

    // Start is called before the first frame update
    void Start()
    {
        myRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        GravityAdjustment();
    }

    private void GravityAdjustment()
    {
        if (myRB.linearVelocity.y < 0)
        {
            myRB.linearVelocity += Vector3.up * Physics.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }

        else if (myRB.linearVelocity.y > 0)
        {
            myRB.linearVelocity += Vector3.up * Physics.gravity.y * (jumpMultiplier - 1) * Time.deltaTime;
        }
    }
}
