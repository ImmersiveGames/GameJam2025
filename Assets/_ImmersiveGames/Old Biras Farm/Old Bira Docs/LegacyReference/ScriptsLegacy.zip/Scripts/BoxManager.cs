using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxManager : MonoBehaviour
{
    [SerializeField] Transform[] boxSlots;
    int boxSlotCount = 0;
    bool isFullBox = false;

    public bool IsBoxFull() { return isFullBox; }

    public void MilkDrop(GameObject milk) 
    {
        if (!isFullBox) 
        {
            milk.transform.position = boxSlots[boxSlotCount].transform.position;            
            milk.transform.rotation = boxSlots[boxSlotCount].transform.rotation;            
            milk.transform.SetParent(boxSlots[boxSlotCount]);

            if (milk.transform.localScale.y < 0)
            {
                Vector3 scaleCorrection = new Vector3(milk.transform.localScale.x, 
                                                      milk.transform.localScale.y * -1,
                                                      milk.transform.localScale.z);

                milk.transform.localScale = scaleCorrection;
            }

            milk.layer = 0;

            boxSlotCount++;
            if (boxSlotCount > boxSlots.Length - 1) isFullBox = true;
        }

        if (isFullBox) 
        {
            Debug.Log("Caixa cheia! contagem: " + boxSlotCount);
        }
    }
}
