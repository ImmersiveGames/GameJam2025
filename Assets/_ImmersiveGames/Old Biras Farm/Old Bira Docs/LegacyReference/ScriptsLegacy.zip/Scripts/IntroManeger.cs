using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Playables;
using UnityEngine.InputSystem;

public class IntroManeger : MonoBehaviour
{
    PlayableDirector myDirector;
    [SerializeField] Text startText;
    //[SerializeField] Animator doorAnimator;

    bool hasActivated = false;
    PlayerInputSystem myInputSystem;

    // Start is called before the first frame update
    void Start()
    {
        myDirector = GetComponent<PlayableDirector>();
        
        myInputSystem = new PlayerInputSystem();
        myInputSystem.PlayerControls.Enable();
        myInputSystem.PlayerControls.Start.performed += StartMenu;
    }

    // Update is called once per frame
    void StartMenu(InputAction.CallbackContext context)
    {
        if (!hasActivated) 
        {
            if (context.performed)
            {
                startText.enabled = false;
                myDirector.Play();
                //doorAnimator.SetTrigger("Open");
                hasActivated = true;
            }
        } 
    }
}
