using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyAnimations : MonoBehaviour
{
    [SerializeField] PlayerData myPlayerData;
    [SerializeField] Transform myRootTransform;
    [SerializeField] float rotationSensibility;
    [SerializeField] CollisionHandler myCS;
    [SerializeField] float standthreshold = 30f;
    [SerializeField] FaceController myFaceController;

    Animator myAnimator;
    float myStartRotation;
    float headValue = 0f;
    bool iWin = false;

    // Start is called before the first frame update
    void Start()
    {        
        myStartRotation = myRootTransform.transform.rotation.z;
        myAnimator = GetComponent<Animator>();
        myAnimator.SetBool("Win", false);
        iWin = false;            
    }

    // Update is called once per frame
    void Update()
    {
        HeadAnimation();
        if (iWin) { CheckIfIStand(); return; }
        else CheckIfWin();
    }

    void HeadAnimation() 
    {
        float offsetRotation = myStartRotation + rotationSensibility;
        float myCurrentRotation = myRootTransform.transform.rotation.z;

        if (myCurrentRotation >= offsetRotation) headValue = -1f;
        if (myCurrentRotation <= -offsetRotation) headValue = 1f;
        if (myCurrentRotation <= offsetRotation && myCurrentRotation >= -offsetRotation) headValue = 0f;

        if (myFaceController == null) return;
        if (headValue!= 0f) myFaceController.SetState("fs.caution");

        myAnimator.SetFloat("head", headValue);    
    }

    void CheckIfWin() 
    {
        if (myCS.WinState()) 
        {            
            iWin = true;          
        }
    }

    void CheckIfIStand() 
    {
        float myCurrentRotation = myRootTransform.rotation.z * 100;

        if (myCurrentRotation <= -standthreshold || myCurrentRotation >= standthreshold)
        {
            myAnimator.SetBool("Win", false);
        }
        else 
        { 
            myAnimator.SetBool("Win", true);
        }        
    }
}
