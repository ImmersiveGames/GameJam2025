using System;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlataformerController : MonoBehaviour
{
    // General Settings;
    [Header("General Settings")]
    [SerializeField] PlayerData myPlayerData;
    private Rigidbody myRB;
    private PlayerInputSystem myInputSystem;
    private Animator myAnimator;
    private AudioSource myAudioSorce;

    // For Movement
    [Header("Movement Settings")]
    [SerializeField] float movementSpeed;
    [SerializeField] float colisionDistance;
    [SerializeField] Transform flipRef;
    private bool isFacingRight;
    private bool isBlocked = false;

    //for jumping
    [Header("Jump Settings")]   
    [SerializeField] float jumpForce;
    [SerializeField] [Range(0, 1)] float distanceResistence = 0.5f;
    [SerializeField] float groundCheckRadius = 0.2f;
    [SerializeField] LayerMask groundLayer;
    [SerializeField] Transform groundCheck;
    [SerializeField] float doubleJumpForce;
    [SerializeField] GameObject doubleJumpVFX;
    [SerializeField] AudioClip doubleJumpSFX;
    [SerializeField] [Range(0, 10f)]float doubleJumpSFXVolume = 10f;
    [SerializeField] float fallMultiplier = 2.5f;
    [SerializeField] float jumpMultiplier = 2f;
    bool isGrounded = false;
    bool hasDoubleJumped = false;
    Collider[] groundCollisions;

    //for Interaction
    [Header("Interaction Options")]
    [SerializeField] LayerMask milkLayer;
    [SerializeField] float milkDistance = 1f;
    [SerializeField] LayerMask boxLayer;
    [SerializeField] float boxDistance = 1f;
    [SerializeField] LayerMask obstacleLayer;
    [SerializeField] float obstacleCheckRadius = 1.5f;
    [SerializeField] Transform fowardReference;
    [SerializeField] Transform handReference;
    bool hasBottle = false;
    GameObject myMilkBottle;  

    private void Awake()
    {
        myRB = GetComponent<Rigidbody>();
        myAnimator = GetComponent<Animator>();
        myAudioSorce = GetComponent<AudioSource>();

        myInputSystem = new PlayerInputSystem();
        myInputSystem.PlataformerControls.Enable();
        myInputSystem.PlataformerControls.Jump.performed += Jump;
        myInputSystem.PlataformerControls.Interaction.performed += Interact;
    }

    // Start is called before the first frame update
    void Start()
    {
        isFacingRight = true;
    }

    // Update is called once per frame
    void Update()
    {
        GroundCheck();
    }

    void FixedUpdate()
    {
        PlayerMovement();
        GravityAdjustment();
    }

    private void GroundCheck()
    {
        groundCollisions = Physics.OverlapSphere(groundCheck.position, groundCheckRadius, groundLayer);

        if (groundCollisions.Length > 0)
        {
            isGrounded = true;
            isBlocked = false;
        }

        else isGrounded = false;
    }

    void PlayerMovement()
    {        
        Vector2 inputVector = myInputSystem.PlataformerControls.Movement.ReadValue<Vector2>();
        Vector3 movementVector = new Vector3(inputVector.x * movementSpeed * Time.deltaTime, myRB.linearVelocity.y, 0f);

        if (inputVector.x > 0 && !isFacingRight ||
            inputVector.x < 0 && isFacingRight) 
        {
            Flip();
        }

        if (isGrounded)
        {
            myAnimator.SetBool("Jump", false);
            doubleJumpVFX.SetActive(false);
            myAnimator.SetBool("DoubleJump", false);
            myAnimator.SetFloat("Walk", Mathf.Abs(inputVector.x));

        }

        else if (!isGrounded)
        {
            myAnimator.SetFloat("Walk", 0f);
            if (!hasDoubleJumped) myAnimator.SetBool("Jump", true);
            movementVector.x *= distanceResistence;
        }


        if (!BlockCheck())
        {
            myRB.linearVelocity = movementVector;
        }
    }

    bool BlockCheck() 
    {
        Collider[] obstacle = Physics.OverlapSphere(fowardReference.position, colisionDistance, groundLayer);

        if (obstacle.Length > 0)
        {
            isBlocked = true;
        }

        else isBlocked = false;

        return isBlocked;
    }

    void Flip() 
    {
        isFacingRight = !isFacingRight;

        Vector3 myScaleValue = flipRef.localScale;        
        myScaleValue.y *= -1;
        flipRef.localScale = myScaleValue;

        Vector3 myfowardRef = fowardReference.localPosition;
        myfowardRef.x *= -1;
        fowardReference.localPosition = myfowardRef;
    }

    void Jump(InputAction.CallbackContext context) 
    {
        // Normal jump
        if (context.performed && isGrounded)
        {
            //myRB.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            myRB.linearVelocity = Vector3.up * jumpForce;
            hasDoubleJumped = false;
            myAnimator.SetBool("Jump", true);
        }

        // Double Jump
        if (context.performed &&
            isGrounded == false &&
            hasDoubleJumped == false) 
        {
            hasDoubleJumped = true;
            
            myRB.AddForce(Vector3.up * doubleJumpForce, ForceMode.Impulse);

            myAudioSorce.PlayOneShot(doubleJumpSFX, myPlayerData.GetSfxVolume() * doubleJumpSFXVolume);
            doubleJumpVFX.SetActive(true);
            myAnimator.SetBool("DoubleJump", true);
            myAnimator.SetBool("Jump", false);
        }
    }

    private void GravityAdjustment()
    {
        if (myRB.linearVelocity.y < 0)
        {
            myRB.linearVelocity += Vector3.up * Physics.gravity.y * (fallMultiplier - 1) * Time.deltaTime;
        }

        else if (myRB.linearVelocity.y > 0) 
        {
            myRB.linearVelocity += Vector3.up * Physics.gravity.y * (jumpMultiplier - 1) * Time.deltaTime;
        }
    }

    void Interact(InputAction.CallbackContext context) 
    {
        if (context.performed) 
        {
            Collider[] milk = Physics.OverlapSphere(fowardReference.position, milkDistance, milkLayer);
            Collider[] boxes = Physics.OverlapSphere(fowardReference.position, boxDistance, boxLayer);
            Collider[] obstacles = Physics.OverlapSphere(fowardReference.position, obstacleCheckRadius, obstacleLayer);

            // Drop Milk Bottle in the box
            if (boxes.Length > 0 && hasBottle) 
            {
                int boxcount = 0;
                foreach (Collider box in boxes) 
                {
                    if (boxes[boxcount].GetComponent<BoxManager>().IsBoxFull() == false)
                    {
                        myAnimator.SetTrigger("Grab");
                        boxes[boxcount].GetComponent<BoxManager>().MilkDrop(myMilkBottle);
                        hasBottle = false;
                        myMilkBottle = null;
                        return;
                    }
                    else boxcount++;
                }

                return;
            }
            
            // Drop Milk Bottle
            if (hasBottle &&
                myMilkBottle != null &&
                isGrounded &&
                obstacles.Length == 0)
            {
                DropMilk();
                return;
            }

            // Grab Milk Bottle
            if (milk.Length > 0)
            {
                if (hasBottle == false)
                {
                    GrabMilk(milk);
                    return;
                }
            }

            //else 
            //{
            //    Debug.Log("N�o houve Colis�o");
            //}
        }
    }

    private void DropMilk()
    {
        myAnimator.SetTrigger("Grab");

        myMilkBottle.GetComponent<CapsuleCollider>().enabled = true;
        myMilkBottle.transform.GetComponent<Rigidbody>().useGravity = true;
        myMilkBottle.transform.GetComponent<Rigidbody>().isKinematic = false;
        myMilkBottle.transform.parent = null;

        float dropOffset;
        if (isFacingRight) dropOffset = 2f;
        else dropOffset = -2f;

        myMilkBottle.transform.position = new Vector3(myMilkBottle.transform.position.x + dropOffset,
                                                      myMilkBottle.transform.position.y,
                                                      0f);
        
        myMilkBottle = null;
        hasBottle = false;
    }

    private void GrabMilk(Collider[] milk)
    {
        myAnimator.SetTrigger("Grab");

        milk[0].transform.SetParent(handReference.transform);
        myMilkBottle = handReference.transform.GetChild(0).gameObject;

        myMilkBottle.transform.SetPositionAndRotation(handReference.transform.position,
                                                      handReference.transform.rotation);

        if (myMilkBottle.transform.localScale.y < 0)
        {
            Vector3 scaleCorrection = new Vector3(myMilkBottle.transform.localScale.x,
                                                  myMilkBottle.transform.localScale.y * -1,
                                                  myMilkBottle.transform.localScale.z);

            myMilkBottle.transform.localScale = scaleCorrection;
        }

        myMilkBottle.transform.GetComponent<CapsuleCollider>().enabled = false;
        myMilkBottle.transform.GetComponent<Rigidbody>().useGravity = false;
        myMilkBottle.transform.GetComponent<Rigidbody>().isKinematic = true;
        hasBottle = true;
    }
}
