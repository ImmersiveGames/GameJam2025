namespace _ImmersiveGames.NewScripts.Infrastructure.Runtime
{
    public enum RuntimeMode
    {
        Strict = 0,
        Release = 1
    }
}
