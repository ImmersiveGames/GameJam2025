# LATEST — Evidence (fonte canônica)

**Última atualização:** 2026-01-31  
**Regra:** manter **1 arquivo de evidência por dia** (um snapshot consolidado). Outros artefatos do dia devem ser **mesclados** neste arquivo e removidos.

## Snapshot canônico atual

- **2026-01-31 — Baseline 2.2 Evidence Snapshot:** `Reports/Evidence/2026-01-31/Baseline-2.2-Evidence-2026-01-31.md`

## Histórico recente

- 2026-01-29 — `Reports/Evidence/2026-01-29/Baseline-2.2-Evidence-2026-01-29.md`
- 2026-01-28 — `Reports/Evidence/2026-01-28/Baseline-2.2-Evidence-2026-01-28.md`

> Observação: a pasta `Reports/Evidence/<data>/` pode conter `.meta` por exigência do Unity, mas **não deve** conter múltiplos arquivos de evidência humana por dia.
