namespace _ImmersiveGames.NewScripts.Infrastructure.WorldLifecycle.Runtime
{
    internal static class WorldLifecycleReasons
    {
        public const string SceneFlowScenesReady = "SceneFlow/ScenesReady";
        public const string WorldResetRequest = "WorldReset/Request";
    }
}
