namespace _ImmersiveGames.NewScripts.Lifecycle.World.Reset.Domain
{
    /// <summary>
    /// Origem do request de reset.
    /// </summary>
    public enum WorldResetOrigin
    {
        Unknown = 0,
        SceneFlow = 1,
        Manual = 2
    }
}
