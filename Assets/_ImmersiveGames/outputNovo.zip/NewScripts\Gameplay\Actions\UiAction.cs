namespace _ImmersiveGames.NewScripts.Gameplay.Actions
{
    public enum UiAction
    {
        Navigate,
        Submit,
        Cancel
    }
}

