﻿# EvidÃªncia canÃ´nica (LATEST)

Esta pÃ¡gina aponta para o conjunto de evidÃªncias **mais recente** aceito como referÃªncia para auditoria.

## Snapshot atual

- **Data:** 2026-02-03
- **Baseline:** 2.2
- **Arquivo de evidÃªncia:** [`Baseline-2.2-Evidence-2026-02-03.md`](2026-02-03/Baseline-2.2-Evidence-2026-02-03.md)
- **Log bruto:** [`Baseline-2.2-Smoke-LastRun.log`](2026-02-03/Baseline-2.2-Smoke-LastRun.log)
- **Evidências adicionais:** [ADR-0017-LevelCatalog-Evidence-2026-02-03.md](2026-02-03/ADR-0017-LevelCatalog-Evidence-2026-02-03.md)

## Regras

- Quando um snapshot Ã© promovido para â€œLATESTâ€, ele vira **fonte de verdade** atÃ© nova promoÃ§Ã£o.
- AlteraÃ§Ãµes de comportamento devem atualizar o snapshot e/ou justificar divergÃªncias via ADR + evidÃªncia.


