namespace _ImmersiveGames.NewScripts.Gameplay.Actions
{
    public enum SystemAction
    {
        RequestReset,
        RequestQuit
    }
}

