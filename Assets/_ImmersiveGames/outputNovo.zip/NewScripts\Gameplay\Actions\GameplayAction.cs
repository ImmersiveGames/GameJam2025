namespace _ImmersiveGames.NewScripts.Gameplay.Actions
{
    public enum GameplayAction
    {
        Spawn,
        Move,
        Shoot,
        Interact
    }
}

