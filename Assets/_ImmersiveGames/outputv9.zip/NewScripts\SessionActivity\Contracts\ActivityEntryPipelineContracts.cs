using System;
using System.Collections.Generic;
using _ImmersiveGames.NewScripts.Actors.ActivitySetup;
using _ImmersiveGames.NewScripts.Actors.Attributes.Runtime;
using _ImmersiveGames.NewScripts.Actors.Foundation;
using _ImmersiveGames.NewScripts.Actors.Players.ActivitySetup;
using _ImmersiveGames.NewScripts.SessionActivity.Capabilities.Inventory;
using _ImmersiveGames.NewScripts.SessionActivity.Capabilities.Inventory.RuntimeReferences;
using _ImmersiveGames.NewScripts.Actors.Presentation.Contracts;
using _ImmersiveGames.NewScripts.CameraPresentation.Contracts;
using PlayerActivityParticipantBinding = _ImmersiveGames.NewScripts.PlayerParticipation.Contracts.ActivityParticipantBinding;
using PlayerSessionParticipantId = _ImmersiveGames.NewScripts.PlayerParticipation.Contracts.SessionParticipantId;

namespace _ImmersiveGames.NewScripts.SessionActivity.Contracts
{
    public readonly struct ActivityEntryCommand
    {
        public ActivityEntryCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public enum ActivityEntryPreparationResultKind
    {
        Unknown = 0,
        Prepared = 1,
        Failed = 2,
        RejectedStaleOrForeign = 3
    }

    public readonly struct ActivityEntryPreparationResult
    {
        public ActivityEntryPreparationResult(
            bool prepared,
            SessionActivityIdentity identity,
            string reason)
            : this(prepared ? ActivityEntryPreparationResultKind.Prepared : ActivityEntryPreparationResultKind.Failed, identity, reason)
        {
        }

        public ActivityEntryPreparationResult(
            ActivityEntryPreparationResultKind kind,
            SessionActivityIdentity identity,
            string reason)
        {
            Kind = kind;
            Identity = identity;
            Reason = Normalize(reason);
        }

        public ActivityEntryPreparationResultKind Kind { get; }
        public bool Prepared => Kind == ActivityEntryPreparationResultKind.Prepared;
        public SessionActivityIdentity Identity { get; }
        public string Reason { get; }

        public bool IsValid => Kind != ActivityEntryPreparationResultKind.Unknown && Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public enum ActivityEntrySetupReadinessResultKind
    {
        Unknown = 0,
        Completed = 1,
        SkippedNoContent = 2,
        Failed = 3,
        RejectedStaleOrForeign = 4
    }

    public readonly struct ActivityEntrySetupReadinessResult
    {
        public ActivityEntrySetupReadinessResult(
            bool completed,
            SessionActivityIdentity identity,
            string reason)
            : this(completed ? ActivityEntrySetupReadinessResultKind.Completed : ActivityEntrySetupReadinessResultKind.Failed, identity, reason)
        {
        }

        public ActivityEntrySetupReadinessResult(
            ActivityEntrySetupReadinessResultKind kind,
            SessionActivityIdentity identity,
            string reason)
        {
            Kind = kind;
            Identity = identity;
            Reason = Normalize(reason);
        }

        public ActivityEntrySetupReadinessResultKind Kind { get; }
        public bool Completed => Kind == ActivityEntrySetupReadinessResultKind.Completed;
        public bool IsTerminalSuccess => Kind == ActivityEntrySetupReadinessResultKind.Completed || Kind == ActivityEntrySetupReadinessResultKind.SkippedNoContent;
        public SessionActivityIdentity Identity { get; }
        public string Reason { get; }

        public bool IsValid => Kind != ActivityEntrySetupReadinessResultKind.Unknown && Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryContentLoadCommand
    {
        public ActivityEntryContentLoadCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }
        public bool IsValid => Identity.IsValid && Definition.IsValid && !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryContentLoadCompletionCommand
    {
        public ActivityEntryContentLoadCompletionCommand(
            SessionActivityIdentity activeIdentity,
            SessionActivityDefinition definition,
            SessionActivityPendingOperation operation,
            string source,
            string reason)
        {
            ActiveIdentity = activeIdentity;
            Definition = definition;
            Operation = operation;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity ActiveIdentity { get; }
        public SessionActivityDefinition Definition { get; }
        public SessionActivityPendingOperation Operation { get; }
        public string Source { get; }
        public string Reason { get; }
        public bool IsValid => ActiveIdentity.IsValid && Definition.IsValid && Operation.IsValid && !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryContentLoadFailureCommand
    {
        public ActivityEntryContentLoadFailureCommand(
            SessionActivityIdentity activeIdentity,
            SessionActivityDefinition definition,
            SessionActivityPendingOperation operation,
            string source,
            string reason,
            string error)
        {
            ActiveIdentity = activeIdentity;
            Definition = definition;
            Operation = operation;
            Source = Normalize(source);
            Reason = Normalize(reason);
            Error = Normalize(error);
        }

        public SessionActivityIdentity ActiveIdentity { get; }
        public SessionActivityDefinition Definition { get; }
        public SessionActivityPendingOperation Operation { get; }
        public string Source { get; }
        public string Reason { get; }
        public string Error { get; }
        public bool IsValid => ActiveIdentity.IsValid && Definition.IsValid && Operation.IsValid && !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryContentLoadResult
    {
        public ActivityEntryContentLoadResult(
            bool shouldContinueEntry,
            bool pendingOperationIssued,
            string reason)
        {
            ShouldContinueEntry = shouldContinueEntry;
            PendingOperationIssued = pendingOperationIssued;
            Reason = Normalize(reason);
        }

        public bool ShouldContinueEntry { get; }
        public bool PendingOperationIssued { get; }
        public string Reason { get; }
        public bool IsValid => !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryObjectSetupCommand
    {
        public ActivityEntryObjectSetupCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryObjectSetupResult
    {
        public ActivityEntryObjectSetupResult(
            bool completed,
            SessionActivityIdentity identity,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }


    public readonly struct ActivityEntryActorPresentationSetupCommand
    {
        public ActivityEntryActorPresentationSetupCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryActorPresentationSetupResult
    {
        public ActivityEntryActorPresentationSetupResult(
            bool completed,
            SessionActivityIdentity identity,
            int total,
            int resolved,
            int materialized,
            int retained,
            int skipped,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            Total = total < 0 ? 0 : total;
            Resolved = resolved < 0 ? 0 : resolved;
            Materialized = materialized < 0 ? 0 : materialized;
            Retained = retained < 0 ? 0 : retained;
            Skipped = skipped < 0 ? 0 : skipped;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int Total { get; }
        public int Resolved { get; }
        public int Materialized { get; }
        public int Retained { get; }
        public int Skipped { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryActorAttributeSetupCommand
    {
        public ActivityEntryActorAttributeSetupCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryActorAttributeSetupResult
    {
        public ActivityEntryActorAttributeSetupResult(
            bool completed,
            SessionActivityIdentity identity,
            int total,
            int resolved,
            int ready,
            int skipped,
            int failed,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            Total = total < 0 ? 0 : total;
            Resolved = resolved < 0 ? 0 : resolved;
            Ready = ready < 0 ? 0 : ready;
            Skipped = skipped < 0 ? 0 : skipped;
            Failed = failed < 0 ? 0 : failed;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int Total { get; }
        public int Resolved { get; }
        public int Ready { get; }
        public int Skipped { get; }
        public int Failed { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }


    public readonly struct ActivityEntryActorParticipationEnterCommand
    {
        public ActivityEntryActorParticipationEnterCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryActorParticipationEnterResult
    {
        public ActivityEntryActorParticipationEnterResult(
            bool completed,
            SessionActivityIdentity identity,
            int total,
            int entered,
            int skipped,
            int failed,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            Total = total < 0 ? 0 : total;
            Entered = entered < 0 ? 0 : entered;
            Skipped = skipped < 0 ? 0 : skipped;
            Failed = failed < 0 ? 0 : failed;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int Total { get; }
        public int Entered { get; }
        public int Skipped { get; }
        public int Failed { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }


    public readonly struct ActivityEntryPlayerInputBindingReference
    {
        public ActivityEntryPlayerInputBindingReference(
            string requirementId,
            ActivityParticipantRequirementKind participantKind,
            PlayerActivityParticipantBinding participantBinding,
            bool required)
        {
            RequirementId = Normalize(requirementId);
            ParticipantKind = participantKind;
            ParticipantBinding = participantBinding;
            Required = required;
        }

        public string RequirementId { get; }
        public ActivityParticipantRequirementKind ParticipantKind { get; }
        public PlayerActivityParticipantBinding ParticipantBinding { get; }
        public bool Required { get; }

        public bool IsValid =>
            !string.IsNullOrWhiteSpace(RequirementId) &&
            ParticipantKind != ActivityParticipantRequirementKind.Unknown &&
            ParticipantBinding.IsValid;

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryPlayerInputBindingCommand
    {
        public ActivityEntryPlayerInputBindingCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            IReadOnlyList<ActivityEntryPlayerInputBindingReference> participantBindings,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            ParticipantBindings = participantBindings ?? Array.Empty<ActivityEntryPlayerInputBindingReference>();
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public IReadOnlyList<ActivityEntryPlayerInputBindingReference> ParticipantBindings { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            ParticipantBindings != null &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryPlayerInputBindingResult
    {
        public ActivityEntryPlayerInputBindingResult(
            bool completed,
            SessionActivityIdentity identity,
            int requiredCount,
            int requiredBoundCount,
            int totalBoundCount,
            bool skipped,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            RequiredCount = requiredCount < 0 ? 0 : requiredCount;
            RequiredBoundCount = requiredBoundCount < 0 ? 0 : requiredBoundCount;
            TotalBoundCount = totalBoundCount < 0 ? 0 : totalBoundCount;
            Skipped = skipped;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int RequiredCount { get; }
        public int RequiredBoundCount { get; }
        public int TotalBoundCount { get; }
        public bool Skipped { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }


    public readonly struct ActivityEntryPermissionTargetPreparationCommand
    {
        public ActivityEntryPermissionTargetPreparationCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            bool registerReceivers,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            RegisterReceivers = registerReceivers;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public bool RegisterReceivers { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryPermissionTargetPreparationResult
    {
        public ActivityEntryPermissionTargetPreparationResult(
            bool completed,
            SessionActivityIdentity identity,
            int receiverCount,
            bool skipped,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            ReceiverCount = receiverCount < 0 ? 0 : receiverCount;
            Skipped = skipped;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int ReceiverCount { get; }
        public bool Skipped { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryMovementBindingReference
    {
        public ActivityEntryMovementBindingReference(
            string requirementId,
            ActivityParticipantRequirementKind participantKind,
            PlayerActivityParticipantBinding participantBinding,
            bool required)
        {
            RequirementId = Normalize(requirementId);
            ParticipantKind = participantKind;
            ParticipantBinding = participantBinding;
            Required = required;
        }

        public string RequirementId { get; }
        public ActivityParticipantRequirementKind ParticipantKind { get; }
        public PlayerActivityParticipantBinding ParticipantBinding { get; }
        public bool Required { get; }

        public bool IsValid =>
            !string.IsNullOrWhiteSpace(RequirementId) &&
            ParticipantKind != ActivityParticipantRequirementKind.Unknown &&
            ParticipantBinding.IsValid;

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryMovementBindingCommand
    {
        public ActivityEntryMovementBindingCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            IReadOnlyList<ActivityEntryMovementBindingReference> participantBindings,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            ParticipantBindings = participantBindings ?? Array.Empty<ActivityEntryMovementBindingReference>();
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public IReadOnlyList<ActivityEntryMovementBindingReference> ParticipantBindings { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            ParticipantBindings != null &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryMovementBindingResult
    {
        public ActivityEntryMovementBindingResult(
            bool completed,
            SessionActivityIdentity identity,
            int requiredCount,
            int requiredBoundCount,
            int totalBoundCount,
            int retainedCount,
            bool retainedExistingBinding,
            bool skipped,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            RequiredCount = requiredCount < 0 ? 0 : requiredCount;
            RequiredBoundCount = requiredBoundCount < 0 ? 0 : requiredBoundCount;
            TotalBoundCount = totalBoundCount < 0 ? 0 : totalBoundCount;
            RetainedCount = retainedCount < 0 ? 0 : retainedCount;
            RetainedExistingBinding = retainedExistingBinding;
            Skipped = skipped;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int RequiredCount { get; }
        public int RequiredBoundCount { get; }
        public int TotalBoundCount { get; }
        public int RetainedCount { get; }
        public bool RetainedExistingBinding { get; }
        public bool Skipped { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryCameraBindingCommand
    {
        public ActivityEntryCameraBindingCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryCameraBindingResult
    {
        public ActivityEntryCameraBindingResult(
            bool completed,
            SessionActivityIdentity identity,
            int requiredCount,
            bool targetBound,
            bool skipped,
            string reason)
        {
            Completed = completed;
            Identity = identity;
            RequiredCount = requiredCount < 0 ? 0 : requiredCount;
            TargetBound = targetBound;
            Skipped = skipped;
            Reason = Normalize(reason);
        }

        public bool Completed { get; }
        public SessionActivityIdentity Identity { get; }
        public int RequiredCount { get; }
        public bool TargetBound { get; }
        public bool Skipped { get; }
        public string Reason { get; }

        public bool IsValid => Identity.IsValid && !string.IsNullOrWhiteSpace(Reason);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public interface IActivityEntryIdentityRuntimeBridge : IActivityEntryPipelineBoundary
    {
        SessionActivityIdentity BuildIdentity(SessionActivityDefinition definition, SessionActivityStage stage, int entrySequence);
        void SetCurrentIdentity(SessionActivityIdentity identity, SessionActivityStage stage);
    }

    public interface IActivityEntryFactRuntimeBridge
    {
        void EmitFact(
            List<SessionActivityFact> emittedFacts,
            SessionActivityFactKind kind,
            SessionActivityIdentity identity,
            string source,
            string reason,
            string message);
        void EmitSnapshot(
            List<SessionActivitySnapshot> emittedSnapshots,
            string snapshotKind,
            string source,
            string reason,
            string message);
    }

    public interface IActivityEntryContentLoadedSetRuntimeBridge
    {
        void SetCurrentActivityContentLoadedSet(ActivityContentLoadedSet loadedSet);
        void ClearCurrentActivityContentLoadedSet();
    }

    public interface IActivityEntryContentPendingOperationRuntimeBridge
    {
        SessionActivityPendingOperation BuildActivityContentPendingOperation(
            SessionActivityDefinition definition,
            int entrySequence,
            ActivityContentSceneLoadCommand command);
        void SetPendingOperation(SessionActivityPendingOperation operation);
        void RunActivityContentOperation(
            SessionActivityPendingOperation operation,
            ActivityContentSceneLoadCommand command);
    }

    public interface IActivityEntryContentRuntimeBridge :
        IActivityEntryContentLoadedSetRuntimeBridge,
        IActivityEntryContentPendingOperationRuntimeBridge
    {
    }

    public interface IActivityEntryLogRuntimeBridge
    {
        void LogEntryOwnerEvent(
            string eventName,
            SessionActivityIdentity identity,
            string source,
            string reason,
            string detail = "");

        void LogPhaseBoundary(
            string phaseName,
            SessionActivityIdentity identity,
            string source,
            string reason,
            bool completed = false,
            string detail = "");
    }

    public interface IActivityEntryPreparationRuntimeBridge
    {
        void ClearCurrentActivityObjectContributorDiscoveryResult();
        void ClearCurrentActivitySetupInventory();
        void ClearCurrentActorInventoryFeedResult();
        void ResetMovementControlStateForEntry();
        void BeginActivityActorScope(SessionActivityIdentity identity);
        void ClearActiveActorParticipations(string activityId, int entrySequence, string source, string reason);
        bool TryGetActivePlayerActorIdentities(SessionActivityIdentity identity, out IReadOnlyList<PlayerActorIdentityRecord> activeActors);
        void EmitPredefinedVisualSetupReadyFactIfApplicable(
            SessionActivityDefinition definition,
            List<SessionActivityFact> facts,
            SessionActivityIdentity readinessIdentity,
            string source,
            string reason,
            string readinessPoint);

        void ObserveActivitySceneContractOrSkip(
            SessionActivityDefinition definition,
            string source,
            string reason,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots,
            int entrySequence);
    }

    public interface IActivityEntryRuntimeBridge :
        IActivityEntryIdentityRuntimeBridge,
        IActivityEntryFactRuntimeBridge,
        IActivityEntryContentRuntimeBridge,
        IActivityEntryLogRuntimeBridge,
        IActivityEntryPreparationRuntimeBridge
    {
    }

    // Bridge transitoria SA-3B0: expõe apenas state técnico canônico e actor scan targets
    // enquanto o subfluxo é transferido do SessionActivityPipeline para o ActivityEntryPipeline.
    public interface IActivityEntryObjectSetupRuntimeBridge
    {
        ActivityContentLoadedSet GetCurrentActivityContentLoadedSet();
        ActivityObjectContributorDiscoveryResult GetCurrentActivityObjectContributorDiscoveryResult();
        void SetCurrentActivityObjectContributorDiscoveryResult(ActivityObjectContributorDiscoveryResult result);
        void SetCurrentActivitySetupInventory(ActivitySetupInventory inventory);
        void SetCurrentActivityCapabilityInventoryPreview(
            ActivityCapabilityInventory inventory,
            ActivityCapabilityInventoryValidationResult validation);
        void ClearCurrentActivityCapabilityInventoryPreview();
    }

    public interface IActivityEntryActorInventoryRuntimeBridge
    {
        ActivitySceneActorRegistry GetActivitySceneActorRegistry();
        ActivityPlayerActorRegistry GetActivityPlayerActorRegistry();
        SessionActorRuntimeStore GetSessionActorRuntimeStore();
        IReadOnlyList<PlayerActorIdentityRecord> ResolvePlayerActorCapabilityTargetsForCurrentEntry(SessionActivityIdentity identity);
        ActorInventoryFeedResult GetCurrentActorInventoryFeedResult();
        void SetCurrentActorInventoryFeedResult(ActorInventoryFeedResult result);
        void ClearCurrentActorInventoryFeedResult();
    }



    public interface IActivityEntryActorAttributeRuntimeBridge
    {
        ActivityCapabilityInventory GetCurrentActivityCapabilityInventoryPreview();
        void StoreActiveActorAttributeCapability(
            SessionActivityIdentity identity,
            ActorAttributeEndpointReference attributeReference,
            ActorAttributeEndpoint endpoint,
            string pipelineIdentity,
            string activityIdentity);
        void RemoveActiveActorAttributeCapability(ActorInstanceId actorInstanceRuntimeId);
    }



    public interface IActivityEntryActorParticipationRuntimeBridge
    {
        ActorParticipationReadinessEvaluation EvaluateActorParticipationReadiness(
            SessionActivityIdentity identity,
            ActorInstanceRecord instance);
        void StoreActiveActorParticipation(ActorInstanceId actorInstanceRuntimeId);
    }





    public readonly struct ActivityEntryParticipantBindingCommand
    {
        public ActivityEntryParticipantBindingCommand(
            SessionActivityIdentity identity,
            SessionActivityDefinition definition,
            string source,
            string reason)
        {
            Identity = identity;
            Definition = definition;
            Source = Normalize(source);
            Reason = Normalize(reason);
        }

        public SessionActivityIdentity Identity { get; }
        public SessionActivityDefinition Definition { get; }
        public string Source { get; }
        public string Reason { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Definition.IsValid &&
            Identity.Stage == SessionActivityStage.ActivitySetupStarted &&
            string.Equals(Identity.ActivityId, Definition.ActivityId, StringComparison.Ordinal) &&
            Identity.ActivityOrdinal == Definition.ActivityOrdinal &&
            !string.IsNullOrWhiteSpace(Source);

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryParticipantBindingResolvedRecord
    {
        public ActivityEntryParticipantBindingResolvedRecord(
            string requirementId,
            ActivityParticipantRequirementKind participantKind,
            PlayerActivityParticipantBinding participantBinding,
            bool required)
        {
            RequirementId = Normalize(requirementId);
            ParticipantKind = participantKind;
            ParticipantBinding = participantBinding;
            Required = required;
        }

        public string RequirementId { get; }
        public ActivityParticipantRequirementKind ParticipantKind { get; }
        public PlayerActivityParticipantBinding ParticipantBinding { get; }
        public bool Required { get; }

        public bool IsValid =>
            !string.IsNullOrWhiteSpace(RequirementId) &&
            ParticipantKind != ActivityParticipantRequirementKind.Unknown &&
            ParticipantBinding.IsValid;

        private static string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? string.Empty : value.Trim();
        }
    }

    public readonly struct ActivityEntryParticipantBindingResult
    {
        public ActivityEntryParticipantBindingResult(
            SessionActivityIdentity identity,
            int totalRequirements,
            int requiredRequirements,
            int resolvedRequirements,
            int skippedRequirements,
            int requiredResolvedRequirements,
            IReadOnlyList<ActivityEntryParticipantBindingResolvedRecord> resolvedParticipants)
        {
            Identity = identity;
            TotalRequirements = totalRequirements < 0 ? 0 : totalRequirements;
            RequiredRequirements = requiredRequirements < 0 ? 0 : requiredRequirements;
            ResolvedRequirements = resolvedRequirements < 0 ? 0 : resolvedRequirements;
            SkippedRequirements = skippedRequirements < 0 ? 0 : skippedRequirements;
            RequiredResolvedRequirements = requiredResolvedRequirements < 0 ? 0 : requiredResolvedRequirements;
            ResolvedParticipants = resolvedParticipants ?? Array.Empty<ActivityEntryParticipantBindingResolvedRecord>();
        }

        public SessionActivityIdentity Identity { get; }
        public int TotalRequirements { get; }
        public int RequiredRequirements { get; }
        public int ResolvedRequirements { get; }
        public int SkippedRequirements { get; }
        public int RequiredResolvedRequirements { get; }
        public IReadOnlyList<ActivityEntryParticipantBindingResolvedRecord> ResolvedParticipants { get; }

        public bool IsValid =>
            Identity.IsValid &&
            Identity.Stage == SessionActivityStage.ActivityParticipantBindingCompleted &&
            RequiredRequirements >= 0 &&
            ResolvedRequirements >= 0 &&
            SkippedRequirements >= 0 &&
            RequiredResolvedRequirements >= 0 &&
            RequiredResolvedRequirements <= RequiredRequirements &&
            ResolvedParticipants != null;
    }

    public interface IActivityEntryPermissionTargetRuntimeBridge
    {
        ActivityCapabilityInventory GetCurrentActivityCapabilityInventoryPreview();
        void BeginPermissionScope(SessionActivityIdentity identity);
        void ReplacePermissionReceivers(IReadOnlyList<ActivityCapabilityPermissionReceiverReference> receivers);
    }


    public interface IActivityEntryMovementBindingRuntimeBridge
    {
        ActivityPlayerActorRegistry GetActivityPlayerActorRegistry();
        IMovementBindingAdapter GetMovementBindingAdapter();
        IReadOnlyList<PlayerActorIdentityRecord> ResolveRetainedMovementTargets(SessionActivityIdentity identity);
        void SetMovementControlTargets(IReadOnlyList<PlayerActorIdentityRecord> targets, bool enableAllowed);
    }

    public interface IActivityEntryCameraBindingRuntimeBridge
    {
        ActivitySetupInventory GetCurrentActivitySetupInventory();
        bool TryGetCurrentActivityCapabilityInventory(
            SessionActivityIdentity identity,
            out ActivityCapabilityInventory inventory,
            out ActivityCapabilityInventoryValidationResult validation);
        IReadOnlyList<PlayerActivityParticipantBinding> GetActivityParticipantBindings();
        bool TryResolvePlayerActorHandle(
            SessionActivityIdentity identity,
            PlayerActivityParticipantBinding binding,
            out PlayerActorRuntimeHandle handle);
        bool TryGetActivityCameraPreparationExecutor(out IActivityCameraPreparationExecutor executor);
    }


    public interface IActivityEntryActorPresentationRuntimeBridge
    {
        ActivityCapabilityInventory GetCurrentActivityCapabilityInventoryPreview();
        bool TryGetActiveActorPresentationHandle(
            ActorPresentationEndpointReference presentationReference,
            out ActorPresentationRuntimeHandle handle);
        void StoreActiveActorPresentationHandle(
            SessionActivityIdentity identity,
            ActorPresentationEndpointReference presentationReference,
            ActorPresentationRuntimeHandle handle);
        void SyncActiveActorPresentationHandle(
            SessionActivityIdentity identity,
            ActorPresentationEndpointReference presentationReference,
            ActorPresentationRuntimeHandle handle);
        void ReleaseActorPresentationBeforeRematerialization(
            ActivityEntryActorPresentationSetupCommand command,
            ActorInstanceId actorInstanceRuntimeId,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
    }

    public interface IActivityEntryPipeline
    {
        ActivityEntryPreparationResult PrepareEntry(ActivityEntryCommand command);
        ActivityEntrySetupReadinessResult ExecuteSetupAndReadiness(
            ActivityEntryCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryContentLoadResult BeginContentLoad(
            ActivityEntryContentLoadCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryContentLoadResult CompleteContentLoad(
            ActivityEntryContentLoadCompletionCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryObjectSetupResult ExecuteSetupInfrastructure(
            ActivityEntryObjectSetupCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryParticipantBindingResult ExecuteParticipantBinding(
            ActivityEntryParticipantBindingCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryObjectSetupResult ExecuteCapabilityObjectSetup(
            ActivityEntryObjectSetupCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryActorPresentationSetupResult ExecuteActorPresentationSetup(
            ActivityEntryActorPresentationSetupCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryActorAttributeSetupResult ExecuteActorAttributeSetup(
            ActivityEntryActorAttributeSetupCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryActorParticipationEnterResult ExecuteActorParticipationEnter(
            ActivityEntryActorParticipationEnterCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryPlayerInputBindingResult ExecutePlayerInputBinding(
            ActivityEntryPlayerInputBindingCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryPermissionTargetPreparationResult ExecutePermissionTargetPreparation(
            ActivityEntryPermissionTargetPreparationCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryMovementBindingResult ExecuteMovementBinding(
            ActivityEntryMovementBindingCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        ActivityEntryCameraBindingResult ExecuteCameraBinding(
            ActivityEntryCameraBindingCommand command,
            List<SessionActivityFact> facts,
            List<SessionActivitySnapshot> snapshots);
        void FailContentLoad(ActivityEntryContentLoadFailureCommand command, List<SessionActivityFact> facts);
        void ResetState();
    }
}
