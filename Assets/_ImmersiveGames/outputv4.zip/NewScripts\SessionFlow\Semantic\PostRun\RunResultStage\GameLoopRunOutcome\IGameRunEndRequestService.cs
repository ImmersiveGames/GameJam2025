// Assets/_ImmersiveGames/NewScripts/Gameplay/GameLoop/IGameRunEndRequestService.cs

using _ImmersiveGames.NewScripts.SessionFlow.GameLoop.RunLifecycle.Core;
namespace _ImmersiveGames.NewScripts.SessionFlow.Semantic.PostRun.RunResultStage.GameLoopRunOutcome
{
    /// <summary>
    /// Ponto único de entrada para solicitar o encerramento de uma execução de gameplay (vitória/derrota).
    ///
    /// Observações:
    /// - Este serviço NÃO define as condições de vitória/derrota.
    /// - Sistemas de gameplay devem apenas chamar <see cref="RequestRunEnd"/> quando detectarem
    ///   suas próprias condições (tempo, morte, objetivo, sequência de eventos etc.).
    /// - O processamento real e a deduplicação acontecem do lado consumidor (ex.: GameRunOutcomeService).
    /// </summary>
    public interface IGameRunEndRequestService
    {
        /// <summary>
        /// Solicita o encerramento do run atual.
        /// </summary>
        /// <param name="outcome">Vitória ou Derrota.</param>
        /// <param name="reason">Motivo/assinatura do emissor (útil para debug/telemetria).</param>
        void RequestRunEnd(GameRunOutcome outcome, string reason);
    }
}

