using _ImmersiveGames.NewScripts.SessionFlow.Semantic.PostRun.Contracts;
namespace _ImmersiveGames.NewScripts.SessionFlow.Semantic.SessionTransition.Runtime
{
    /// <summary>
    /// Identificador canonico dos eixos compostos por SessionTransition.
    /// </summary>
    public enum SessionTransitionAxisId
    {
        Continuity = 0,
        PhaseTransition = 1,
        WorldReset = 2,
        Reconstruction = 3,
        ContentSpawn = 4,
        CarryOver = 5,
    }

    /// <summary>
    /// Mapa minimo dos eixos da transicao de sessao.
    /// Nao executa nada; apenas congela vocabulario e composicao.
    /// </summary>
    public readonly struct SessionTransitionAxisMap
    {
        public SessionTransitionAxisMap(
            SessionTransitionIntentKind intentKind,
            RunContinuationKind legacyRunContinuation,
            SessionTransitionPhaseAction phaseTransition,
            SessionTransitionResetAction worldReset,
            bool reconstruction,
            bool contentSpawn,
            bool carryOver)
        {
            IntentKind = intentKind;
            LegacyRunContinuation = legacyRunContinuation;
            PhaseTransition = phaseTransition;
            WorldReset = worldReset;
            Reconstruction = reconstruction;
            ContentSpawn = contentSpawn;
            CarryOver = carryOver;
        }

        public SessionTransitionIntentKind IntentKind { get; }

        /// <summary>
        /// Ponte explícita de telemetria para o contrato antigo de PostRun.
        /// InitialEntry deve manter este campo como Unknown.
        /// </summary>
        public RunContinuationKind LegacyRunContinuation { get; }
        public RunContinuationKind Continuity => LegacyRunContinuation;
        public SessionTransitionPhaseAction PhaseTransition { get; }
        public SessionTransitionResetAction WorldReset { get; }
        public bool Reconstruction { get; }
        public bool ContentSpawn { get; }
        public bool CarryOver { get; }

        public bool ComposesPhaseTransition => PhaseTransition != SessionTransitionPhaseAction.None;
        public bool ComposesWorldReset => WorldReset != SessionTransitionResetAction.None;

        public override string ToString()
        {
            return $"Intent='{IntentKind}', LegacyRunContinuation='{LegacyRunContinuation}', PhaseTransition='{PhaseTransition}', WorldReset='{WorldReset}', Reconstruction='{Reconstruction}', ContentSpawn='{ContentSpawn}', CarryOver='{CarryOver}'";
        }
    }
}
