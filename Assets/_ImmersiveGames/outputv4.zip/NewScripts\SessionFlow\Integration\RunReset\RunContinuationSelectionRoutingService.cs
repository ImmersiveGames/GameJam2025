using System;
using System.Threading.Tasks;
using _ImmersiveGames.NewScripts.Foundation.Core.Logging;
using _ImmersiveGames.NewScripts.SessionFlow.Semantic.PostRun.Contracts;

namespace _ImmersiveGames.NewScripts.SessionFlow.Integration.RunReset
{
    [DebugLevel(DebugLevel.Verbose)]
    public sealed class RunContinuationSelectionRoutingService : IRunContinuationSelectionRoutingService
    {
        private readonly IRunContinuationOperationalHandoffService _handoffService;

        public RunContinuationSelectionRoutingService(IRunContinuationOperationalHandoffService handoffService)
        {
            _handoffService = handoffService ?? throw new ArgumentNullException(nameof(handoffService));
        }

        public void RouteSelection(RunContinuationSelection selection)
        {
            RunContinuationSelection routedSelection = NormalizeSelectionForCanonicalRouting(selection);

            DebugUtility.Log<GameRunEndedEventBridge>(
                $"[OBS][GameplaySessionFlow][Seam] translated continuation='{routedSelection.SelectedContinuation}' reason='{routedSelection.Reason}' nextState='{routedSelection.NextState}'.",
                DebugUtility.Colors.Info);

            DebugUtility.Log<GameRunEndedEventBridge>(
                $"[OBS][GameplaySessionFlow][Seam] handoff_dispatch target='RunContinuationOperational' continuation='{routedSelection.SelectedContinuation}' reason='{routedSelection.Reason}' nextState='{routedSelection.NextState}'.",
                DebugUtility.Colors.Info);

            _ = DispatchRunContinuationHandoffAsync(_handoffService, routedSelection);
        }

        private static RunContinuationSelection NormalizeSelectionForCanonicalRouting(RunContinuationSelection selection)
        {
            if (selection.SelectedContinuation != RunContinuationKind.Retry)
            {
                return selection;
            }

            RunContinuationSelection normalizedSelection = new RunContinuationSelection(
                selection.ContinuationContext,
                RunContinuationKind.RestartCurrentPhase,
                selection.Completion);

            DebugUtility.Log<GameRunEndedEventBridge>(
                $"[OBS][GameplaySessionFlow][Seam] continuation_normalized from='Retry' to='RestartCurrentPhase' legacy='true' reason='{selection.Reason}' nextState='{selection.NextState}'.",
                DebugUtility.Colors.Warning);

            return normalizedSelection;
        }

        private static async Task DispatchRunContinuationHandoffAsync(
            IRunContinuationOperationalHandoffService handoffService,
            RunContinuationSelection selection)
        {
            try
            {
                await handoffService.DispatchAsync(selection);

                DebugUtility.Log<GameRunEndedEventBridge>(
                    $"[OBS][GameplaySessionFlow][Seam] handoff_accepted target='RunContinuationOperational' continuation='{selection.SelectedContinuation}' reason='{selection.Reason}' nextState='{selection.NextState}'.",
                    DebugUtility.Colors.Success);
            }
            catch (Exception ex)
            {
                DebugUtility.LogError<GameRunEndedEventBridge>(
                    $"[FATAL][GameplaySessionFlow] Falha inesperada no handoff operacional de RunContinuation. ex='{ex.GetType().Name}: {ex.Message}'.");
            }
        }
    }
}
