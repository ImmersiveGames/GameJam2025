#nullable enable
using System.Threading.Tasks;
using _ImmersiveGames.NewScripts.SceneFlow.Contracts.Navigation;
using _ImmersiveGames.NewScripts.SessionFlow.Semantic.IntroStage.Eligibility;
namespace _ImmersiveGames.NewScripts.SessionFlow.Semantic.IntroStage.ContentContract
{
    /// <summary>
    /// Contexto minimo para execucao da IntroStage antes da revelacao da cena.
    /// O contrato canonico da IntroStage vem do rail phase-owned; este contexto apenas o transporta ate o executor.
    /// </summary>
    public readonly struct IntroStageContext
    {
        public IntroStageSession Session { get; }
        public string ContextSignature { get; }
        public string ExecutionSignature { get; }
        public SceneRouteKind RouteKind { get; }
        public string TargetScene { get; }
        public string Reason { get; }
        public bool HasIntroStage => Session.HasIntroStage;
        public bool IsValid => Session.IsValid;

        public IntroStageContext(
            IntroStageSession session,
            SceneRouteKind routeKind,
            string? targetScene,
            string? reason)
        {
            Session = session;
            ContextSignature = session.SessionSignature;
            ExecutionSignature = session.EntrySignature;
            RouteKind = routeKind;
            TargetScene = targetScene ?? string.Empty;
            Reason = reason ?? string.Empty;
        }
    }

    public interface IIntroStageCoordinator
    {
        Task RunIntroStageAsync(IntroStageContext context);
    }

    public interface IIntroStageControlService
    {
        bool IsIntroStageActive { get; }
        void BeginIntroStage(IntroStageContext context);
        void CompleteIntroStage(string reason);
        void SkipIntroStage(string reason);
        void MarkSessionClosed();
    }

    public readonly struct IntroStageCompletionResult
    {
        public string Reason { get; }
        public bool WasSkipped { get; }

        public IntroStageCompletionResult(string? reason, bool wasSkipped)
        {
            Reason = reason ?? string.Empty;
            WasSkipped = wasSkipped;
        }
    }
}
