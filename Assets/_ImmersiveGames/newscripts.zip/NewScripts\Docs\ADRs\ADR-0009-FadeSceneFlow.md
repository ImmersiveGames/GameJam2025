# ADR-0009 — Fade + SceneFlow (NewScripts)

## Status
Aceito e implementado (baseline operacional validada em log).

## Contexto

O pipeline NewScripts precisava:

- Aplicar **FadeIn/FadeOut** durante transições do SceneFlow.
- Evitar dependência do fade legado.
- Permitir configurar timings por **profile** (startup/frontend/gameplay).
- Coordenar Fade com **Loading HUD** para manter UI consistente (Loading só aparece após FadeIn e some antes do FadeOut).

## Decisão

1. Expor `INewScriptsFadeService` no **DI global**.
2. Integrar o fade ao `ISceneTransitionService` via adapter (`NewScriptsSceneFlowFadeAdapter`).
3. Resolver timings de fade por `NewScriptsSceneTransitionProfile`, carregado via `Resources` em:
   - `SceneFlow/Profiles/<profileName>`
4. Implementar o Fade como uma cena additive (`FadeScene`) com controlador (`NewScriptsFadeController`) que opera via `CanvasGroup`.

## Consequências

- O SceneFlow se torna independente do fade legado.
- A duração do fade é declarativa por profile (sem strings espalhadas além do ponto de resolução).
- O Loading HUD pode ser sincronizado com fases explícitas do SceneFlow:
  - `AfterFadeIn` → `Show`
  - `BeforeFadeOut` → `Hide`
  - `Completed` → safety hide

## Notas de implementação (baseline validada)

Evidências observadas:

- O DI global registra `INewScriptsFadeService`.
- O resolver informa:
  - `Profile resolvido: name='<profile>', path='SceneFlow/Profiles/<profile>'`
- O adapter aplica timings:
  - `fadeIn=0,5` e `fadeOut=0,5` (exemplo do log)
- O fade carrega a `FadeScene` additive quando necessário e encontra `NewScriptsFadeController`.
- O canvas de fade opera com sorting alto (ex.: `sortingOrder=11000`) para sobrepor UI durante transição.

## Evidência

- `Docs/Reports/Report-SceneFlow-Production-Log-2025-12-31.md` (recortes do log: ProfileResolver + FadeController + sequência com LoadingHUD).
