## Evidência canônica (Strict) — 2026-01-31

Fonte: log de execução em Editor/Dev com NEWSCRIPTS_MODE ativo.

### Cenários cobertos (PASS)
A) Boot → Menu (profile=startup): ResetWorld SKIP (profile != gameplay) e ResetCompleted publicado para destravar o SceneFlow gate.
B) Menu → Gameplay (profile=gameplay): ResetWorld reason='SceneFlow/ScenesReady' com pipeline completo + spawn Player/Eater (ActorRegistry=2).
C) IntroStage: bloqueia simulação via token 'sim.gameplay' e libera via reason='IntroStage/UIConfirm', seguindo para GameLoop=Playing.
D) Pause/Resume: token 'state.pause' + InputMode 'PauseOverlay' e retorno a 'Gameplay'.
E) ContentSwap QA: in-place contentId='content.2' reason='QA/ContentSwap/InPlace/NoVisuals'.
F) PostGame: Victory/Defeat publicados via GameRunEndedEvent; Restart -> Boot confirmado; ExitToMenu -> profile=frontend com Reset SKIP.

### Tokens/gates observados
- flow.scene_transition: adquirido em TransitionStarted e liberado em TransitionCompleted
- WorldLifecycle.WorldReset: adquirido durante reset e liberado ao final do pipeline
- sim.gameplay: adquirido durante IntroStage e liberado ao concluir IntroStage
- state.pause: adquirido no Pause e liberado no Resume

### Assinaturas-chave (hard evidence)
- [SceneFlow] TransitionStarted / ScenesReady / TransitionCompleted
- [WorldLifecycle] ResetRequested / ResetCompleted (inclusive em SKIP)
- [GameLoop] Boot → Ready → IntroStage → Playing (+ Paused)
- [InputMode] FrontendMenu / Gameplay / PauseOverlay com razões consistentes
