# Reason-Map (DEPRECATED)

Este arquivo existe **apenas** como *redirect* para buscas/ferramentas e para evitar referências órfãs em auditorias.

## Fonte canônica

- **Use:** `Standards/Observability-Contract.md`
- **Não use:** este arquivo para registrar novos `reason`.

## Regra

Não manter listas duplicadas de `reason`. Qualquer duplicidade inevitavelmente diverge do runtime e enfraquece evidências.

