namespace _ImmersiveGames.NewScripts.Modules.Gameplay.Actions
{
    public enum UiAction
    {
        Navigate,
        Submit,
        Cancel
    }
}

