namespace _ImmersiveGames.NewScripts.Infrastructure.Mode
{
    public enum RuntimeMode
    {
        Strict = 0,
        Release = 1
    }
}
