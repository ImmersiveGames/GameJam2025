using _ImmersiveGames.NewScripts.Core.Composition;
using _ImmersiveGames.NewScripts.Core.Events;
using _ImmersiveGames.NewScripts.Core.Logging;
using _ImmersiveGames.NewScripts.Modules.GameLoop.Core;
using _ImmersiveGames.NewScripts.Modules.GameLoop.Run;
namespace _ImmersiveGames.NewScripts.Modules.GameLoop.Input
{
    /*
     * Auditoria (GameLoopCommands)
     * - GamePauseCommandEvent(bool isPaused) -> EventBus<GamePauseCommandEvent>.Raise(new GamePauseCommandEvent(true/false)).
     * - GameResumeRequestedEvent() -> EventBus<GameResumeRequestedEvent>.Raise(new GameResumeRequestedEvent()).
     * - GameRunEndRequestedEvent(GameRunOutcome outcome, string reason) -> IGameRunEndRequestService.RequestRunEnd(...)
     *   (publica EventBus<GameRunEndRequestedEvent> dentro do serviço).
     * - GameRunEndedEvent(GameRunOutcome outcome, string reason) -> publicado pelo GameRunOutcomeService via EventBus<GameRunEndedEvent>.
     * - GameResetRequestedEvent(reason) -> EventBus<GameResetRequestedEvent>.Raise(new GameResetRequestedEvent(reason)).
     * - GameExitToMenuRequestedEvent(reason) -> EventBus<GameExitToMenuRequestedEvent>.Raise(new GameExitToMenuRequestedEvent(reason)).
     */
    public sealed class GameLoopCommands : IGameLoopCommands
    {
        private readonly IGameRunEndRequestService _runEndRequestService;
        private const string DefaultExitToMenuReason = "GameLoopCommands/ExitToMenu";
        private const string DefaultRestartReason = "GameLoopCommands/Restart";

        public GameLoopCommands(IGameRunEndRequestService runEndRequestService)
        {
            _runEndRequestService = runEndRequestService;
        }

        public void RequestPause(string reason = null)
        {
            DebugUtility.Log(typeof(GameLoopCommands),
                $"[GameLoopCommands] RequestPause reason='{GameLoopReasonFormatter.Format(reason)}'");

            EventBus<GamePauseCommandEvent>.Raise(new GamePauseCommandEvent(true));
        }

        public void RequestResume(string reason = null)
        {
            DebugUtility.Log(typeof(GameLoopCommands),
                $"[GameLoopCommands] RequestResume reason='{GameLoopReasonFormatter.Format(reason)}'");

            EventBus<GameResumeRequestedEvent>.Raise(new GameResumeRequestedEvent());
        }

        public void RequestVictory(string reason)
        {
            string normalizedReason = GameLoopReasonFormatter.NormalizeRequired(reason);

            DebugUtility.Log(typeof(GameLoopCommands),
                $"[GameLoopCommands] RequestVictory reason='{normalizedReason}'");

            RequestRunEnd(GameRunOutcome.Victory, normalizedReason);
        }

        public void RequestDefeat(string reason)
        {
            string normalizedReason = GameLoopReasonFormatter.NormalizeRequired(reason);

            DebugUtility.Log(typeof(GameLoopCommands),
                $"[GameLoopCommands] RequestDefeat reason='{normalizedReason}'");

            RequestRunEnd(GameRunOutcome.Defeat, normalizedReason);
        }

        public void RequestRestart(string reason)
        {
            string normalizedReason = GameLoopReasonFormatter.NormalizeOptional(reason, DefaultRestartReason);

            DebugUtility.Log(typeof(GameLoopCommands),
                $"[GameLoopCommands] RequestRestart reason='{normalizedReason}'");

            EventBus<GameResetRequestedEvent>.Raise(new GameResetRequestedEvent(normalizedReason));
        }

        public void RequestExitToMenu(string reason)
        {
            string normalizedReason = GameLoopReasonFormatter.NormalizeOptional(reason, DefaultExitToMenuReason);

            DebugUtility.Log(typeof(GameLoopCommands),
                $"[GameLoopCommands] RequestExitToMenu reason='{normalizedReason}'");

            EventBus<GameExitToMenuRequestedEvent>.Raise(new GameExitToMenuRequestedEvent(normalizedReason));
        }

        private void RequestRunEnd(GameRunOutcome outcome, string reason)
        {
            if (_runEndRequestService != null)
            {
                _runEndRequestService.RequestRunEnd(outcome, reason);
                return;
            }

            if (DependencyManager.HasInstance &&
                DependencyManager.Provider.TryGetGlobal<IGameRunEndRequestService>(out var runEndRequestService) &&
                runEndRequestService != null)
            {
                runEndRequestService.RequestRunEnd(outcome, reason);
                return;
            }

            DebugUtility.LogWarning(typeof(GameLoopCommands),
                "[GameLoopCommands] IGameRunEndRequestService indisponível. Ignorando RequestRunEnd.");
        }
    }
}
