﻿namespace _ImmersiveGames.NewScripts.Modules.SceneFlow.Readiness
{
    /// <summary>
    /// Serviço de classificação de cenas de gameplay.
    /// </summary>
    public interface IGameplaySceneClassifier
    {
        bool IsGameplayScene();
    }
}
