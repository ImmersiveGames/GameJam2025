﻿namespace _ImmersiveGames.NewScripts.Modules.SceneFlow.Readiness.Runtime
{
    /// <summary>
    /// Marcador explícito para identificar o escopo de serviços da cena atual.
    /// </summary>
    public interface ISceneScopeMarker
    {
    }
}
