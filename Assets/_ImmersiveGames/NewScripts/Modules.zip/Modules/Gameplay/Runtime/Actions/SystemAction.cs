namespace _ImmersiveGames.NewScripts.Modules.Gameplay.Runtime.Actions
{
    public enum SystemAction
    {
        RequestReset,
        RequestQuit
    }
}

